$.wait('.plurk[id^=p]', function(){
	$(this).find('.p_img img').mouseenter(function(){
		function enlarge(obj){
			$(obj).stop(true).animate({width: 100, height: 100, top:-40, left:-40}, 500);
			$(obj).css({'z-index' : '99999', 'position': 'relative', '-webkit-box-shadow' : 'rgba(0, 0, 0, 0.796875) 0px 0px 10px 0px'});
		}
		if( (m = $(this).attr('src').match(/(\d+)-small(\d+)/)) ){
			//$(this).css({top: 0, left:0});
			$(this).one('load', function(){	enlarge(this); });
			$(this).attr('src', ( 'http://avatars.plurk.com/'+ m[1] +'-big'+m[2]+'.jpg' ));
		}else{ enlarge(this); }

	}).mouseleave(function(){
		$(this).stop(true).animate({width: 20, height: 20, top:0, left:0}, 500, function(){ $(this).css({'-webkit-box-shadow' : 'none'}); });
		$(this).unbind('load');		
	})
}, true);
