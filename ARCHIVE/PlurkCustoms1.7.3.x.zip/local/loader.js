function localScript(scriptText, args){
	var args = JSON.stringify(args);
	if(typeof scriptText == 'function') scriptText = '(' + scriptText + ')('+args+');';
	var script = document.createElement('script'); 
	script.type = 'text/javascript'; 
	script.appendChild(document.createTextNode(scriptText));
	document.body.appendChild(script);	
}
function loadScript(file){
	var xhrObj = new XMLHttpRequest();
	xhrObj.open('GET', chrome.extension.getURL(file), false);
	xhrObj.send('');
	var se = document.createElement('script');
	se.type = "text/javascript";
	se.text = xhrObj.responseText;
	document.getElementsByTagName('head')[0].appendChild(se);
}
function loadStyle(file){
	var xhrObj = new XMLHttpRequest();
	xhrObj.open('GET', chrome.extension.getURL(file), false);
	xhrObj.send('');
	var style = document.createElement('style');
	style.type = 'text/css';

	if (style.styleSheet){
	  style.styleSheet.cssText = xhrObj.responseText;
	} else {
	  style.appendChild(document.createTextNode(xhrObj.responseText));
	}
	document.getElementsByTagName('head')[0].appendChild(style);
}
