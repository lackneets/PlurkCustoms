//監控自訂表情上傳
(function handleUploadEmoticons(){
	var field;
	var image;

	$.wait("#emo-add-field2", function(obj){
		var field = obj;
		var image = obj.find('img#emo-add-preview');
		var imageElement = image.get(0);
		var src;

		field.children().hide();
		image.on('load', srcArrived);

		function srcArrived(e){
			$("#emo-add-field2").hide();
			var url = image.attr('src'); 
			var keyword = prompt(__("請為這張圖片取一個名字"), __("表情"));
			if(keyword && keyword.replace(/\s*/, '') != ""){
				saveEmotion(url, keyword, function(emotions){
					reset();
				});
			}else{
				reset();
			}
		}

		function reset(){
			$('#emo-file-form')[0].reset();
			src = null;
			image.attr('src', ''); 
		}

	}, true);

})();


/*$.wait(".error-msg.emo-file-error[style*='visibility: visible']", function(){
	$(".error-msg.emo-file-error").css('visibility', 'hidden');
	alert($(".error-msg.emo-file-error").text());
}, true);

$.wait(".error-msg.emo-url-error[style*='visibility: visible']", function(){
	$(".error-msg.emo-url-error").css('visibility', 'hidden');
	alert($(".error-msg.emo-url-error").text());
}, true);*/