if(typeof PlurkCustoms == 'undefined') PlurkCustoms = {};

var isMac = navigator.platform.match(/Mac/i);
var plurkCustoms;
var token;
var extension_url = "https://chrome.google.com/webstore/detail/plurkcustoms-%E8%87%AA%E8%A8%82%E8%A1%A8%E6%83%85%E5%9C%96%E5%BA%AB/npkllofhoohpldfjaepknfbjbmehjpmc";
var permission_request = false;


var emotionUsed = [];
var emotionUplaoded = [];
var emotionRemoved = [];

function arrayClone(arr){
	if(typeof arr == 'object') return arr.slice(0);
	else return arr;
}

//取得 manifest 的資料
function manifest(name) {
	var value;
	
	if(! manifest.data ) $.ajax({
		url: chrome.extension.getURL('/manifest.json'),
		dataType: 'json',
		async: false,
		success: function(data){
			manifest.data = data;
		}
	});
	value = manifest.data[name]
	return value;
}

function localScript(scriptText, args){
	var args = JSON.stringify(args);
	//if(typeof scriptText == 'function') scriptText = '(function(args){(' + scriptText + ')();})('+args+');';
	if(typeof scriptText == 'function') scriptText = '(' + scriptText + ')('+args+');';
	var script = document.createElement('script'); 
	script.type = 'text/javascript'; 
	script.appendChild(document.createTextNode(scriptText));
	document.body.appendChild(script);
	setTimeout(function(){
		document.body.removeChild(script);
	}, 300)
}
function loadScript(file){
	var xhrObj = new XMLHttpRequest();
	xhrObj.open('GET', chrome.extension.getURL(file), false);
	xhrObj.send('');
	var se = document.createElement('script');
	se.type = "text/javascript";
	se.text = xhrObj.responseText;
	document.getElementsByTagName('head')[0].appendChild(se);	
}

function include(file) {
	if(typeof arguments.callee.cache == 'undefined') arguments.callee.cache = new Array();
	var value;
	var cache = arguments.callee.cache;
	if(typeof cache[file] == 'undefined') $.ajax({
		url: chrome.extension.getURL(file),
		dataType: 'text',
		async: false,
		success: function(data){ cache[file] = data; }
	});
	value = cache[file];
	try{eval(value);}catch(e){ throw e; }
	//return value;
}

function getLocal(variable, callback){
	var id = '__getLocal__' + (new Date()).getTime();
	localScript(function(args){
		var e = document.createElement('div');
		var t = document.createTextNode(JSON.stringify(eval(args.variable)));
		e.id = args.id;
		e.style.display = 'none';
		e.appendChild(t);
		document.body.appendChild(e);
	}, {variable: variable, id: id})
	function retrive(){
		var e = document.getElementById(id);
		if(e){
			callback(JSON.parse(e.firstChild.nodeValue));
			e.parentNode.removeChild(e);
		}else{
			setTimeout(retrive, 500);
		}
	}
	setTimeout(retrive, 500);
}

/*Libs*/
var handup = false;
var emotionsCache;

function sendExtensionRequest(obj, callback){
	if(handup) return false;
	try{
		chrome.extension.sendRequest(obj, callback);
	}catch(e){
		handup = true;
		alert(__('發生錯誤：') + e);
		var c = confirm(__('無法連線到圖庫，請立即重新整理頁面看看，可能有版本更新，繼續將無法正常操作'));
		if(c) window.location.reload();
	}
}
//將單一個自訂表情新增到圖庫
function saveEmotion(url, keyword, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotion: true, url: url, keyword: keyword}, function(emotions){
		if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
		console.log("saveEmotion: userEmotions has been updated");
		if(typeof callback == 'function') callback(emotions);
	});
}
//取代所有 (警告)
function replaceEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({replaceEmotions: true, emotions: emotions}, function(emotions){
		console.log("emotions replaced!!!!!!");
		if(typeof callback == 'function') callback(emotions);
	});
}
//合併表情
function saveEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotions: true, emotions: emotions}, function(emotions){
		console.log("emotions merged!!!!!!");
		if(typeof callback == 'function') callback(emotions);
	});
}
function onlineMergeEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotions: true, type: 'onlineMerge' , emotions: emotions}, function(emotions){
		console.log("onlineMergeEmotions");
		if(typeof callback == 'function') callback(emotions);
	});

}

//將單一個自訂表情從圖庫刪除
function deleteEmotion(keyword, callback){
	if(handup) return false;
	sendExtensionRequest({deleteEmotion: true, keyword: keyword}, function(emotions){
		console.log("deleteEmotion: userEmotions has been updated");
		if(typeof callback == 'function') callback(emotions);
	});
}

//從圖庫載入所有表情
function loadEmotions(callback){
	if(handup) return false;
	sendExtensionRequest({loadEmotions: true}, function(emotions){
		if(typeof emotions != 'object' && typeof emotions != 'array') emotions = new Array();
		if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
		if(typeof callback == 'function') callback(emotions);
	});		

}

//檢查表情是否在噗浪上
function isAlive(keyword, callback){
	if(handup) return false;
	sendExtensionRequest({isAlive: true, keyword: keyword}, callback);
}

function getUserEmoticons(callback, cache){
	if(!getUserEmoticons.emotions) $.ajax({ url: "http://www.plurk.com/EmoticonManager/getUserEmoticons",
		data: {token: token},
		dataType: 'json',
		type: 'POST',
		success: function(onlineEmotions){
			getUserEmoticons.emotions = onlineEmotions;
			onlineMergeEmotions(onlineEmotions, function(){
				loadEmotions(function(emotions){
					var delay = 0;
					for(var i in onlineEmotions) for(var e in emotions) (function(o, e){
						if(o.url == e.url && o.keyword != e.keyword){
						 	setTimeout(function(){removeEmotion(o.url);}, (delay++)*300) && console.log(o.url, delay*300);
						}
					})(onlineEmotions[i], emotions[e]);
					if(typeof callback == 'function') callback(emotions);
				})
			});
		},
		error: function(){
			if(!getUserEmoticons.alerted && (getUserEmoticons.alerted = true)) alert("無法存取您的噗浪自訂表情，請確認您有填寫100%個人資料開啟自訂表情功能");
		}
	});
	else loadEmotions(function(emotions){
		if(callback) callback(emotions);
	})
}

//將一個表情上傳到噗浪
function addEmotion(url, keyword, callback){
	var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
	$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/addEmoticon",
		data: {form_token: token, url: url,  hash_id: hash_id, keyword: keyword},
		type: 'POST',
		success:function(response){
			getUserEmoticons(function(response){
				console.log("userEmotions has been uploaded", keyword);
				if(callback) callback(response);
			});
		}
	});
}

//從噗浪上刪除一個表情
function removeEmotion(url, _callback){
	//if(typeof url != 'string' || !url.match(/plurk\.com\/([0-9a-zA-Z]+)/) ) throw('removeEmotion: invalid url', url)
	var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
	$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/removeEmoticon",
		data: {form_token: token, hash_id: hash_id},
		type: 'POST',
		success:function(response){
			console.log("removeEmotion: " + url + " has been removed from plurk");
			if(typeof _callback == 'function') _callback();
		}
	});
}

function click_smile(smile, callback) { 
	
	var keyword = $(smile).attr("alt");;
	var url = smile.find('img').attr('src');
	
	var match = $(smile).attr("match"); if(! match ) match = 0;
	
	var uploaded = ($.inArray($(smile).attr("alt"), emotionUplaoded) != -1);
	var removed = ($.inArray($(smile).attr("alt"), emotionRemoved) != -1);
			
	if( !uploaded || removed ){ isAlive(keyword, function(isAlive){
		if(!isAlive || removed ){ 
			
			//$(smile).find('img').hide().end().append($("<span style='color:red;text-decoration:none;font-size:12px!important;'>"+ __('上傳中...') +"</span>"));

			$(smile).find('img').hide().end().append($("<img/>", {
				class: 'loading',
				src: chrome.extension.getURL('images/loading-orange.gif')
			}));
			
			loadEmotions(function(emotions){
				emotions.reverse();
				
				
				var aliveCount = 0;
				for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, emotionUplaoded) != -1) aliveCount++;
				
				//可移除清單
				var removeable = emotions.slice(0);
				
				//加入常用作為排序參照
				var favEmotions = EmoticonsStorage.getFavorites();
				for(var i in removeable) {
					removeable[i].favorite = 0;
					for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
						removeable[i].favorite = favEmotions[f].favorite;
						break;
					}
				}
				function sortFavorite(a, b){ return b.favorite - a.favorite; }
				removeable.sort(sortFavorite);
				
				var _removeable = []
				for(var i in removeable) { 
					//如果正在使用則不可移除
					if($.inArray(removeable[i].keyword, emotionUsed) != -1) continue;
					//不在線上 && 未上傳
					if(removeable[i].alive != true && $.inArray(removeable[i].keyword, emotionUplaoded) == -1) continue;
					//已移除
					if($.inArray(removeable[i].keyword, emotionRemoved) != -1) continue;
					
					_removeable.push(removeable[i]);
					//console.log(removeable[i].keyword, removeable[i].favorite); 
				}
				removeable = _removeable; delete _removeable;
				
				
				var toRemove ;

				if(aliveCount > 55 && removeable) toRemove = removeable.pop();
				
				function add(){
					
					addEmotion(url, keyword, function(emotions){
						if((i = $.inArray(keyword, emotionRemoved)) != -1) emotionRemoved.splice(i, 1); //從已刪除移除
						if((i = $.inArray(keyword, emotionUplaoded)) == -1) emotionUplaoded.push(keyword);	//列入已上傳
						//if(emotionUplaoded.length > 50) emotionUplaoded.splice(0, emotionUplaoded.length-50); //保留最後50個已上傳
						$(smile).find('img').show().end().find('.loading').remove();
						addSmile(keyword, match);
						if(typeof callback == 'function') callback();
					});
				}
				
				if(toRemove && toRemove.url){
					removeEmotion(toRemove.url, function(emotions){
						if((i = $.inArray(toRemove.keyword, emotionUplaoded)) != -1) emotionUplaoded.splice(i, 1);	//從已上傳移除
						if((i = $.inArray(toRemove.keyword, emotionRemoved)) == -1) emotionRemoved.push(toRemove.keyword);	//列入已刪除
						add();if(typeof callback == 'function') callback();
					});
				} else {
					add();if(typeof callback == 'function') callback();
				}
			})
			
		}else{
			addSmile(keyword, match);if(typeof callback == 'function') callback();
		}
	})
	}else{ addSmile(keyword, match);if(typeof callback == 'function') callback(); }
	
	if((i = $.inArray(keyword, emotionUsed)) != -1) emotionUsed[i]= emotionUsed.splice(emotionUsed.length-1, 1, emotionUsed[i])[0]; //swap to last
	if(emotionUsed.length > 50) emotionUsed.splice(0, emotionUsed.length-50); //保留最後50個使用紀錄
	if($.inArray($(smile).attr("alt"), emotionUsed) == -1) emotionUsed.push( $(smile).attr("alt") );
	
	console.log('emotionUsed', emotionUsed);
	console.log('emotionUplaoded', emotionUplaoded)
	console.log('emotionRemoved', emotionRemoved)
}

function addSmile(keyword, backward){
	if(!backward) backward = 0;
	if ( !lastInputFocused  ) lastInputFocused = document.getElementById('input_big');
	
	var s = lastInputFocused.selectionStart;
	
	if(backward) lastInputFocused.value = lastInputFocused.value.substr(0, lastInputFocused.selectionStart-backward) + lastInputFocused.value.substr(lastInputFocused.selectionStart, lastInputFocused.value.length)
	if(backward) s = s-backward;
	var t = lastInputFocused.value;
	var k = "[" + keyword + "]";
	var x = t.substr(0, s) + k + t.substr(s, t.length);
	
	lastInputFocused.value = x;
	lastInputFocused.setSelectionRange(s + k.length, s + k.length);
}



//Start PlurkCustoms

(function($){

	jQuery.fn.swapWith = function(to) {
	    return this.each(function() {
	        var copy_to = $(to).clone(true);
	        $(to).replaceWith(this);
	        $(this).replaceWith(copy_to);
	    });
	};
	

	reduceOnlineEmoticons(50);
		
	function findKeywords(plurkData){
		var RegExBrackets = /(\[[^\]]+\])/g ;
		var RegExEmosUrl = /http:\/\/emos\.plurk\.com\/[0-9a-f]{32}_w\d+_h\d+\.\w+/g;
		var RegExEmosHash = /[0-9a-f]{32}/g;
		var emos = plurkData.content.match(RegExEmosUrl);
		var brackets = plurkData.content_raw.match(RegExBrackets);
		var nonConvertedBrackets = plurkData.content.match(RegExBrackets);
		var arr = {};
		//console.log(brackets, nonConvertedBrackets, emos);
		for(var i in nonConvertedBrackets){
			if(!brackets) break;
			var index = brackets.indexOf(nonConvertedBrackets[i]);
			if(index > -1) brackets.splice(index, 1);
		}
		for(var i in emos){
			if(!brackets) break;
			var hash = emos[i].match(RegExEmosHash)[0];
			arr[hash] = "emos" && brackets[i] && brackets[i].replace(/^\[/, '').replace(/\]$/, '');
		}
		
		return arr;
	}

	//去廣告
	$.wait("#plurk_ads", function(elements){ $(elements).remove(); }, true);

	// read token
	try{
		token = $("body").html().match(/token=([\d\w]+)/)[1];
	}catch(e){
		return false;
	}

	Emotion = function(emotion_data){
		for(var i in this.__proto__){
			this[i] = emotion_data[i];
		}
	}
	Emotion.prototype = {
		keyword	: "",
		hash_id	: "",
		url		: "",
		alive	: false
	}

	EmoticonsStorage = {	}
	EmoticonsStorage.getFavorites = function(){
		var fav = localStorage.getItem("emotions_favorites");
		try{ fav = JSON.parse(fav); }catch(e){ fav = new Array();; }
		if(typeof fav != 'object' && typeof fav != 'array') fav = new Array();
		if(fav == null) fav = new Array();
		return arrayClone(fav);
	}
	EmoticonsStorage.addFavorite = function(emotion){
		if(! typeof emotion == 'Emotion') throw("EmoticonsStorage.addFavorite(): Emotion expected");
		
		var emotions = this.getFavorites();
		emotions.sort(sortFavorite);
		
		
		var high = (emotions.length > 0) ? emotions[0].favorite : 0;
		
		// Find the same
		var exist;
		for(var i in emotions) if(emotions[i].hash_id == emotion.hash_id){
			emotion = emotions[i];
			exist = true;
			break;
		}
		if(! exist ) emotions.push(emotion);
		
		function stdDev(a){
			function mean(a){ var sum=eval(a.join("+")); return sum/a.length; }
			var m=mean(a);
			var sum=0;
			var l=a.length;
			for(var i=0;i<l;i++){
				var dev=a[i]-m;
				sum+=(dev*dev);
			}
			return Math.sqrt(sum/(l-1));
		}
		
		
		function array_mid(arr, attr){var s=0; for(i in arr) s+= arr[i][attr]; return s/arr.length; }

		if( typeof emotion.favorite != 'number') emotion.favorite = 0;

		if(emotion.hash_id == emotions[0].hash_id){
			//已經是第一個
		} else if(emotion.favorite == emotions[0].favorite){
			//最高權值但不是第一個
			emotion.favorite += 2;
			
		} else if(emotion.favorite < 256){
			function fav_arr(emotions){  var e = []; for(i in emotions) e.push(emotions[i]['favorite']); return e; };
			
			var mid = Math.ceil(array_mid(emotions, 'favorite')); if(mid < 2) mid = 2;
			var max = Math.max.apply( Math, fav_arr(emotions) );
			var min = Math.min.apply( Math, fav_arr(emotions) );
			var std = stdDev(fav_arr(emotions));
			var inc = Math.ceil(Math.max(min, 1) + std/4);
			//emotion.favorite += inc;
			if(emotion.favorite < mid)  emotion.favorite += inc;
			else emotion.favorite += Math.ceil(Math.max(std/4, 2)) ;
			
		} else {
			for(i in emotions){
				emotions[i].favorite--;
				if(emotions[i].favorite > 255) emotions[i].favorite = 255;
			}
		}
		
		emotion.favorite = Math.min(255, Math.ceil(emotion.favorite));
		
		emotions.sort(sortFavorite);
		
		if(emotions.length > 200) emotions.splice(emotions.length-200, emotions.length); 
		
		function sortFavorite(a, b){ return b.favorite - a.favorite; }
		
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
		
	}
	EmoticonsStorage.renameFavorite = function(url, keyword){
		var emotions = this.getFavorites();
		for(i in emotions) if(emotions[i].url == url) emotions[i].keyword = keyword;
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
	}

	EmoticonsStorage.removeFavorite = function(url){
		var emotions = this.getFavorites();
		for(i in emotions) if(emotions[i].url == url) emotions.splice(i, 1);
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
	}

	
	Function.prototype.clone = function() {
	    var that = this;
	    var temp = function temporary() { return that.apply(this, arguments); };
	    for( key in this ) {
	        temp[key] = this[key];
	    }
	    return temp;
	};
	
	function require(file, callback){
		$.ajax({
		  url: chrome.extension.getURL('/' + file),
		  dataType: "script",
		  async: false,
		  success: callback
		});
	}
	
	//candidate.js



	//顯示「表情圖庫」
	window.showMoreEmotionsTab = showMoreEmotionsTab;
	var lazyLoader;
	function showMoreEmotionsTab(){
		
		if(showMoreEmotionsTab.exist) return false;
		
		$("#emo_my").bind('click' ,function(){
			var t = setInterval(function(){

				$(".emoticons_my #emoticons_my_holder")
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				
				if($(".emoticons_my #emoticons_my_holder table:not(.protected)").length == 0) {
					return;
				}else{
					clearInterval(t);
				}
				
				$(".emoticons_my #emoticons_my_holder")
				.find('table').addClass('protected').hide().end()
				.append(
					$("<ol class='protect' style='margin:20px auto;color:#555;width:350px;'></ol>")
					.append($("<li style='margin:20px 0px;'/>").html(__("PlurkCustoms 已經代管噗浪自訂表情<br> 您應該從「<a class='gallery'>圖庫</a>」來使用表情圖片")))
					.append($("<li style='margin:20px 0px;'/>").html(__("您可以按上方的「新增...」來上傳圖片到圖庫")))
					.append($("<li style='margin:20px 0px;'/>").html(__("或者也可以點選任何他人的自訂表情新增到圖庫")))
					.append($("<li style='margin:20px 0px;'/>").html(__("如果仍需要顯示線上的自訂表情請按一下<a class='showMyEmotions'>這裡</a>")))
				)
				.find('a').css({'cursor' : 'pointer'}).end()
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				 
			}, 200);
		})
		
		var doc = document; 
		createStyle(doc, ".emoticon_selecter.delete.current{ background:red !important; }	.emoticon_selecter.delete.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.rename.current{ background:green !important; }	.emoticon_selecter.rename.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.backup.current{ background:#CF5A00 !important; }	.emoticon_selecter.backup.current a{ color:white !important;}");
		
		//add tab
		var moreEmotionsTab = $('<li class="emoticon_selecter plurkCustoms gallery"><a href="#">'+__('圖庫')+'</a></li>').appendTo("#emoticons_tabs ul");
		moreEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").removeClass("current");
			$("#emoticons_tabs ul li.gallery").addClass("current");
			showStoredEmotions("#emoticons_show");
			return false;
			
		});
		
		
		var backupEmotionsTab = $('<li class="emoticon_selecter plurkCustoms backup" ><a href="#">'+__('備份')+'</a></li>').appendTo("#emoticons_tabs ul");
		backupEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").removeClass("current");
			$("#emoticons_tabs ul li.backup").addClass("current");
			showStoredEmotions("#emoticons_show", 'none');
			
			loadEmotions(function(emotions){
				
				var json = JSON.stringify(emotions);
				var b64 = utf8_to_b64( json );
				
				$("#emoticons_show").empty();
				
				var zone = $(__("<div style='border:3px dashed gray;margin:10px;padding:10px;position:relative;'><p>備份方式：將上方的檔案圖示拖曳至桌面儲存，或點選右鍵另存</p><p>還原方式：將備份的檔案拖曳到虛線框中，而還原有兩種模式</p><p>取代模式：圖庫將被完全刪除並置換成檔案的內容</p><p>合併模式：從備份的檔案中補足圖庫中缺少的圖片</p></div>")).appendTo("#emoticons_show").bind('click', function(e){
					e.stopPropagation();
				    e.preventDefault();
				    return false;
				});
				
				var exp = $("<a class='icon_export' style='display:block;width:auto;margin:8px;padding-left:55px;line-height:48px;'title='"+__("按右鍵另存此檔案")+"' target='_blank'></a>").html(__("%d 張圖片").replace('%d', emotions.length)).prependTo(zone).map(function(){
					this.href = "data:text/plain;charset=utf-8; base64," + b64
				});

				var method = $("<select style='position:absolute; right:10px; top:10px;' />")
					.append( $('<option value="replace">'+__('取代模式')+'</option>') )
					.append( $('<option value="merge">'+__('合併模式')+'</option>') )
					/*.append( $('<option value="delete" style="background:red">刪除圖庫</option>').select(function(){
						var ok = confirm('你確定要完全清空圖庫嗎?');
					}) )*/
					.appendTo(zone);
				
				function handleFileSelect(evt) {
					
				    evt.stopPropagation();
				    evt.preventDefault();

				    var files = evt.dataTransfer.files || evt.target.files; 
				    
				    for (var i = 0, f; f = files[i]; i++) {
				    	
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(e) {
								var data = e.target.result;
								var emotions = {};
								if(data.indexOf('[InternetShortcut]') == 0){ 
									try{
										b64 = data.replace(/[\n\r]*/ig, '').replace('[InternetShortcut]', '').replace('URL=data:text/plain;charset=utf-8; base64,', '');
										emotions = JSON.parse(b64_to_utf8(b64));
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}else{
									try{
										emotions = JSON.parse(data);
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								for(var i=0, e ; e = emotions[i]; i++ ){
									if((e.url && e.keyword && e.hash_id) == false) {
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								if(method.val() == 'replace'){
									var con = confirm("警告！你確定要取代目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) replaceEmotions(emotions, function(emotions){
										for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
										getUserEmoticons();
										alert('圖庫置換成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}else{
									var con = confirm("警告！你確定要合併至目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) saveEmotions(emotions, function(emotions){
										for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
										getUserEmoticons();
										alert('圖庫合併成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}
							};
						})(f);
						reader.readAsText(f)
				    }
				  }
				  
				function handleDragEnd(evt) {
				}

				function handleDragOver(evt) {
					evt.stopPropagation();
					evt.preventDefault();
				}

				  // Setup the dnd listeners.
				  $(zone).get(0).addEventListener('dragover', handleDragOver, false);
				  $(zone).get(0).addEventListener('dragend', handleDragEnd, false);
				  $(zone).get(0).addEventListener('drop', handleFileSelect, false);
			});
				
			return false;
			
		}); // End backup click event
		

		$("<a class='switchWindowMode' style='float:right;height:9px;width:9px; margin:8px; padding:2px; background:url(http://emos.plurk.com/633e54d3723da4e8c1acc48288e952bc_w8_h8.gif) no-repeat; cursor:pointer;' title='切換視窗大小'></a>").toggle(function(){
			$(this).parents('#emoticon_selecter').addClass('large').draggable({ disabled: true });
			$('body').addClass('large_emoticon_selecter');
			$('.tableWrapper').scrollTop(0);
			lazyLoader.resize();

		},function(){
			$(this).parents('#emoticon_selecter').removeClass('large').draggable({ disabled: false });
			$('body').removeClass('large_emoticon_selecter');
			$('.tableWrapper').scrollTop(0);
			lazyLoader.resize();
		}).insertAfter("#emoticons_tabs a.bn_close");
		
		//Make it draggable
		$("#emoticon_selecter").draggable({attachTo: "#emoticons_tabs", ignore: "a, li", "cursor": "move" })
		createStyle(doc, "#emoticon_selecter.ondrag {opacity: 0.5;}");
		createStyle(doc, "#emoticon_selecter {-webkit-box-shadow: rgba(0, 0, 0, 0.8) 2px 2px 5px 0px;-webkit-transition: opacity 0.2s linear;}");
		//createStyle(doc, "#emoticon_selecter #emoticons_tabs {cursor: move ;}");
		showMoreEmotionsTab.exist = true;		

	}
	
	$(".smily_holder img, .cmp_emoticon_off, .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", showMoreEmotionsTab );
	//[reload] showStoredEmotions
	$(".smily_holder img, .cmp_emoticon_off,  .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		if($(".emoticon_selecter.plurkCustoms.delete.current").length) showStoredEmotions("#emoticons_show", 'auto');
		else if($(".emoticon_selecter.plurkCustoms.current").length) showStoredEmotions("#emoticons_show", 'auto');
	});



	window.showStoredEmotions = showStoredEmotions;
	function showStoredEmotions(target, actionMode){

		var _static = arguments.callee;
			
		target = $($('#emoticons_show').get(0) || $('<div id="emoticons_show" />').css('height', '250px').prependTo('#emoticon_selecter')).show();
		$('#emoticon_selecter #emoticon_holder_super_parent').hide();
		$('#emoticons_tabs li[id^=emo_]').click(function(){
			$('#emoticon_selecter #emoticon_holder_super_parent').show();
			$('#emoticons_show').hide();
		});
		
		if(actionMode != 'none') $('#emoticons_tabs li.gallery').siblings().removeClass('current').end().addClass('current');
		
		var help = $("<div style='padding:0 8px; color:#ccc;'>" +  __('Shift + 點選重新命名 / %s + 點選刪除').replace('%s', (isMac? "⌘" : "Ctrl")) +"</div>");
		var tableWrapper 	= $('.tableWrapper').length		? $('.tableWrapper')	:  $("<div class='tableWrapper' style='position:absolute;top:28px;right:0px;left:0px;bottom:0px;overflow-x:hidden;overflow-y:scroll;'> </div>").append(help);
		var filterWrapper 	= $('.filterWrapper').length	? $('.filterWrapper')	:  $("<div class='filterWrapper' style='position:absolute;right:0px;left:0px;top:0px;'></div>").css({'padding' : "3px 8px"});

		var totalPics = 0;
		
		getUserEmoticons(function(emotions){
			
			totalPics = emotions.length;
			
			var shown = $('table.plurkCustoms.gallery').length == 1;
			var modified = JSON.stringify($(target).data('emotions')) != JSON.stringify(emotions);
			
			console.log('shown', shown, 'modified', modified);
			
			if(shown && !modified){
				//console.log('not reload tab');
				$(target).find('.filter').focus()[0].select();
				if(typeof _static.scrollTop == 'number') $(tableWrapper).scrollTop(_static.scrollTop);
				return false;
			}
			
			$(target).data('emotions', emotions);
			
			$(target).unbind('scroll');
			
			var table = _static.table = $("<table class='flexible plurkCustoms gallery' />");
			var count = 0;
			var row ;

			for(var i in emotions){ 
				
				if(count%8==0) row = $("<tr/>").appendTo(table);
				count++;
				var td = $("<td/>").data('emotion', emotions[i]).css({'opacity': (emotions[i].alive ? '1.0 ' : '1.0')}).appendTo(row);
				
				emo = $('<a class="a_emoticon lazy" style="position:relative" />')
					.data('emotion', emotions[i])
					.attr('url', emotions[i].url)
					.attr('alt', emotions[i].keyword)
					.attr('title', emotions[i].keyword)
					.html($("<img data-src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />").hide())
					.appendTo(td);
				
				td.bind("click", function(e){
					var url = $(this).find('a').attr("url");
					var keyword = $(this).find('a').attr("alt");
					
					if(e.shiftKey){ //ShiftKey rename
						var e = $(this).find('a');
						var td = $(this);
						var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
						if(newKeyword && newKeyword != "" && newKeyword != keyword) {
							removeEmotion(url, function(){	//從自訂表情刪除
								deleteEmotion(keyword, function(emotions){	//從圖庫刪除
									saveEmotion(url, newKeyword, function(emotions){
										for(z in emotions) if(emotions[z].url == url) newKeyword = emotions[z].keyword; // peocessed keyword
										var emo = $(td).find('a').attr('alt', newKeyword).attr('title', newKeyword + " ("+__('已重新命名')+")").end().addClass('highlighted');
									})
								});
							});
							EmoticonsStorage.renameFavorite(url, newKeyword);
							//showCandidateEmotions(parent);
						}
					}else if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) ){ //ctrlKey delete
						var e = $(this).find('a');
						var ok = confirm(__("你確定要刪除 %s 嗎").replace('%s', keyword));
						if(ok) {
							removeEmotion(url, function(){
								deleteEmotion(keyword, function(emotions){
									$(e).animate({opacity: 0.1}, 500).unbind('click');
								});
							});
							EmoticonsStorage.removeFavorite(url);
							//showCandidateEmotions(parent);
						}
					}else{
						var e = new Emotion($(this).data('emotion'));
						EmoticonsStorage.addFavorite(e);
						click_smile($(this).find('a')); return false; 
					}
				});
			}
			
			var footer = $("<div style='margin:3px 15px; color:#777; font-size:12px; cursor:default;'> "+ __('共 %d 張圖片').replace('%d', totalPics) +" <span style='float:right'> PlurkCustoms " + manifest('version') + " © 2011-2013 <a href='http://www.plurk.com/Lackneets' target='_blank'>Lackneets</a></span><div Style='color:#999; margin:5px 0;'>"+__('※請勿自行刪除重新安裝以免圖庫遺失，如需更新請重新啟動瀏覽器')+"</div></div>");
			 
			var buffer = $('<div/>').append(tableWrapper, filterWrapper).hide().appendTo('body');
			var filter = newFilter(table);
		
			tableWrapper.empty().append(help).append(table).append(footer);
			filterWrapper.empty().append(filter);
			
			$(target).css({'position': 'relative'});
			$(target).click(function(){ return false; });
			$(target).empty().prepend(filterWrapper).append(tableWrapper);

			lazyLoader = new LazyLoader(tableWrapper);


			function newFilter(table, defaultValue){

				if(typeof _static.filterValue == 'undefined') _static.filterValue = "";
				var delayTimer;
				var filter = $("<input class='filter' type='text' placeholder='"+ __('快速找到相關的表情') + "' />")
					.val(_static.filterValue)
					.keyup(function(){
						var val = $(this).val();
						val = val.replace(/^[\s　]+/, '').replace(/[\s　]+$/, '');
						
						_static.filterValue = val;
						
						var tds = $(table).find("td");

						//show all if empty
						if(val.length == 0) {
							//restore 
							tds.css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
							lazyLoader && lazyLoader.resize();
							return false;
						}
						
						var matched = tds.filter(function(){
							var alt = $(this).find('a').attr('alt').toLowerCase();
							return (alt.indexOf(val.toLowerCase()) != -1);
						});
						
						
						if(matched.length == 0 && val.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)){
							return false;
						}


							
						clearInterval(delayTimer);
						delayTimer = setTimeout(function(){
							//show matched
							matched.addClass('matched').css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
							
							//hide others
							var animated = tds.not(matched).filter(':visible').filter(':lt(25)').css({'max-width': '0', 'max-height': '0', 'opacity' : '0', 'display': ''})
							tds.not(matched).not(animated).attr('style', 'display:none !important;')
							//don't know why this not work
							//tds.not(matched).not(animated).css('display', 'none');
							
							//make first 25 hidden element animated next time
							tds.not(matched).not(":visible").filter(':lt(25)').css({'opacity' : '1', 'display': '', 'max-width': '0', 'max-height': '0'});
							setTimeout(function(){
								lazyLoader.resize();
							}, 300);
						}, 200)

					})
					.trigger('keyup')
					.css({width: '100%'})
					.click(function(){this.select();})
				return filter;
			}

		});
		
		
	}

	function addDefaultSmile(keyword, backward){
		if(!backward) backward = 0;
		if ( !lastInputFocused  ) lastInputFocused = document.getElementById('input_big');
		
		var s = lastInputFocused.selectionStart;
		
		if(backward) lastInputFocused.value = lastInputFocused.value.substr(0, lastInputFocused.selectionStart-backward) + lastInputFocused.value.substr(lastInputFocused.selectionStart, lastInputFocused.value.length)
		if(backward) s = s-backward;
		var t = lastInputFocused.value;
		var k = keyword ;
		var x = t.substr(0, s) + k + t.substr(s, t.length);
		
		lastInputFocused.value = x;
		lastInputFocused.setSelectionRange(s + k.length, s + k.length);
	}
	
	function reduceOnlineEmoticons(max){
		//console.log('縮減線上表情', max);
		getRemovableEmoticons(function(removeable){
			//console.log(removeable);
			for(var i = max; i < removeable.length; i++){
				removeEmotion(removeable[i].url, function(){
				});
			}
		});
	}

	// 算出可刪除的線上表情，依照常用度排序
	function getRemovableEmoticons(callback){
		loadEmotions(function(emotions){
			emotions.reverse();

			var aliveCount = 0;
			//可移除清單
			var removeable = emotions.slice(0);
			var favEmotions = EmoticonsStorage.getFavorites();

			for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, emotionUplaoded) != -1) aliveCount++;

			//加入常用作為排序參照
			for(var i in removeable) {
				removeable[i].favorite = 0;
				for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
					removeable[i].favorite = favEmotions[f].favorite;
					break;
				}
			}

			function sortFavorite(a, b){ return b.favorite - a.favorite; }
			removeable.sort(sortFavorite);

			var _removeable = []
			for(var i in removeable) { 
				//如果正在使用則不可移除
				if($.inArray(removeable[i].keyword, emotionUsed) != -1) continue;
				//不在線上 && 未上傳
				if(removeable[i].alive != true && $.inArray(removeable[i].keyword, emotionUplaoded) == -1) continue;
				//已移除
				if($.inArray(removeable[i].keyword, emotionRemoved) != -1) continue;
				
				_removeable.push(removeable[i]);
				//console.log(removeable[i].keyword, removeable[i].favorite); 
			}
			removeable = _removeable; delete _removeable;

			callback && callback(removeable);
		})
	}
		
	var lastInputFocused;

	
	$("#main_poster .smily_holder img").live("click",function(){
		 lastInputFocused = document.getElementById('input_big');
		 //return false;
	});
	$(".mini_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_small');
	});
	
	$(".cmp_emoticon_on, .cmp_emoticon_off, #main_poster .emoticon_selecter_img_on, #main_poster .emoticon_selecter_img_off").live("click",function(){
		 lastInputFocused = document.getElementById('input_big');
		 console.log('input_big');
		 //return false;
	});
	$(".cmp_emoticon_mini_on, .cmp_emoticon_mini_off, .mini_form .emoticon_selecter_img_on, .mini_form .emoticon_selecter_img_off").live("click",function(){
		lastInputFocused = document.getElementById('input_small');
		console.log('input_small');
	});
	
	$(".private_plurk_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_big_private');
	});
	$(".private_plurk_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_big_private');
	});
	
	function utf8_to_b64( str ) {
	    return window.btoa(unescape(encodeURIComponent( str )));
	}

	function b64_to_utf8( str ) {
	    return decodeURIComponent(escape(window.atob( str )));
	}
	

	
	function createStyle(targetDocument, style){
		var eStyle = targetDocument.createElement('style');
		eStyle.setAttribute("type", "text/css");

		if (eStyle.styleSheet) {   // IE
		    eStyle.styleSheet.cssText = style;
		} else {                // the world
		    var tStyle = targetDocument.createTextNode(style);
		    eStyle.appendChild(tStyle);
		}
		var eHead = targetDocument.getElementsByTagName('head')[0];
		eHead.appendChild(eStyle);
		return eStyle;
	}


})(jQuery);