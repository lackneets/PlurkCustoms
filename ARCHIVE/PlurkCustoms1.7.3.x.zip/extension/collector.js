function collectableEmoticon(elements){
	if(! emotionsCache ) {
		loadEmotions();
		return ;
	}
	
	$(elements).each(function(){
		//for(var i in emotionsCache) if(emotionsCache[i].url == $(this).attr('src')){
		for(var i in emotionsCache) if($(this).attr('src').match(emotionsCache[i].hash_id)){
			$(this).addClass('exist');
			$(this).attr('title', emotionsCache[i].keyword);
			return;
		}
		$(this).addClass('new').attr('title', __('點選以蒐集這張圖片')).bind('click', function(){
			var img = $(this);
			url = $(this).attr('src');
			var defaultKeyword = $(img).attr('keyword');
			keyword = prompt(__("請為這張圖片取一個名字"), defaultKeyword || __("表情"));
			if(keyword && keyword.replace(/\s*/, '') != ""){
				saveEmotion(url, keyword, function(emotions){
					console.log("saveEmotion done");
					img.removeAttr('title').removeClass('new').unbind('click');
					img.attr('title', keyword);
				});
			}
		});
	});
}


$(document).on('mouseover', ".plurk img[src*='emos.plurk.com']:not(.new):not(.exist), #emotiland img[src*='emos.plurk.com']:not(.new):not(.exist)", function(){
	collectableEmoticon(this);
});