﻿(function($){
	
	var plurkCustoms;
	var token = $("body").html().match(/token=([\d\w]+)/)[1];
	
	Function.prototype.clone = function() {
	    var that = this;
	    var temp = function temporary() { return that.apply(this, arguments); };
	    for( key in this ) {
	        temp[key] = this[key];
	    }
	    return temp;
	};
	
	function require(file, callback){
		$.ajax({
		  url: chrome.extension.getURL('/' + file),
		  dataType: "script",
		  async: false,
		  success: callback
		});
	}
	
	//取得 manifest 的資料
	function manifest(name) {
		var value;
		
		if(! manifest.data ) $.ajax({
			url: chrome.extension.getURL('/manifest.json'),
			dataType: 'json',
			async: false,
			success: function(data){
				manifest.data = data;
			}
		});
		value = manifest.data[name]
		return value;
	}
	
	//監控自訂表情上傳
	setInterval(function(){
		
		var img = $(".add-emoticon-panel .popup img.col-right:not(.locked):visible");
		if(img.length){ 
			img.addClass('locked');
			$(".add-emoticon-panel").hide();
			var url = img.attr('src');
			var keyword = prompt("請為這張圖片取一個名字", "表情");

			if(keyword && keyword.replace(/\s*/, '') != ""){
				saveEmotion(url, keyword, function(emotions){
					console.log("saveEmotion done");
					$(".add-emoticon-panel").hide();
					img.removeClass('locked');
				});
			}else{
				$(".add-emoticon-panel").hide();
				img.removeClass('locked');
			}
		}
		
		if($(".error-msg.emo-file-error[style*='visibility: visible']").length){
			$(".error-msg.emo-file-error").css('visibility', 'hidden');
			alert($(".error-msg.emo-file-error").text());
		}
		if($(".error-msg.emo-url-error[style*='visibility: visible']").length){
			$(".error-msg.emo-url-error").css('visibility', 'hidden');
			alert($(".error-msg.emo-url-error").text());
		}

	}, 200)
		
	//檢查表情是否在噗浪上
	function isAlive(keyword, callback){
		chrome.extension.sendRequest({isAlive: true, keyword: keyword}, callback);
		//return	$inArray(keyword, emotionUplaoded) != -1;
	}
	
	function getUserEmoticons(callback, cache){
		if(!getUserEmoticons.emotions) $.ajax({ url: "http://www.plurk.com/EmoticonManager/getUserEmoticons",
			data: {token: token},
			dataType: 'json',
			type: 'POST',
			success:function(emotions){
				for(var i in emotions){
					//emotions[i].alive = true;
					//emotionUplaoded.push(emotions[i].keyword);
				}
				getUserEmoticons.emotions = emotions;
				onlineMergeEmotions(emotions, function(){
					loadEmotions(function(emotions){
						if(callback) callback(emotions);
					})
				});
				
			}
		});
		else loadEmotions(function(emotions){
			if(callback) callback(emotions);
		})
	}
	
	//將單一個自訂表情新增到圖庫
	function saveEmotion(url, keyword, callback){
		chrome.extension.sendRequest({saveEmotion: true, url: url, keyword: keyword}, function(response){
			console.log("saveEmotion: userEmotions has been updated");
			callback();
		});
	}
	//取代所有 (警告)
	function replaceEmotions(emotions, callback){
		chrome.extension.sendRequest({replaceEmotions: true, emotions: emotions}, function(response){
			console.log("emotions replaced!!!!!!");
			callback(emotions);
		});
	}
	//合併表情
	function saveEmotions(emotions, callback){
		chrome.extension.sendRequest({saveEmotions: true, emotions: emotions}, function(response){
			console.log("emotions merged!!!!!!");
			callback(emotions);
		});
	}
	function onlineMergeEmotions(emotions, callback){
		chrome.extension.sendRequest({saveEmotions: true, type: 'onlineMerge' , emotions: emotions}, function(response){
			console.log("onlineMergeEmotions");
			callback(emotions);
		});
	}
	
	//將單一個自訂表情從圖庫刪除
	function deleteEmotion(keyword, callback){
		chrome.extension.sendRequest({deleteEmotion: true, keyword: keyword}, function(response){
			console.log("deleteEmotion: userEmotions has been updated");
			callback();
		});
	}
	
	//從圖庫載入所有表情
	function loadEmotions(callback){
		chrome.extension.sendRequest({loadEmotions: true}, callback);
	}
	
	//將一個表情上傳到噗浪
	function addEmotion(url, keyword, callback){
		var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
		$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/addEmoticon",
			data: {form_token: token, url: url,  hash_id: hash_id, keyword: keyword},
			type: 'POST',
			success:function(response){
				getUserEmoticons(function(response){
					console.log("userEmotions has been updated");
					if(callback) callback(response);
				});
			}
		});
	}
	
	//從噗浪上刪除一個表情
	function removeEmotion(url, _callback){
		var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
		$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/removeEmoticon",
			data: {form_token: token, hash_id: hash_id},
			type: 'POST',
			success:function(response){
				console.log("removeEmotion: " + url + " has been removed from plurk");
				_callback();
			}
		});
	}
	
	//顯示「表情圖庫」
	function showMoreEmotionsTab(){
		if(showMoreEmotionsTab.exist) return false;
		
		$("#emo_my").bind('click' ,function(){
			var t = setInterval(function(){

				$(".emoticons_my #emoticons_my_holder")
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				
				if($(".emoticons_my #emoticons_my_holder table:not(.protected)").length == 0) {
					return;
				}else{
					clearInterval(t);
				}
				
				$(".emoticons_my #emoticons_my_holder")
				.find('table').addClass('protected').hide().end()
				.append(
					$("<ol class='protect' style='margin:20px auto;color:#555;width:350px;'></ol>")
					.append($("<li style='margin:20px 0px;'/>").html("PlurkCustoms 已經代管噗浪自訂表情<br> 您應該從「<a class='gallery'>圖庫</a>」來使用表情圖片"))
					.append($("<li style='margin:20px 0px;'/>").html("您可以按上方的「新增...」來上傳圖片到圖庫"))
					.append($("<li style='margin:20px 0px;'/>").html("或者也可以對任何人的自訂表情按右鍵新增到圖庫"))
					.append($("<li style='margin:20px 0px;'/>").html("如果仍需要顯示線上的自訂表情請按一下<a class='showMyEmotions'>這裡</a>"))
				)
				.find('a').css({'cursor' : 'pointer'}).end()
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				 
			}, 200);
		})
		
		var doc = document; 
		createStyle(doc, ".emoticon_selecter.delete.current{ background:red !important; }	.emoticon_selecter.delete.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.rename.current{ background:green !important; }	.emoticon_selecter.rename.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.backup.current{ background:#CF5A00 !important; }	.emoticon_selecter.backup.current a{ color:white !important;}");
		
		//add tab
		var moreEmotionsTab = $('<li class="emoticon_selecter plurkCustoms gallery"><a href="#">圖庫</a></li>').appendTo("#emoticons_tabs ul");
		moreEmotionsTab.bind("click",function(){
			
			$("#emo_my").click()

			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			
			showStoredEmotions("#emoticons_show");
			
		});
		
		var renameEmotionsTab = $('<li class="emoticon_selecter plurkCustoms rename" ><a href="#">更名</a></li>').appendTo("#emoticons_tabs ul");
		renameEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			showStoredEmotions("#emoticons_show", 'rename');
		});	
			
		var delEmotionsTab = $('<li class="emoticon_selecter plurkCustoms delete" ><a href="#">刪除</a></li>').appendTo("#emoticons_tabs ul");
		delEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			showStoredEmotions("#emoticons_show", 'delete');
		});
		
		var backupEmotionsTab = $('<li class="emoticon_selecter plurkCustoms backup" ><a href="#">備份</a></li>').appendTo("#emoticons_tabs ul");
		backupEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			
			showStoredEmotions("#emoticons_show", 'none');
			
			
			loadEmotions(function(emotions){
				
				var b64 = utf8_to_b64( JSON.stringify(emotions) );
				//var b64_compressed = utf8_to_b64( lzw_encode(JSON.stringify(emotions)) );
				
				$("#emoticons_show").empty();
				
				var zone = $("<div style='border:3px dashed gray;margin:10px;padding:10px;position:relative;'><p>還原：將備份的檔案拖曳到此</p><p>備份：將上方的檔案圖示拖曳至桌面儲存，或點選右鍵另存</p><p>取代模式：圖庫將被完全刪除並置換成檔案的內容</p><p>合併模式：從檔案中補足圖庫中缺少的圖片</p></div>").appendTo("#emoticons_show").bind('click', function(e){
					e.stopPropagation();
				    e.preventDefault();
				    return false;
				});
				
				var exp = $("<a class='icon_export' style='display:block;width:auto;margin:8px;padding-left:55px;line-height:48px;'title='按右鍵另存此檔案' target='_blank'></a>").html(emotions.length + " 張圖片").prependTo(zone).map(function(){
					this.href = "data:text/plain;charset=utf-8; base64," + b64
				})
						
				var method = $("<select style='position:absolute; right:10px; top:10px;' />")
					.append( $('<option value="replace">取代模式</option>') )
					.append( $('<option value="merge">合併模式</option>') )
					/*.append( $('<option value="delete" style="background:red">刪除圖庫</option>').select(function(){
						var ok = confirm('你確定要完全清空圖庫嗎?');
					}) )*/
					.appendTo(zone);
				
				function handleFileSelect(evt) {
					
				    evt.stopPropagation();
				    evt.preventDefault();

				    var files = evt.dataTransfer.files; 
				    
				    for (var i = 0, f; f = files[i]; i++) {
				    	
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(e) {
								var data = e.target.result;
								var emotions = {};
								if(data.indexOf('[InternetShortcut]') == 0){ 
									try{
										b64 = data.replace(/[\n\r]*/ig, '').replace('[InternetShortcut]', '').replace('URL=data:text/plain;charset=utf-8; base64,', '');
										emotions = JSON.parse(b64_to_utf8(b64));
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}else{
									try{
										emotions = JSON.parse(data);
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								for(var i=0, e ; e = emotions[i]; i++ ){
									if((e.url && e.keyword && e.hash_id) == false) {
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								if(method.val() == 'replace'){
									var con = confirm("警告！你確定要取代目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) replaceEmotions(emotions, function(emotions){
										alert('圖庫置換成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}else{
									var con = confirm("警告！你確定要合併至目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) saveEmotions(emotions, function(emotions){
										alert('圖庫合併成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}
							};
						})(f);
						reader.readAsText(f)
				    }
				  }
				  
				function handleDragEnd(evt) {
				}

				function handleDragOver(evt) {
					evt.stopPropagation();
					evt.preventDefault();
				}

				  // Setup the dnd listeners.
				  $(zone).get(0).addEventListener('dragover', handleDragOver, false);
				  $(zone).get(0).addEventListener('dragend', handleDragEnd, false);
				  $(zone).get(0).addEventListener('drop', handleFileSelect, false);
				  
			})
			
		});
		

		$("<a style='float:right;height:9px;width:9px; margin:8px; padding:2px; background:url(http://emos.plurk.com/633e54d3723da4e8c1acc48288e952bc_w8_h8.gif) no-repeat; cursor:pointer;' title='切換視窗大小'></a>").toggle(function(){
			$(this).parents('#emoticon_selecter').addClass('large').draggable({ disabled: true });
			$('body').addClass('large_emoticon_selecter');
		},function(){
			$(this).parents('#emoticon_selecter').removeClass('large').draggable({ disabled: false });
			$('body').removeClass('large_emoticon_selecter');
		}).insertAfter("#emoticons_tabs a.bn_close");
		
		//Make it draggable
		$("#emoticon_selecter").draggable({attachTo: "#emoticons_tabs", ignore: "a, li", "cursor": "move" })
		createStyle(doc, "#emoticon_selecter.ondrag {opacity: 0.5;}");
		createStyle(doc, "#emoticon_selecter {-webkit-box-shadow: rgba(0, 0, 0, 0.8) 2px 2px 5px 0px;-webkit-transition: opacity 0.2s linear;}");
		//createStyle(doc, "#emoticon_selecter #emoticons_tabs {cursor: move ;}");
		showMoreEmotionsTab.exist = true;		

	}
	
	$(".smily_holder img").live("click", showMoreEmotionsTab );
	//[reload] showStoredEmotions
	$(".smily_holder img").live("click", function(){
		if($(".emoticon_selecter.plurkCustoms.delete.current").length) showStoredEmotions("#emoticons_show", 'auto');
		else if($(".emoticon_selecter.plurkCustoms.current").length) showStoredEmotions("#emoticons_show", 'auto');
	});


	function showStoredEmotions(target, actionMode){
		
		if(!actionMode) actionMode = 'default';
		
		if(actionMode != 'auto') $(target).data('actionMode', actionMode) ;
		else actionMode = $(target).data('actionMode');
		
		if(actionMode == 'none') return false;
				
		var totalPics = 0;
	
		getUserEmoticons(function(emotions){
			
			totalPics = emotions.length;
			
			if(actionMode == 'auto' && JSON.stringify($(target).data('emotions')) == JSON.stringify(emotions) && $(target).data('actionMode') == actionMode){
				console.log('not reload tab');
				return false;
			}
			
			$(target).data('emotions', emotions);
			
			var table = $("<table/>");
			var count = 0;
			var row ;
			for(var i in emotions){ 
				
				if(count%8==0) row = $("<tr/>").appendTo(table);
				count++;
				var td = $("<td/>").css({'opacity': (emotions[i].alive ? '1.0 !important' : '1.0 !important'), 'position': 'relative'}).appendTo(row);
				
				emo = $('<a class="a_emoticon" style="position:relative" />')
					.attr('url', emotions[i].url)
					.attr('alt', emotions[i].keyword)
					.attr('title', emotions[i].keyword)
					.html("<img src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />")
					.appendTo(td);
					
				if(actionMode == 'default') td.bind("click",function(){  click_smile($(this).find('a')); return false; });
				else if(actionMode == 'rename') td.bind("click",function(){  
					
					var url = $(this).find('a').attr("url");
					var keyword = $(this).find('a').attr("alt");
					var e = $(this).find('a');
					var newKeyword = prompt("重新命名 " + keyword + " : ",  keyword );
					
					if(newKeyword && newKeyword != "" && newKeyword != keyword) {
						removeEmotion(url, function(){	//從自訂表情刪除
							deleteEmotion(keyword, function(emotions){	//從圖庫刪除
								saveEmotion(url, newKeyword, function(){
									showStoredEmotions(target, actionMode);
								})
							});
						});
					}
					return false; 
				});
				else if(actionMode == 'delete') td.bind("click",function(){  
					
					var url = $(this).find('a').attr("url");
					var keyword = $(this).find('a').attr("alt");
					var e = $(this).find('a');
					var ok = confirm("你確定要刪除 "+ keyword +" 嗎");
					
					if(ok) {
						removeEmotion(url, function(){
							deleteEmotion(keyword, function(emotions){
								$(e).animate({opacity: 0.1}, 500).unbind('click');
							});
						});
					}
					return false; 
				});
			}
			
			var footer = $("<div style='margin:3px 15px; color:#777; font-size:12px; cursor:default;'> 共 "+totalPics+" 張圖片 <span style='float:right'> PlurkCustoms " + manifest('version') + " © 2011 <a href='http://www.plurk.com/Lackneets' target='_blank'>Lackneets</a></span></div>");
			 
			$(target).empty().prepend(table).append(footer);
			
		})
	}
	
	
	

	var emotionUsed = [];
	var emotionUplaoded = [];
	var emotionRemoved = [];
		
	function click_smile(smile) { 
		
		var keyword = $(smile).attr("alt");;
		var url = smile.find('img').attr('src');
		
		var uploaded = ($.inArray($(smile).attr("alt"), emotionUplaoded) != -1);
		var removed = ($.inArray($(smile).attr("alt"), emotionRemoved) != -1);
				
		if( !uploaded || removed ){ isAlive(keyword, function(isAlive){
			if(!isAlive || removed ){ 
				
				$(smile).find('img').hide().end().append($("<span class='color:red';text-decoration:none;'>上傳中...</span>"));
				
				loadEmotions(function(emotions){
					emotions.reverse();
					
					var toRemove ;
					for(var e in emotions){ //console.log("remove? "+ emotions[e].alive +  ", " + emotions[e].keyword + ", " + ($.inArray(emotions[e].keyword, emotionUsed ) == -1) + ", " + ($.inArray(emotions[e].keyword, emotionRemoved ) == -1));
						if(emotions[e].alive == true && $.inArray(emotions[e].keyword, emotionUsed ) == -1 && $.inArray(emotions[e].keyword, emotionRemoved ) == -1){
							toRemove = emotions[e].url;
							emotionRemoved.push(emotions[e].keyword);
							console.log(emotions[e].keyword + "removed automatically")
							break;
						} 
					}
					
					function add(){
						addEmotion(url, keyword, function(emotions){
							if(emotionUplaoded.length > 50) emotionUplaoded.splice(0, emotionUplaoded.length-50); 
							if($.inArray(keyword, emotionRemoved) != -1 ) emotionRemoved.splice($.inArray(keyword, emotionRemoved), 1)
							emotionUplaoded.push( keyword );
							console.log(keyword + "uploaded");
							$(smile).find('img').show().end().find('span').remove();
							addSmile(keyword);
						});
					}
					
					if(toRemove)
						removeEmotion(toRemove, function(emotions){
							add();
						});
					else 
						add();
				})
				
			}else{
				addSmile(keyword);
			}
		})
		}else{ addSmile(keyword); }
		if(emotionUsed.length > 50) emotionUsed.splice(0, emotionUsed.length-50); 
		if($.inArray($(smile).attr("alt"), emotionUsed) == -1) emotionUsed.push( $(smile).attr("alt") );
		
		console.log(emotionUsed);
		console.log(emotionUplaoded)
		console.log(emotionRemoved)
		
	}
	var lastInputFocused;
	function addSmile(keyword){
		if ( !lastInputFocused  ) lastInputFocused = document.getElementById('input_big');
		
		var t = lastInputFocused.value;
		var s = lastInputFocused.selectionStart;
		var k = "[" + keyword + "]";
		var x = t.substr(0, s) + k + t.substr(s, t.length);
		
		lastInputFocused.value = x;
		lastInputFocused.setSelectionRange(s + k.length, s + k.length);
		
		//$("body").append("<script type='text/javascript'>/*Emoticons.forceHide();*/window.scrollTo(0,0);</script>");
	}
	
	
	
	$("#main_poster .smily_holder img").live("click",function(){
		 lastInputFocused = document.getElementById('input_big');
		 
		 /*document.getElementById('input_big').addEventListener('dragover', function(evt){
			evt.stopPropagation();
			//evt.preventDefault();
			//alert('dragover')
		});			
			
		document.getElementById('input_big').addEventListener('drop', function(evt){
			console.log(evt)
			//alert('drop')
		});*/
		 
	});
	
	$(".mini_form .smily_holder img").bind("click",function(){
		lastInputFocused = document.getElementById('input_small');
	});
	function utf8_to_b64( str ) {
	    return window.btoa(unescape(encodeURIComponent( str )));
	}

	function b64_to_utf8( str ) {
	    return decodeURIComponent(escape(window.atob( str )));
	}
	
	// LZW-compress a string
	function lzw_encode(s) {
	    var dict = {};
	    var data = (s + "").split("");
	    var out = [];
	    var currChar;
	    var phrase = data[0];
	    var code = 256;
	    for (var i=1; i<data.length; i++) {
	        currChar=data[i];
	        if (dict[phrase + currChar] != null) {
	            phrase += currChar;
	        }
	        else {
	            out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
	            dict[phrase + currChar] = code;
	            code++;
	            phrase=currChar;
	        }
	    }
	    out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
	    for (var i=0; i<out.length; i++) {
	        out[i] = String.fromCharCode(out[i]);
	    }
	    return out.join("");
	}

	// Decompress an LZW-encoded string
	function lzw_decode(s) {
	    var dict = {};
	    var data = (s + "").split("");
	    var currChar = data[0];
	    var oldPhrase = currChar;
	    var out = [currChar];
	    var code = 256;
	    var phrase;
	    for (var i=1; i<data.length; i++) {
	        var currCode = data[i].charCodeAt(0);
	        if (currCode < 256) {
	            phrase = data[i];
	        }
	        else {
	           phrase = dict[currCode] ? dict[currCode] : (oldPhrase + currChar);
	        }
	        out.push(phrase);
	        currChar = phrase.charAt(0);
	        dict[code] = oldPhrase + currChar;
	        code++;
	        oldPhrase = phrase;
	    }
	    return out.join("");
	}
	
	function createStyle(targetDocument, style){
		var eStyle = targetDocument.createElement('style');
		eStyle.setAttribute("type", "text/css");

		if (eStyle.styleSheet) {   // IE
		    eStyle.styleSheet.cssText = style;
		} else {                // the world
		    var tStyle = targetDocument.createTextNode(style);
		    eStyle.appendChild(tStyle);
		}
		var eHead = targetDocument.getElementsByTagName('head')[0];
		eHead.appendChild(eStyle);
		return eStyle;
	}


})(jQuery);