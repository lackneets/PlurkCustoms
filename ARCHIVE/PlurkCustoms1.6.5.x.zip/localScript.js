﻿function usingjQuery(callback){
	if(typeof jQuery == 'function'){
		if(typeof callback == 'function') callback(jQuery);
	}else{
		var script = document.createElement('script'); 
		script.type = 'text/javascript'; 
		script.src = jQueryPath;
		document.body.appendChild(script);
		var interval = setInterval(function(){
			if(typeof jQuery == 'function'){
				jQuery.noConflict();
				clearInterval(interval);
				if(typeof callback == 'function') callback(jQuery);
				console.log("jQuery is ready")
			}else{
				console.log("Waiting jQuery....")
			}
		}, 50);
	}
}

setInterval(function(){
	if(typeof Poll == 'undefined') return;
	Poll.counts = Poll.getUnreadCounts();
	var title = "";	 var detail = "";
	if(Poll.counts.my) detail += " 我 " + Poll.counts.my;	
	if(Poll.counts.responded) detail += " 回 " + Poll.counts.responded;
	if(Poll.counts.priv) detail += " 私 " + Poll.counts.priv;
	detail = detail.replace(/^\s+/, '').replace(/\s+$/, '');
	if(detail) title = title + " " + detail + "";
	if(Poll.counts.all) title += " 未讀 " + Poll.counts.all;
	
	if(title) document.title = title + " - " + TopBar.cur_page_title;
	else document.title = title;
}, 200);


function markMuted(ids){
	if(typeof ids == 'array' || typeof ids == 'object'){
		for(var i in ids) markMuted(ids[i]);
		return;
	}
	var id = ids;
	console.log("Mute " + id)
	if(typeof id == 'string' || typeof id == 'number') for(var i in $plurks) if($plurks[i].obj.plurk_id == id) ($plurks[i].obj.is_unread = 2);
}

/*
usingjQuery(function($){
	$.wait = function(selector, callback, loop){
		var i = setInterval(function(){
			if($(selector).length > 0 && typeof callback == 'function'){
				var obj = $(selector);
				if(! loop ) clearInterval(i);
				callback.call(obj, obj);
			} 
		}, 200);
	}

})*/