﻿(function($){
	
	var token = $("body").html().match(/token=([\d\w]+)/)[1];
	var uid = $("body").html().match(/user_id=([\d]+)/)[1];
	
	function getFans(offset, callback, fansArray){
		if(!offset) offset = 0;
		if(typeof fansArray != 'array') fansArray = [];
 		$.ajax({
			url: "http://www.plurk.com/Friends/getFansByOffset",
			data: {user_id: uid, offset: offset },
			type: "POST", cache: false,
			success: function(fansJSON){
				var arr = eval('(' + fansJSON + ')');
				fansArray.concat(arr);
				console.log(arr);
				for(var i in arr) writeConsole("<div class='fan' style='padding:3px 0px;border-bottom:gray 1px dashed;'><a target='_blank' href='http://www.plurk.com/" + arr[i].nick_name + "'><img src='http://avatars.plurk.com/" + arr[i].id + "-small" + arr[i].avatar + ".gif'/>" + arr[i].display_name + "</a></div>")
				if(arr.length > 0) getFans(offset + 10, callback, fansArray);
				else if(callback) callback();
			}
		});
	}
	
//	getFans();
	
	/*var win = window.open('', '_blank');
	console.log(win)*/
//	var logWin = $("<div id='plurkCustoms_fansManager' style='position:fixed; padding:6px; bottom:0px;right:0px; height:250px;width:200px; overflow-y:scroll;background:#eee;'><h3 style='color:black'>所有粉絲</h3></div>").appendTo('body');
	function writeConsole(content) {
		//var win = window.open('');
		//win.writeln(content);
		logWin.append(content);
	}
	
	
	
	/*setInterval(function(){
		$(".plurk td.td_img:not(medium)").each(function(){
			$(this).css({position: 'relative', left: '-25px'}).find('img').css({width: '45px', height: '45px'}).each(function(){ $(this).attr('src', $(this).attr('src').replace('small', 'medium'));});
		}).addClass('medium');

	}, 100);*/
	
	
	
	
	
	
	

})(jQuery);