var Gallery = function(){
	this.reduceOnlineEmoticons(50);
	this.init();
}

Gallery.prototype.lazyLoader = null;
Gallery.prototype.galleryTab = null;
Gallery.prototype.galleryPanel = null;
Gallery.prototype.lastInputFocused = null;

Gallery.prototype.emotionUsed = [];
Gallery.prototype.emotionUplaoded = [];
Gallery.prototype.emotionRemoved = [];
Gallery.prototype.init = function() { 
	var	self = this;
	$("#main_poster .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big');
	});
	$(".mini_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_small');
	});
	
	$(".cmp_emoticon_on, .cmp_emoticon_off, #main_poster .emoticon_selecter_img_on, #main_poster .emoticon_selecter_img_off").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big');
	});
	$(".cmp_emoticon_mini_on, .cmp_emoticon_mini_off, .mini_form .emoticon_selecter_img_on, .mini_form .emoticon_selecter_img_off").live("click",function(){
		self.lastInputFocused = document.getElementById('input_small');
	});
	
	$(".private_plurk_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big_private');
	});
	$(".private_plurk_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big_private');
	});
	$(".smily_holder img, .cmp_emoticon_off, .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		self.generateGalleryTab.apply(gallery, arguments);
	} );
	$(".smily_holder img, .cmp_emoticon_off,  .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		if($(".emoticon_selecter.plurkCustoms.delete.current").length) self.showStoredEmotions("#emoticons_show", 'auto');
		else if($(".emoticon_selecter.plurkCustoms.current").length) self.showStoredEmotions("#emoticons_show", 'auto');
	});
}
Gallery.prototype.operateEmoticonClick = function(smile, callback) { 

	var self = this;

	var keyword = $(smile).attr("alt");;
	var url = smile.find('img').attr('src');
	var match = $(smile).attr("match"); if(! match ) match = 0;
	var uploaded = ($.inArray($(smile).attr("alt"), self.emotionUplaoded) != -1);
	var removed = ($.inArray($(smile).attr("alt"), self.emotionRemoved) != -1);
			
	if( !uploaded || removed ){ isAlive(keyword, function(isAlive){
		if(!isAlive || removed ){ 
			
			//$(smile).find('img').hide().end().append($("<span style='color:red;text-decoration:none;font-size:12px!important;'>"+ __('上傳中...') +"</span>"));

			$(smile).find('img').hide().end().append($("<img/>", {
				class: 'loading',
				src: chrome.extension.getURL('images/loading-orange.gif')
			}));
			
			loadEmotions(function(emotions){
				emotions.reverse();
				
				
				var aliveCount = 0;
				for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, self.emotionUplaoded) != -1) aliveCount++;
				
				//可移除清單
				var removeable = emotions.slice(0);
				
				//加入常用作為排序參照
				var favEmotions = EmoticonsStorage.getFavorites();
				for(var i in removeable) {
					removeable[i].favorite = 0;
					for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
						removeable[i].favorite = favEmotions[f].favorite;
						break;
					}
				}
				function sortFavorite(a, b){ return b.favorite - a.favorite; }
				removeable.sort(sortFavorite);
				
				var _removeable = []
				for(var i in removeable) { 
					//如果正在使用則不可移除
					if($.inArray(removeable[i].keyword, self.emotionUsed) != -1) continue;
					//不在線上 && 未上傳
					if(removeable[i].alive != true && $.inArray(removeable[i].keyword, self.emotionUplaoded) == -1) continue;
					//已移除
					if($.inArray(removeable[i].keyword, self.emotionRemoved) != -1) continue;
					
					_removeable.push(removeable[i]);
					//console.log(removeable[i].keyword, removeable[i].favorite); 
				}
				removeable = _removeable; delete _removeable;
				
				
				var toRemove ;

				if(aliveCount > 55 && removeable) toRemove = removeable.pop();
				
				function add(){
					
					addEmotion(url, keyword, function(emotions){
						if((i = $.inArray(keyword, self.emotionRemoved)) != -1) self.emotionRemoved.splice(i, 1); //從已刪除移除
						if((i = $.inArray(keyword, self.emotionUplaoded)) == -1) self.emotionUplaoded.push(keyword);	//列入已上傳
						//if(self.emotionUplaoded.length > 50) self.emotionUplaoded.splice(0, self.emotionUplaoded.length-50); //保留最後50個已上傳
						$(smile).find('img').show().end().find('.loading').remove();
						self.useEmoticon(keyword, match);
						if(typeof callback == 'function') callback();
					});
				}
				
				if(toRemove && toRemove.url){
					removeEmotion(toRemove.url, function(emotions){
						if((i = $.inArray(toRemove.keyword, self.emotionUplaoded)) != -1) self.emotionUplaoded.splice(i, 1);	//從已上傳移除
						if((i = $.inArray(toRemove.keyword, self.emotionRemoved)) == -1) self.emotionRemoved.push(toRemove.keyword);	//列入已刪除
						add();if(typeof callback == 'function') callback();
					});
				} else {
					add();if(typeof callback == 'function') callback();
				}
			})
			
		}else{
			self.useEmoticon(keyword, match);if(typeof callback == 'function') callback();
		}
	})
	}else{ self.useEmoticon(keyword, match);if(typeof callback == 'function') callback(); }
	
	if((i = $.inArray(keyword, self.emotionUsed)) != -1) self.emotionUsed[i]= self.emotionUsed.splice(self.emotionUsed.length-1, 1, self.emotionUsed[i])[0]; //swap to last
	if(self.emotionUsed.length > 50) self.emotionUsed.splice(0, self.emotionUsed.length-50); //保留最後50個使用紀錄
	if($.inArray($(smile).attr("alt"), self.emotionUsed) == -1) self.emotionUsed.push( $(smile).attr("alt") );
	
	console.log('self.emotionUsed', self.emotionUsed);
	console.log('self.emotionUplaoded', self.emotionUplaoded)
	console.log('self.emotionRemoved', self.emotionRemoved)
}
Gallery.prototype.useEmoticon = function(keyword, backward){
	var self = this;
	console.log(keyword, backward, this.lastInputFocused)
	if(!backward) backward = 0;
	if ( !gallery.lastInputFocused  ) gallery.lastInputFocused = document.getElementById('input_big');
	
	var s = gallery.lastInputFocused.selectionStart;
	
	if(backward) gallery.lastInputFocused.value = gallery.lastInputFocused.value.substr(0, gallery.lastInputFocused.selectionStart-backward) + gallery.lastInputFocused.value.substr(gallery.lastInputFocused.selectionStart, gallery.lastInputFocused.value.length)
	if(backward) s = s-backward;
	var t = gallery.lastInputFocused.value;
	var k = "[" + keyword + "]";
	var x = t.substr(0, s) + k + t.substr(s, t.length);
	
	gallery.lastInputFocused.value = x;
	gallery.lastInputFocused.setSelectionRange(s + k.length, s + k.length);
}
Gallery.prototype.useDefaultSmile = function(keyword, backward){
	var self = this;
	if(!backward) backward = 0;
	if ( !gallery.lastInputFocused  ) gallery.lastInputFocused = document.getElementById('input_big');
	
	var s = gallery.lastInputFocused.selectionStart;
	
	if(backward) gallery.lastInputFocused.value = gallery.lastInputFocused.value.substr(0, gallery.lastInputFocused.selectionStart-backward) + gallery.lastInputFocused.value.substr(gallery.lastInputFocused.selectionStart, gallery.lastInputFocused.value.length)
	if(backward) s = s-backward;
	var t = gallery.lastInputFocused.value;
	var k = keyword ;
	var x = t.substr(0, s) + k + t.substr(s, t.length);
	
	gallery.lastInputFocused.value = x;
	gallery.lastInputFocused.setSelectionRange(s + k.length, s + k.length);
}
Gallery.prototype.createNewTab = function(){
}
Gallery.prototype.showSettingTab = function(){
}
Gallery.prototype.showBackupTab = function(){
	var self = this;
	//self.showStoredEmotions("#emoticons_show", 'none');
	
	loadEmotions(function(emotions){
		
		var json = JSON.stringify(emotions);
		var b64 = utf8_to_b64( json );
		
		//$("#emoticons_show").empty();
		
		var zone = $(__("<div style='border:3px dashed gray;margin:10px;padding:10px;position:relative;'><p>備份方式：將上方的檔案圖示拖曳至桌面儲存，或點選右鍵另存</p><p>還原方式：將備份的檔案拖曳到虛線框中，而還原有兩種模式</p><p>取代模式：圖庫將被完全刪除並置換成檔案的內容</p><p>合併模式：從備份的檔案中補足圖庫中缺少的圖片</p></div>"))
			.appendTo(self.galleryPanel.empty())
			.bind('click', function(e){
				e.stopPropagation();
				e.preventDefault();
				return false;
			});
		
		var exp = $("<a class='icon_export' style='display:block;width:auto;margin:8px;padding-left:55px;line-height:48px;'title='"+__("按右鍵另存此檔案")+"' target='_blank'></a>").html(__("%d 張圖片").replace('%d', emotions.length)).prependTo(zone).map(function(){
			this.href = "data:text/plain;charset=utf-8; base64," + b64
		});

		var method = $("<select style='position:absolute; right:10px; top:10px;' />")
			.append( $('<option value="replace">'+__('取代模式')+'</option>') )
			.append( $('<option value="merge">'+__('合併模式')+'</option>') )
			/*.append( $('<option value="delete" style="background:red">刪除圖庫</option>').select(function(){
				var ok = confirm('你確定要完全清空圖庫嗎?');
			}) )*/
			.appendTo(zone);
		
		function handleFileSelect(evt) {
			
		    evt.stopPropagation();
		    evt.preventDefault();

		    var files = evt.dataTransfer.files || evt.target.files; 
		    
		    for (var i = 0, f; f = files[i]; i++) {
		    	
				var reader = new FileReader();
				reader.onload = (function(theFile) {
					return function(e) {
						var data = e.target.result;
						var emotions = {};
						if(data.indexOf('[InternetShortcut]') == 0){ 
							try{
								b64 = data.replace(/[\n\r]*/ig, '').replace('[InternetShortcut]', '').replace('URL=data:text/plain;charset=utf-8; base64,', '');
								emotions = JSON.parse(b64_to_utf8(b64));
							}catch(e){
								console.log(e);
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}else{
							try{
								emotions = JSON.parse(data);
							}catch(e){
								console.log(e);
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}
						
						for(var i=0, e ; e = emotions[i]; i++ ){
							if((e.url && e.keyword && e.hash_id) == false) {
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}
						
						if(method.val() == 'replace'){
							var con = confirm("警告！你確定要取代目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
							if(con) replaceEmotions(emotions, function(emotions){
								for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
								getUserEmoticons();
								alert('圖庫置換成功！');
								getUserEmoticons.emotions = null;
								backupEmotionsTab.trigger('click');
							})
						}else{
							var con = confirm("警告！你確定要合併至目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
							if(con) saveEmotions(emotions, function(emotions){
								for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
								getUserEmoticons();
								alert('圖庫合併成功！');
								getUserEmoticons.emotions = null;
								backupEmotionsTab.trigger('click');
							})
						}
					};
				})(f);
				reader.readAsText(f)
		    }
		  }
		  
		function handleDragEnd(evt) {
		}

		function handleDragOver(evt) {
			evt.stopPropagation();
			evt.preventDefault();
		}
		// Setup the dnd listeners.
		$(zone).get(0).addEventListener('dragover', handleDragOver, false);
		$(zone).get(0).addEventListener('dragend', handleDragEnd, false);
		$(zone).get(0).addEventListener('drop', handleFileSelect, false);
	});
}
Gallery.prototype.showGalleryTab = function(){
	this.showStoredEmotions(this.galleryPanel());
}
Gallery.prototype.getPanel = function(){
	this.generateGalleryTab();
	// 隱藏官方面板
	$('#emoticon_selecter #emoticon_holder_super_parent').hide();
	var panel = $($('#emoticons_show').get(0) || $('<div id="emoticons_show" />').css('height', '250px').prependTo('#emoticon_selecter')).show();
	this.galleryPanel = panel;
	return panel;
}
Gallery.prototype.deprecateDefaultTab = function(){
	$("#emo_my").bind('click' ,function(){
		var t = setInterval(function(){
			$(".emoticons_my #emoticons_my_holder")
			.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
			.find('.showMyEmotions:not(:Event(click))').click( function(){
				$(this).parents('#emoticons_my_holder').find('.protect').hide();
				$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
				return false;
			 }).end();
			
			if($(".emoticons_my #emoticons_my_holder table:not(.protected)").length == 0) {
				return;
			}else{
				clearInterval(t);
			}
			
			$(".emoticons_my #emoticons_my_holder")
			.find('table').addClass('protected').hide().end()
			.append(
				$("<ol class='protect' style='margin:20px auto;color:#555;width:350px;'></ol>")
				.append($("<li style='margin:20px 0px;'/>").html(__("PlurkCustoms 已經代管噗浪自訂表情<br> 您應該從「<a class='gallery'>圖庫</a>」來使用表情圖片")))
				.append($("<li style='margin:20px 0px;'/>").html(__("您可以按上方的「新增...」來上傳圖片到圖庫")))
				.append($("<li style='margin:20px 0px;'/>").html(__("或者也可以點選任何他人的自訂表情新增到圖庫")))
				.append($("<li style='margin:20px 0px;'/>").html(__("如果仍需要顯示線上的自訂表情請按一下<a class='showMyEmotions'>這裡</a>")))
			)
			.find('a').css({'cursor' : 'pointer'}).end()
			.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
			.find('.showMyEmotions:not(:Event(click))').click( function(){
				$(this).parents('#emoticons_my_holder').find('.protect').hide();
				$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
				return false;
			 }).end();
		}, 200);
	})	
}
Gallery.prototype.generateGalleryTab = function(){

	var self = this;

	if(this.galleryTab) return;
	
	self.deprecateDefaultTab();

	var doc = document; 
	createStyle(doc, ".emoticon_selecter.delete.current{ background:red !important; }	.emoticon_selecter.delete.current a{ color:white !important;}");
	createStyle(doc, ".emoticon_selecter.rename.current{ background:green !important; }	.emoticon_selecter.rename.current a{ color:white !important;}");
	createStyle(doc, ".emoticon_selecter.backup.current{ background:#CF5A00 !important; }	.emoticon_selecter.backup.current a{ color:white !important;}");
	
	//add tab
	function switchTab(e){
		$(this).siblings().removeClass("current");
		$(this).addClass("current");
		
		return $(self.getPanel()).css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
	}

	this.galleryTab = $('<li>', {
		class: 'gallery',
		attr: {title: __('圖庫')},
		html: $('<a/>'),
		click: function(){
			switchTab.apply(this, arguments);
			//self.showBackupTab.apply(self, arguments);
			self.showStoredEmotions("#emoticons_show");
		}
	}).appendTo("#emoticons_tabs ul");

	this.backupTab = backupEmotionsTab = $('<li>', {
		class: 'backup',
		attr: {title: __('備份')},
		html: $('<a/>'),
		click: function(){
			switchTab.apply(this, arguments);
			self.showBackupTab.apply(self, arguments);
		}
	}).appendTo("#emoticons_tabs ul");

	this.settingTab = $('<li>', {
		class: 'setting',
		attr: {title: __('設定')},
		html: $('<a/>'),
		click: function(){
			var tab = switchTab.apply(this, arguments);
			//self.showSettingTab.apply(self, arguments);
			tab.empty().append($('<div>', {class:'comingsoon'}));
		}
	}).appendTo("#emoticons_tabs ul");


	$("<a class='switchWindowMode' style='float:right;height:9px;width:9px; margin:8px; padding:2px; background:url(http://emos.plurk.com/633e54d3723da4e8c1acc48288e952bc_w8_h8.gif) no-repeat; cursor:pointer;' title='切換視窗大小'></a>").toggle(function(){
		$(this).parents('#emoticon_selecter').addClass('large').draggable({ disabled: true });
		$('body').addClass('large_emoticon_selecter');
		$('.tableWrapper').scrollTop(0);
		self.lazyLoader.resize();

	},function(){
		$(this).parents('#emoticon_selecter').removeClass('large').draggable({ disabled: false });
		$('body').removeClass('large_emoticon_selecter');
		$('.tableWrapper').scrollTop(0);
		self.lazyLoader.resize();
	}).insertAfter("#emoticons_tabs a.bn_close");
	
	//Make it draggable
	$("#emoticon_selecter").draggable({attachTo: "#emoticons_tabs", ignore: "a, li", "cursor": "move" })
	createStyle(doc, "#emoticon_selecter.ondrag {opacity: 0.5;}");
	createStyle(doc, "#emoticon_selecter {-webkit-box-shadow: rgba(0, 0, 0, 0.8) 2px 2px 5px 0px;-webkit-transition: opacity 0.2s linear;}");
	//createStyle(doc, "#emoticon_selecter #emoticons_tabs {cursor: move ;}");	
}
Gallery.prototype.showStoredEmotions = function(target, actionMode){
	var self = this;
	var _static = arguments.callee;
	var target = self.getPanel();
		
	$('#emoticons_tabs li[id^=emo_]').click(function(){
		$('#emoticon_selecter #emoticon_holder_super_parent').show();
		$('#emoticons_show').hide();
	});
	
	if(actionMode != 'none') $('#emoticons_tabs li.gallery').siblings().removeClass('current').end().addClass('current');
	
	var help = $("<div style='padding:0 8px; color:#ccc;'>" +  __('Shift + 點選重新命名 / %s + 點選刪除').replace('%s', (isMac? "⌘" : "Ctrl")) +"</div>");
	var tableWrapper 	= $('.tableWrapper').length		? $('.tableWrapper')	:  $("<div class='tableWrapper' style='position:absolute;top:28px;right:0px;left:0px;bottom:0px;overflow-x:hidden;overflow-y:scroll;'> </div>").append(help);
	var filterWrapper 	= $('.filterWrapper').length	? $('.filterWrapper')	:  $("<div class='filterWrapper' style='position:absolute;right:0px;left:0px;top:0px;'></div>").css({'padding' : "3px 8px"});

	var totalPics = 0;
	
	getUserEmoticons(function(emotions){
		
		totalPics = emotions.length;
		
		var shown = $('table.plurkCustoms.gallery').length == 1;
		var modified = JSON.stringify($(target).data('emotions')) != JSON.stringify(emotions);
		
		console.log('shown', shown, 'modified', modified);
		
		if(shown && !modified){
			//console.log('not reload tab');
			$(target).find('.filter').focus()[0].select();
			if(typeof _static.scrollTop == 'number') $(tableWrapper).scrollTop(_static.scrollTop);
			return false;
		}
		
		$(target).data('emotions', emotions);
		
		$(target).unbind('scroll');
		
		var table = _static.table = $("<table class='flexible plurkCustoms gallery' />");
		var count = 0;
		var row ;

		for(var i in emotions){ 
			
			if(count%8==0) row = $("<tr/>").appendTo(table);
			count++;
			var td = $("<td/>").data('emotion', emotions[i]).css({'opacity': (emotions[i].alive ? '1.0 ' : '1.0')}).appendTo(row);
			
			emo = $('<a class="a_emoticon lazy" style="position:relative" />')
				.data('emotion', emotions[i])
				.attr('url', emotions[i].url)
				.attr('alt', emotions[i].keyword)
				.attr('title', emotions[i].keyword)
				.html($("<img data-src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />").hide())
				.appendTo(td);
			
			td.bind("click", function(e){
				var url = $(this).find('a').attr("url");
				var keyword = $(this).find('a').attr("alt");
				
				if(e.shiftKey){ //ShiftKey rename
					var e = $(this).find('a');
					var td = $(this);
					var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
					if(newKeyword && newKeyword != "" && newKeyword != keyword) {
						removeEmotion(url, function(){	//從自訂表情刪除
							deleteEmotion(keyword, function(emotions){	//從圖庫刪除
								saveEmotion(url, newKeyword, function(emotions){
									for(z in emotions) if(emotions[z].url == url) newKeyword = emotions[z].keyword; // peocessed keyword
									var emo = $(td).find('a').attr('alt', newKeyword).attr('title', newKeyword + " ("+__('已重新命名')+")").end().addClass('highlighted');
								})
							});
						});
						EmoticonsStorage.renameFavorite(url, newKeyword);
						//showCandidateEmotions(parent);
					}
				}else if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) ){ //ctrlKey delete
					var e = $(this).find('a');
					var ok = confirm(__("你確定要刪除 %s 嗎").replace('%s', keyword));
					if(ok) {
						removeEmotion(url, function(){
							deleteEmotion(keyword, function(emotions){
								$(e).animate({opacity: 0.1}, 500).unbind('click');
							});
						});
						EmoticonsStorage.removeFavorite(url);
						//showCandidateEmotions(parent);
					}
				}else{
					var e = new Emotion($(this).data('emotion'));
					EmoticonsStorage.addFavorite(e);
					gallery.operateEmoticonClick($(this).find('a')); return false; 
				}
			});
		}
		
		var footer = $("<div style='margin:3px 15px; color:#777; font-size:12px; cursor:default;'> "+ __('共 %d 張圖片').replace('%d', totalPics) +" <span style='float:right'> PlurkCustoms " + manifest('version') + " © 2011-2013 <a href='http://www.plurk.com/Lackneets' target='_blank'>Lackneets</a></span><div Style='color:#999; margin:5px 0;'>"+__('※請勿自行刪除重新安裝以免圖庫遺失，如需更新請重新啟動瀏覽器')+"</div></div>");
		 
		var buffer = $('<div/>').append(tableWrapper, filterWrapper).hide().appendTo('body');
		var filter = newFilter(table);
	
		tableWrapper.empty().append(help).append(table).append(footer);
		filterWrapper.empty().append(filter);
		
		$(target).css({'position': 'relative'});
		$(target).click(function(){ return false; });
		$(target).empty().prepend(filterWrapper).append(tableWrapper);

		self.lazyLoader = new LazyLoader(tableWrapper);


		function newFilter(table, defaultValue){

			if(typeof _static.filterValue == 'undefined') _static.filterValue = "";
			var delayTimer;
			var filter = $("<input class='filter' type='text' placeholder='"+ __('快速找到相關的表情') + "' />")
				.val(_static.filterValue)
				.keyup(function(){
					var val = $(this).val();
					val = val.replace(/^[\s　]+/, '').replace(/[\s　]+$/, '');
					
					_static.filterValue = val;
					
					var tds = $(table).find("td");

					//show all if empty
					if(val.length == 0) {
						//restore 
						tds.css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
						self.lazyLoader && self.lazyLoader.resize();
						return false;
					}
					
					var matched = tds.filter(function(){
						var alt = $(this).find('a').attr('alt').toLowerCase();
						return (alt.indexOf(val.toLowerCase()) != -1);
					});
					
					
					if(matched.length == 0 && val.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)){
						return false;
					}


						
					clearInterval(delayTimer);
					delayTimer = setTimeout(function(){
						//show matched
						matched.addClass('matched').css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
						
						//hide others
						var animated = tds.not(matched).filter(':visible').filter(':lt(25)').css({'max-width': '0', 'max-height': '0', 'opacity' : '0', 'display': ''})
						tds.not(matched).not(animated).attr('style', 'display:none !important;')
						//don't know why this not work
						//tds.not(matched).not(animated).css('display', 'none');
						
						//make first 25 hidden element animated next time
						tds.not(matched).not(":visible").filter(':lt(25)').css({'opacity' : '1', 'display': '', 'max-width': '0', 'max-height': '0'});
						setTimeout(function(){
							self.lazyLoader.resize();
						}, 300);
					}, 200)

				})
				.trigger('keyup')
				.css({width: '100%'})
				.click(function(){this.select();})
			return filter;
		}

	});
}
Gallery.prototype.reduceOnlineEmoticons = function(max){
	var self = this;
	//console.log('縮減線上表情', max);
	this.getRemovableEmoticons(function(removeable){
		//console.log(removeable);
		for(var i = max; i < removeable.length; i++){
			removeEmotion(removeable[i].url, function(){
			});
		}
	});
}
Gallery.prototype.getRemovableEmoticons = function(callback){
	var self = this;
	loadEmotions(function(emotions){
		emotions.reverse();

		var aliveCount = 0;
		//可移除清單
		var removeable = emotions.slice(0);
		var favEmotions = EmoticonsStorage.getFavorites();

		for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, self.emotionUplaoded) != -1) aliveCount++;

		//加入常用作為排序參照
		for(var i in removeable) {
			removeable[i].favorite = 0;
			for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
				removeable[i].favorite = favEmotions[f].favorite;
				break;
			}
		}

		function sortFavorite(a, b){ return b.favorite - a.favorite; }
		removeable.sort(sortFavorite);

		var _removeable = []
		for(var i in removeable) { 
			//如果正在使用則不可移除
			if($.inArray(removeable[i].keyword, self.emotionUsed) != -1) continue;
			//不在線上 && 未上傳
			if(removeable[i].alive != true && $.inArray(removeable[i].keyword, self.emotionUplaoded) == -1) continue;
			//已移除
			if($.inArray(removeable[i].keyword, self.emotionRemoved) != -1) continue;
			
			_removeable.push(removeable[i]);
			//console.log(removeable[i].keyword, removeable[i].favorite); 
		}
		removeable = _removeable; delete _removeable;

		callback && callback(removeable);
	})
}

var gallery = new Gallery();