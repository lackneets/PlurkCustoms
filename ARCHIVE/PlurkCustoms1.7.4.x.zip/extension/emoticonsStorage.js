EmoticonsStorage = function(){};
EmoticonsStorage.getFavorites = function(){
	var fav = localStorage.getItem("emotions_favorites");
	try{ fav = JSON.parse(fav); }catch(e){ fav = new Array();; }
	if(typeof fav != 'object' && typeof fav != 'array') fav = new Array();
	if(fav == null) fav = new Array();
	return arrayClone(fav);
}
EmoticonsStorage.addFavorite = function(emotion){
	if(! typeof emotion == 'Emotion') throw("EmoticonsStorage.addFavorite(): Emotion expected");
	
	var emotions = this.getFavorites();
	emotions.sort(sortFavorite);
	
	
	var high = (emotions.length > 0) ? emotions[0].favorite : 0;
	
	// Find the same
	var exist;
	for(var i in emotions) if(emotions[i].hash_id == emotion.hash_id){
		emotion = emotions[i];
		exist = true;
		break;
	}
	if(! exist ) emotions.push(emotion);
	
	function stdDev(a){
		function mean(a){ var sum=eval(a.join("+")); return sum/a.length; }
		var m=mean(a);
		var sum=0;
		var l=a.length;
		for(var i=0;i<l;i++){
			var dev=a[i]-m;
			sum+=(dev*dev);
		}
		return Math.sqrt(sum/(l-1));
	}
	
	
	function array_mid(arr, attr){var s=0; for(i in arr) s+= arr[i][attr]; return s/arr.length; }

	if( typeof emotion.favorite != 'number') emotion.favorite = 0;

	if(emotion.hash_id == emotions[0].hash_id){
		//已經是第一個
	} else if(emotion.favorite == emotions[0].favorite){
		//最高權值但不是第一個
		emotion.favorite += 2;
		
	} else if(emotion.favorite < 256){
		function fav_arr(emotions){  var e = []; for(i in emotions) e.push(emotions[i]['favorite']); return e; };
		
		var mid = Math.ceil(array_mid(emotions, 'favorite')); if(mid < 2) mid = 2;
		var max = Math.max.apply( Math, fav_arr(emotions) );
		var min = Math.min.apply( Math, fav_arr(emotions) );
		var std = stdDev(fav_arr(emotions));
		var inc = Math.ceil(Math.max(min, 1) + std/4);
		//emotion.favorite += inc;
		if(emotion.favorite < mid)  emotion.favorite += inc;
		else emotion.favorite += Math.ceil(Math.max(std/4, 2)) ;
		
	} else {
		for(i in emotions){
			emotions[i].favorite--;
			if(emotions[i].favorite > 255) emotions[i].favorite = 255;
		}
	}
	
	emotion.favorite = Math.min(255, Math.ceil(emotion.favorite));
	
	emotions.sort(sortFavorite);
	
	if(emotions.length > 200) emotions.splice(emotions.length-200, emotions.length); 
	
	function sortFavorite(a, b){ return b.favorite - a.favorite; }
	
	localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
	
}
EmoticonsStorage.renameFavorite = function(url, keyword){
	var emotions = this.getFavorites();
	for(i in emotions) if(emotions[i].url == url) emotions[i].keyword = keyword;
	localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
}

EmoticonsStorage.removeFavorite = function(url){
	var emotions = this.getFavorites();
	for(i in emotions) if(emotions[i].url == url) emotions.splice(i, 1);
	localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
}
