
	function trace(info){
		chrome.tabs.getSelected(null, function(tab) {
			alert(info);
			console.log('Trace: ', info);
		});
	}


	chrome.extension.onRequest.addListener( 
		function(request, sender, sendResponse) { 
			console.log('request', request);
			if(request.saveEmotions){
				var type = request.type ? request.type : 'merge';
			//	console.log("saveEmotions:" + type);
				saveEmotions(request.emotions, type , function(emotions){
					sendResponse(emotions);
				});
			}

			if(request.replaceEmotions){
			//	console.log("replaceEmotions");
				saveEmotions(request.emotions, "replace" , function(emotions){
					sendResponse(emotions);
				});
				
			}
			
			if(request.saveEmotion){
			//	console.log("save single emotion");
				saveEmotion(request.url, request.keyword, function(emotions){
					console.log("emotion stored");
					sendResponse(emotions);
				});
				
			}
			if(request.deleteEmotion){
			//	console.log("delete single emotion");
				deleteEmotion(request.keyword, function(emotions){
					console.log("emotion deleted");
					sendResponse(emotions);
				});
				
			}
			if(request.loadEmotions){
				
				loadEmotions(function(emotions){
					console.log('sendResponse(emotions)', emotions);
					sendResponse(emotions);
				});
			}
			
			if(request.isAlive){
				console.log('request.isAlive', request);
				loadEmotions(function(stored_emotions){
					for(var s in stored_emotions){  
						if(request.keyword == stored_emotions[s].keyword && stored_emotions[s].alive == true){
							console.log('sendResponse', true);
							sendResponse(true);
							return ;
						}
					 }
					 console.log('sendResponse', false);
					 sendResponse(false);
					 return ;
				});
			}

	});
	
	function saveEmotion(url, keyword, callback){
		loadEmotions(function(emotions){
			var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
			emotion = {keyword: keyword, url: url, hash_id: hash_id, alive: false};
			emotions.push(emotion);
			saveEmotions(emotions, "merge", callback);
		});
	}
	
	function deleteEmotion(keyword, callback){
		loadEmotions(function(emotions){
			var newEmotions = [];
			for(var e in emotions){
				if(emotions[e].keyword != keyword) newEmotions.push(emotions[e]);
			}
			saveEmotions(newEmotions, "replace", callback);
		});
	}
	
	function urlDecode(str){
	    str=str.replace(new RegExp('\\+','g'),' ');
	    return unescape(str);
	}
	function urlEncode(str){
	    str=escape(str);
	    str=str.replace(new RegExp('\\+','g'),'%2B');
	    return str.replace(new RegExp('%20','g'),'+');
	}
	
	
	
	chrome.tabs.onRemoved.addListener(function(windowId) {
		bufferedEmotions = null;
	});
	
	
	function fixEmotionsStructure(emotions){
		var cleanEmoticons = new Array();
		var hashes = new Array();
		/*function sortByKeywordAsc(a, b){ return (a.keyword < b.keyword ? 1 : (a.keyword > b.keyword ? -1 : 0)); }
		function sortByKeywordDesc(a, b){ return (a.keyword > b.keyword ? 1 : (a.keyword < b.keyword ? -1 : 0)); }
		emotions.sort(sortByKeywordDesc);
		console.log('desc srot emotions', emotions);*/
		if(!emotions.length) return new Array();
		if(! typeof emotions.push == 'function') return new Array();
		for(i=0; i<emotions.length; i++){
			if(!emotions[i] || !emotions[i].keyword || !emotions[i].url) console.log('an unexpected item found', emotions[i] , ' in emotions['+i+']');
			if(typeof emotions[i].keyword != 'string' ) emotions.splice(i, 1) & i--;
			else if(typeof emotions[i].url != 'string' ) emotions.splice(i, 1) & i--;
		}
		//殺掉雙胞胎表情
		for(i=0; i<emotions.length; i++){ 
			if(hashes.indexOf(emotions[i].hash_id) == -1) cleanEmoticons.push(emotions[i]);
			hashes.push(emotions[i].hash_id)
		}
		return cleanEmoticons;
	}
	
	var bufferedEmotions;
	
	function loadEmotions(callback){
		
		console.log('loadEmotions');
		
		var emotions;
		
		if(bufferedEmotions){
			console.log('bookmark loaded from buffer');
			callback(arrayClone(bufferedEmotions));
			return;
		}
		
		if (typeof(localStorage) == "undefined" ) {
			trace("Your browser does not support HTML5 localStorage. Try upgrading.");
		} else {
			try {
				emotions = localStorage.getItem("plurkCustoms_emotions");
				try{
					emotions = JSON.parse(emotions);
					bufferedEmotions = arrayClone(fixEmotionsStructure(emotions));
					if(typeof emotions[0].url != 'undefined') return callback(arrayClone(bufferedEmotions));					
				}catch(e) {
					emotions = [];
					bufferedEmotions = [];
					return callback(bufferedEmotions);
				}
				
			} catch (e) {
				trace("cannot load emotions from localstorage");
			}
		}
		
		console.log('ckp 2', emotions);
		
		
		/*
		//Old way load from bookmark
		chrome.bookmarks.search("plurkCustoms_data", function(bookmark){
			bookmark = (bookmark.length) ? bookmark[0] : null;
			
			console.log('bookmark loaded from plurkCustoms_data');
			if(bookmark){
				try{
					var bookmark = $.parseJSON(urlDecode(bookmark.url).toString().replace("http://plurkcustoms/?data=", "") )
					bufferedEmotions = arrayClone(fixEmotionsStructure(bookmark));
					callback(bufferedEmotions);
				}catch(e){
					chrome.tabs.getSelected(null, function(tab) {
						alert("糟糕！圖庫已經損毀無法載入")
					})
					bufferedEmotions = [];
					callback(arrayClone([]));
				}
			} else callback(arrayClone([]));
		})*/
		
	} // end loadEmotions
	
	function arrayClone(arr){
		if(typeof arr == 'object') return arr.slice(0);
		else return arr;
	}
	
	function saveEmotions(emotions, type, callback){
		var plurkCustoms;
		
		loadEmotions( function(bookmark){

			try{
				
				stored_emotions = {};
				original_emotions = {};
				
				if(bookmark){
					original_emotions = arrayClone(bookmark);
					stored_emotions = arrayClone(bookmark);
				}
				
			
				function resolveConflict(keyword, emotions){	// name => name_1
					var maxId = 0;
					if(keyword.match(/(.+)_(\d+)$/)) keyword = keyword.match(/(.+)_(\d+)$/)[1];
					for(var e in emotions){
						if(emotions[e].keyword.indexOf(keyword) == 0){
							id = emotions[e].keyword.replace(keyword, '').match(/_(\d+)$/);
							if(id && id[1] > maxId){
								maxId = parseInt(id[1]);
							}
						}
					}
					console.log("conflict keyword resolved as " + keyword + "_" + (maxId + 1));
					return keyword + "_" + (maxId + 1);
				}
				
				
				if(type == "merge" || type == "onlineMerge"){
				
					//merge	
					if(type == "onlineMerge") for(var s in stored_emotions){  stored_emotions[s].alive = false;  }

					for(var e in emotions){
						var exist = false;
											
						for(var s in stored_emotions){ 


						
							//相同名稱衝突
							if(emotions[e].keyword == stored_emotions[s].keyword){ //conflict
								exist = true; 
								if(emotions[e].hash_id == stored_emotions[s].hash_id){	// 完全符合
									stored_emotions[s] = emotions[e];
									if(type == "onlineMerge") stored_emotions[s].alive = true; // 標記為在線上	
									else stored_emotions[s].alive = (typeof emotions[e].alive == 'undefined') ? stored_emotions[s].alive : emotions[e].alive;
								}else{	// 撞名的不同圖片
									emotions[e].keyword = resolveConflict(emotions[e].keyword, stored_emotions);
									emotions[e].alive = false; 
									stored_emotions.push(emotions[e]);
									
								}
								break;
							} 
							
							//不撞名的相同圖片
							if(emotions[e].hash_id == stored_emotions[s].hash_id){ 
								console.log('find exist from online', emotions[e].hash_id, emotions[e].keyword, stored_emotions[s].keyword);
								// do not merge
								stored_emotions[s].alive = false;
								exist = true;
								break; 
							}
							
						}
						if(exist) continue;
						
						
						// new added
						console.log('new emotion merged:' + emotions[e].keyword );
						if(type == "onlineMerge") emotions[e].alive = true; 
						else emotions[e].alive = false; 
						stored_emotions.push(emotions[e]);
					}
				}else{ // type == replace
					console.log('stored_emotions = emotions', type);
					stored_emotions = emotions;
				}
				function trim(str){ return str.replace(/^\s*/ig, '').replace(/\s*$/ig, '').replace(/[\n\r]*$/ig, '').replace(/^[\n\r]*$/ig, '');}
				
				//update
				
				//resolveConflict
				for(var s1 = 0 ; s1 < stored_emotions.length; s1++){
					for(var s2 = 0 ; s2 < stored_emotions.length; s2++){
					
						if(s2 <= s1) continue;
						
						//相同圖片
						if(stored_emotions[s1].url == stored_emotions[s2].url){
							stored_emotions.splice(s2, 1); 
							s1--; break;
						}
						//相同名稱
						if(stored_emotions[s1].keyword == stored_emotions[s2].keyword){ 
							stored_emotions[s1].keyword = resolveConflict(stored_emotions[s1].keyword, stored_emotions);
							stored_emotions[s1].alive = false;
							continue;
						}
					} 
				} 
				
				//SORT
				stored_emotions.sort(function(a, b){
					return (a.keyword > b.keyword) ? 1 : -1;
				});
				
	
				//Save to localstorage
				if (typeof(localStorage) == "undefined" ) {
					trace("Your browser does not support HTML5 localStorage. Try upgrading.");
				} else {
					try {
						localStorage.setItem("plurkCustoms_emotions", JSON.stringify(stored_emotions)); //saves to the database, “key”, “value”
						console.log('stored to localsotrage');
					} catch (e) {
						if (e == QUOTA_EXCEEDED_ERR) {
							trace("Quota exceeded!"); // data wasn’t successfully saved due to quota exceed so throw an error
						}else{
							trace("無法儲存表情至 local storage")
						}
					}
				}
				bufferedEmotions = arrayClone(fixEmotionsStructure(stored_emotions));
				
				
				// prepare sync to storage
				/*
				function lengthInPageEncoding(s){var a=document.createElement('A');a.href='#'+s;var b=a.href;b=b.substring(b.indexOf('#')+1);var m=b.match(/%[0-9a-f]{2}/g);return b.length-(m?m.length*2:0)}
				function lzw_encode(s){var dict={};var data=(s+"").split("");var out=[];var currChar;var phrase=data[0];var code=256;for(var i=1;i<data.length;i++){currChar=data[i];if(dict[phrase+currChar]!=null){phrase+=currChar}else{out.push(phrase.length>1?dict[phrase]:phrase.charCodeAt(0));dict[phrase+currChar]=code;code++;phrase=currChar}}out.push(phrase.length>1?dict[phrase]:phrase.charCodeAt(0));for(var i=0;i<out.length;i++){out[i]=String.fromCharCode(out[i])}return out.join("")}
				function lzw_decode(s){var dict={};var data=(s+"").split("");var currChar=data[0];var oldPhrase=currChar;var out=[currChar];var code=256;var phrase;for(var i=1;i<data.length;i++){var currCode=data[i].charCodeAt(0);if(currCode<256){phrase=data[i]}else{phrase=dict[currCode]?dict[currCode]:(oldPhrase+currChar)}out.push(phrase);currChar=phrase.charAt(0);dict[code]=oldPhrase+currChar;code++;oldPhrase=phrase}return out.join("")}				
				function utf8_to_b64(str){return window.btoa(unescape(encodeURIComponent(str)))}
				function b64_to_utf8(str){return decodeURIComponent(escape(window.atob(str)))}
				function getUTF8Length(string){var utf8length=0;for(var n=0;n<string.length;n++){var c=string.charCodeAt(n);if(c<128){utf8length++}else if((c>127)&&(c<2048)){utf8length=utf8length+2}else{utf8length=utf8length+3}}return utf8length}
				function HuffmanEncoding(a){this.str=a;var b={};for(var i=0;i<a.length;i++){if(a[i]in b){b[a[i]]++}else{b[a[i]]=1}}var c=new BinaryHeap(function(x){return x[0]});for(var d in b){c.push([b[d],d])}while(c.size()>1){var e=c.pop();var f=c.pop();c.push([e[0]+f[0],[e[1],f[1]]])}var g=c.pop();this.encoding={};this._generate_encoding(g[1],"");this.encoded_string="";for(var i=0;i<this.str.length;i++){this.encoded_string+=this.encoding[a[i]]}}
				HuffmanEncoding.prototype._generate_encoding=function(a,b){if(a instanceof Array){this._generate_encoding(a[0],b+"0");this._generate_encoding(a[1],b+"1")}else{this.encoding[a]=b}}
				HuffmanEncoding.prototype.inspect_encoding=function(){for(var a in this.encoding){print("'"+a+"': "+this.encoding[a])}}
				HuffmanEncoding.prototype.decode=function(a){var b={};for(var c in this.encoding){b[this.encoding[c]]=c}var d="";var e=0;while(e<a.length){var f="";while(!(f in b)){f+=a[e];e++}d+=b[f]}return d}

				//split for chrome.storage.sync
				
				
				var modified = (original_emotions.length != stored_emotions.length);
				if(!modified) for(var i in original_emotions){
					if(original_emotions[i].keyword != stored_emotions[i].keyword){ modified = true; break;}
					if(original_emotions[i].url != stored_emotions[i].url){ modified = true; break;}
				}
				
				var items = prepareChromeSync(stored_emotions);
				console.log('compressed', items);
				console.log('parsed', restoreFromChromeSync(items));
				
				function prepareChromeSync(stored_emotions){
					var newobj = JSON.parse(JSON.stringify(stored_emotions));
					for(var i in newobj){
						delete newobj[i].alive;
						delete newobj[i].hash_id;
						newobj[i].url = newobj[i].url.replace('http://emos.plurk.com/', '');
					} 
					var compressed_string = lzw_encode(utf8_to_b64(JSON.stringify(newobj))); 
					
					var huff = new HuffmanEncoding(JSON.stringify(newobj));
					var compressed_string_huff = huff.encoded_string; 
					
					console.log('compressed size:' , compressed_string.length, getUTF8Length(compressed_string));
					console.log('compressed size: (Huffman)' , compressed_string_huff.length, getUTF8Length(compressed_string_huff), compressed_string_huff);
					
					var items = [], pos=0, total = compressed_string.length, limit = 200;
					while(pos < total){
						len = 200;
						while(getUTF8Length(compressed_string.substr(pos, len+1)) <= limit && (pos + len) < total) len++;
						var sliced = compressed_string.substr(pos, len);
						items.push(sliced);
						pos+=len;
					}
					return items;
				}
				function restoreFromChromeSync(items){
					var emoticons = JSON.parse(b64_to_utf8(lzw_decode(items.join(''))));
					for(var i in emoticons){
						emoticons[i].url = 'http://emos.plurk.com/' + emoticons[i].url;
						emoticons[i].hash_id = emoticons[i].url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
						emoticons[i].alive = false;
					}
					return emoticons;
				}
				
				var objItems = {};
				for(var i in items) objItems['data_' + i] = items[i];
				
				chrome.storage.sync.set(objItems, function() {
					console.log('stored into sync');
				});
				
				chrome.storage.sync.get('data_0', function(data) {
					console.log(data)
				});
				
				chrome.storage.sync.get('length', function(length) {
					console.log('chrome.storage.sync.get', length);
					if(!length) {
						console.log('no data in sync');
						
						chrome.storage.sync.set(objItems, function() {
							console.log('stored into sync');
						});
						
						return;
					}
					length = parseInt(length);
					var items = [], waits = length;
					for(var i=0; i < length; i++){
						(function(i){
							chrome.storage.sync.get(i, function(data) {
								items[i] = data;
								waits--;
								if(waits == 0) loaded(items);
							});
						})(i);
					}
					function loaded(items){
						console.log('loaded', restoreFromChromeSync(items));
					}
				});*/
				
				// end backup
				
				callback(arrayClone(stored_emotions));
				
			}catch(e){
				trace(e);
			}
				
		});	//End loadEmotions()
		
	}	//End saveEmotions
