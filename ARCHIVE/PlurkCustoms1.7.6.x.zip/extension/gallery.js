var Gallery = function(){
	this.init();
}

Gallery.prototype.lazyLoader = null;
Gallery.prototype.galleryTab = null;
Gallery.prototype.emoticonsPanel = null;

Gallery.prototype.galleryFilterValue = '';
Gallery.prototype.galleryTable = null;

Gallery.prototype.tabWrapperGallery = null;
Gallery.prototype.tabWrapperBackup = null;
Gallery.prototype.tabWrapperSetting = null;

Gallery.prototype.lastInputFocused = null;
Gallery.prototype.panelScrollTop = 0;

Gallery.prototype.emotionUsed = [];
Gallery.prototype.emotionUplaoded = [];
Gallery.prototype.emotionRemoved = [];
Gallery.prototype.init = function() { 
	var	self = this;
	$("#main_poster .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big');
	});
	$(".mini_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_small');
	});
	
	$(".cmp_emoticon_on, .cmp_emoticon_off, #main_poster .emoticon_selecter_img_on, #main_poster .emoticon_selecter_img_off").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big');
	});
	$(".cmp_emoticon_mini_on, .cmp_emoticon_mini_off, .mini_form .emoticon_selecter_img_on, .mini_form .emoticon_selecter_img_off").live("click",function(){
		self.lastInputFocused = document.getElementById('input_small');
	});
	
	$(".private_plurk_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big_private');
	});
	$(".private_plurk_form .smily_holder img").live("click",function(){
		self.lastInputFocused = document.getElementById('input_big_private');
	});
	$(".smily_holder img, .cmp_emoticon_off, .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		self.generateGalleryTab.apply(gallery, arguments);
	} );
	$(".smily_holder img, .cmp_emoticon_off,  .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		if($(".emoticon_selecter.plurkCustoms.delete.current").length) self.showGalleryTab();
		else if($(".emoticon_selecter.plurkCustoms.current").length) self.showGalleryTab();
	});
}
Gallery.prototype.operateEmoticonClick = function(smile, callback) { 

	var self = this;

	var keyword = $(smile).attr("alt");;
	var url = smile.find('img').attr('src');
	var match = $(smile).attr("match"); if(! match ) match = 0;
	var uploaded = ($.inArray($(smile).attr("alt"), self.emotionUplaoded) != -1);
	var removed = ($.inArray($(smile).attr("alt"), self.emotionRemoved) != -1);
			
	if( !uploaded || removed ){ isAlive(keyword, function(isAlive){
		if(!isAlive || removed ){ 
			
			//$(smile).find('img').hide().end().append($("<span style='color:red;text-decoration:none;font-size:12px!important;'>"+ __('上傳中...') +"</span>"));

			$(smile).find('img').hide().end().append($("<img/>", {
				class: 'loading',
				src: chrome.extension.getURL('images/loading-orange.gif')
			}));
			
			loadEmotions(function(emotions){
				emotions.reverse();
				
				
				var aliveCount = 0;
				for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, self.emotionUplaoded) != -1) aliveCount++;
				
				//可移除清單
				var removeable = emotions.slice(0);
				
				//加入常用作為排序參照
				var favEmotions = EmoticonsStorage.getFavorites();
				for(var i in removeable) {
					removeable[i].favorite = 0;
					for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
						removeable[i].favorite = favEmotions[f].favorite;
						break;
					}
				}
				function sortFavorite(a, b){ return b.favorite - a.favorite; }
				removeable.sort(sortFavorite);
				
				var _removeable = []
				for(var i in removeable) { 
					//如果正在使用則不可移除
					if($.inArray(removeable[i].keyword, self.emotionUsed) != -1) continue;
					//不在線上 && 未上傳
					if(removeable[i].alive != true && $.inArray(removeable[i].keyword, self.emotionUplaoded) == -1) continue;
					//已移除
					if($.inArray(removeable[i].keyword, self.emotionRemoved) != -1) continue;
					
					_removeable.push(removeable[i]);
					//console.log(removeable[i].keyword, removeable[i].favorite); 
				}
				removeable = _removeable; delete _removeable;
				
				
				var toRemove ;

				if(aliveCount > 55 && removeable) toRemove = removeable.pop();
				
				function add(){
					
					addEmotion(url, keyword, function(emotions){
						if((i = $.inArray(keyword, self.emotionRemoved)) != -1) self.emotionRemoved.splice(i, 1); //從已刪除移除
						if((i = $.inArray(keyword, self.emotionUplaoded)) == -1) self.emotionUplaoded.push(keyword);	//列入已上傳
						//if(self.emotionUplaoded.length > 50) self.emotionUplaoded.splice(0, self.emotionUplaoded.length-50); //保留最後50個已上傳
						$(smile).find('img').show().end().find('.loading').remove();
						self.useEmoticon(keyword, match);
						if(typeof callback == 'function') callback();
					});
				}
				
				if(toRemove && toRemove.url){
					removeEmotion(toRemove.url, function(emotions){
						if((i = $.inArray(toRemove.keyword, self.emotionUplaoded)) != -1) self.emotionUplaoded.splice(i, 1);	//從已上傳移除
						if((i = $.inArray(toRemove.keyword, self.emotionRemoved)) == -1) self.emotionRemoved.push(toRemove.keyword);	//列入已刪除
						add();if(typeof callback == 'function') callback();
					});
				} else {
					add();if(typeof callback == 'function') callback();
				}
			})
			
		}else{
			self.useEmoticon(keyword, match);if(typeof callback == 'function') callback();
		}
	})
	}else{ self.useEmoticon(keyword, match);if(typeof callback == 'function') callback(); }
	
	if((i = $.inArray(keyword, self.emotionUsed)) != -1) self.emotionUsed[i]= self.emotionUsed.splice(self.emotionUsed.length-1, 1, self.emotionUsed[i])[0]; //swap to last
	if(self.emotionUsed.length > 50) self.emotionUsed.splice(0, self.emotionUsed.length-50); //保留最後50個使用紀錄
	if($.inArray($(smile).attr("alt"), self.emotionUsed) == -1) self.emotionUsed.push( $(smile).attr("alt") );
	
	console.log('self.emotionUsed', self.emotionUsed);
	console.log('self.emotionUplaoded', self.emotionUplaoded)
	console.log('self.emotionRemoved', self.emotionRemoved)
}
Gallery.prototype.useEmoticon = function(keyword, backward){
	var self = this;
	console.log(keyword, backward, this.lastInputFocused)
	if(!backward) backward = 0;
	if ( !gallery.lastInputFocused  ) gallery.lastInputFocused = document.getElementById('input_big');
	
	var s = gallery.lastInputFocused.selectionStart;
	
	if(backward) gallery.lastInputFocused.value = gallery.lastInputFocused.value.substr(0, gallery.lastInputFocused.selectionStart-backward) + gallery.lastInputFocused.value.substr(gallery.lastInputFocused.selectionStart, gallery.lastInputFocused.value.length)
	if(backward) s = s-backward;
	var t = gallery.lastInputFocused.value;
	var k = "[" + keyword + "]";
	var x = t.substr(0, s) + k + t.substr(s, t.length);
	
	gallery.lastInputFocused.value = x;
	gallery.lastInputFocused.setSelectionRange(s + k.length, s + k.length);
}
Gallery.prototype.useDefaultSmile = function(keyword, backward){
	var self = this;
	if(!backward) backward = 0;
	if ( !gallery.lastInputFocused  ) gallery.lastInputFocused = document.getElementById('input_big');
	
	var s = gallery.lastInputFocused.selectionStart;
	
	if(backward) gallery.lastInputFocused.value = gallery.lastInputFocused.value.substr(0, gallery.lastInputFocused.selectionStart-backward) + gallery.lastInputFocused.value.substr(gallery.lastInputFocused.selectionStart, gallery.lastInputFocused.value.length)
	if(backward) s = s-backward;
	var t = gallery.lastInputFocused.value;
	var k = keyword ;
	var x = t.substr(0, s) + k + t.substr(s, t.length);
	
	gallery.lastInputFocused.value = x;
	gallery.lastInputFocused.setSelectionRange(s + k.length, s + k.length);
}
Gallery.prototype.createNewTab = function(){
}
Gallery.prototype.syncFavorites = function(){

	if(NProgress.status){
		alert(__('忙碌中請稍後再試'));
		return false;
	}

	NProgress.configure({ 
		minimum: 0.005 ,
		template: '<div class="bar sync" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon"></div></div>'
	});
	NProgress.set(0.0);	
	NProgress.start();	


	getOnlineEmoticons(function(onlineEmoticons) {
		//console.log(22, onlineEmoticons);
		var favorites = EmoticonsStorage.getFavorites();

		var pool = {};
		var toRemove = [];
		var toUpload = [];

		favorites.length = 50;


		_.each(onlineEmoticons, function(online){
			if(!_.findWhere(favorites, {hash_id: online.hash_id, keyword: online.keyword})){
				toRemove.push(online);
			}
		});

		_.each(favorites, function(favorite){
			if(!_.findWhere(onlineEmoticons, {hash_id: favorite.hash_id, keyword: favorite.keyword})){
				toUpload.push(favorite);
			}
		});


		var process = toRemove.length + toUpload.length;
		var finished = 0;
		var progress = 0;

		if(process == 0){
			NProgress.done(true);
		}

		function removePhase(){
			_.each(toRemove, function(emo, i){
				setTimeout(function(){
					removeEmotion(emo.url, proceed);
				}, i*120);
			});			
		}
		function uploadPhase(){
			_.each(toUpload, function(emo, i){
				setTimeout(function(){
					addEmotion(emo.url, emo.keyword, proceed);
				}, i*120);
			});			
		}

		function proceed(){
			finished++;
			//console.log(finished, process);
			if(finished == toRemove.length){
				uploadPhase();
			}
			if(finished == process){
				doOnlineMerge();
				NProgress.done(true);
			}else{
				var p = (finished / process);
				if(p - progress > 0.02) {
					progress = p;
					NProgress.set(p);
				}
			}
		}

		if(toRemove.length){
			removePhase();
		}else{
			uploadPhase();
		}

	});
}
Gallery.prototype.showGalleryTab = function(){

	var self = this;
	var target = self.getPanel();

	$('#emoticons_tabs li.gallery').siblings().removeClass('current').end().addClass('current');
		

	getUserEmoticons(function(emotions){
		
		var shown = self.tabWrapperGallery;
		var modified = Boolean(shown) && (JSON.stringify(emotions) != shown.json);

		if(shown && !modified){
			self.loading.hide();
			self.tabWrapperGallery.show();
			self.tabWrapperGallery.restoreScrollTop();
			self.tabWrapperGallery.focusFilter();
			return false;
		}
		
		self.generateGalleryTable(emotions).appendTo(target);
		self.loading.hide();
		
	});
}
Gallery.prototype.showSettingTab = function(){
	var self = this;

	if(self.tabWrapperSetting){
		self.tabWrapperSetting.show();
		return;
	}

	var footer = $('<div/>', { class: 'footer',
		css: { 'text-align': 'right' },
		html: [
			"PlurkCustoms " + manifest('version') + " © 2011-2013 ",
			$('<a>',{
				text: 'Lackneets',
				attr: {href: 'http://www.plurk.com/Lackneets', target : '_blank'}
			})
		]
	});

	var tabWrapper = self.tabWrapperSetting || $('<div/>', { class: 'tabWrapper setting',
		//html : $('<div>', {class:'comingsoon'})
		html: [$('<div>', { class: 'controls',
			html : [

				$('<div>', { class: 'item audio',
					attr: { title: __('更換通知音效') },
					click: function(){
						localScript('notificationSound()');
						alert('功能開發中，請期待');
					}
				}),
				$('<div>', { class: 'item sync',
					attr: { title: __('同步處理線上表情') },
					click: function(){
						//alert('功能開發中，請期待');
						self.syncFavorites();
					}
				}),			
				$('<div>', { class: 'item pack', 
					attr: { title: __('打包下載所有表情圖案') },
					click: function(){
						if(downloadEmoticons){
							downloadEmoticons();
						}else{
							alert(__('找不到套件'));
						}
					}
				}),
				$('<div>', { class: 'item backup', 
					attr: { title: __('雲端備份到噗浪 BETA') },
					click: function(){
						GalleryBackup.cloudBackup();
					}
				}),				


				//$('<div>', { class: 'item none' , click: function(){ GalleryBackup.test(); }}),
				$('<div>', { class: 'item none' }),
				$('<div>', { class: 'item none' }),
				$('<div>', { class: 'item none' }),			

				$('<div>', { class: 'item author',
					attr: { title: __('作者：小耀博士') },
					click: function(){
						window.open('http://www.plurk.com/Lackneets', '_author');
						return false;
					}
				}),
			]
		}),
		footer
		]
	}).appendTo(self.getPanel()).show();
	self.loading.hide();
}
Gallery.prototype.showBackupTab = function(){
	var self = this;
	//self.showGalleryTab("#emoticons_show", 'none');

	if(self.tabWrapperBackup){
		self.tabWrapperBackup.remove();
		delete self.tabWrapperBackup;
	}
	
	loadEmotions(function(emotions){
		
		var json = JSON.stringify(emotions);
		var b64 = utf8_to_b64( json );
		
		//$("#emoticons_show").empty();
		var tabWrapper = self.tabWrapperBackup = $('<div/>', { class: 'tabWrapper backup'

		}).appendTo(self.emoticonsPanel);

		var exportFile = $('<a/>', { class: 'icon_export',
			text: __("%d 張圖片").replace('%d', emotions.length),
			attr: {
				title: __("按右鍵另存此檔案"),
				href: "data:text/plain;charset=utf-8; base64," + b64
			}
		});

		var method = $('<select/>', { class: 'method',
			html: [
				'<option value="replace">'+__('取代模式')+'</option>',
				'<option value="merge">'+__('合併模式')+'</option>'
			]
		});

		var dropZone = $('<div/>', { class: 'dropZone',
			html: [
				exportFile,
				$('<p/>', { text: __('備份方式：將上方的檔案圖示拖曳至桌面儲存，或點選右鍵另存') }),
				$('<p/>', { text: __('還原方式：將備份的檔案拖曳到虛線框中，而還原有兩種模式') }),
				$('<p/>', { text: __('取代模式：圖庫將被完全刪除並置換成檔案的內容') }),
				$('<p/>', { text: __('合併模式：從備份的檔案中補足圖庫中缺少的圖片') }),
				method
			],
			click: function(e){
				e.stopPropagation();
				e.preventDefault();
				return false;
			}
		}).appendTo(tabWrapper)
		
		
		function handleFileSelect(evt) {
			
		    evt.stopPropagation();
		    evt.preventDefault();

		    var files = evt.dataTransfer.files || evt.target.files; 
		    
		    for (var i = 0, f; f = files[i]; i++) {
		    	
				var reader = new FileReader();
				reader.onload = (function(theFile) {
					return function(e) {
						var data = e.target.result;
						var emotions = {};
						if(data.indexOf('[InternetShortcut]') == 0){ 
							try{
								b64 = data.replace(/[\n\r]*/ig, '').replace('[InternetShortcut]', '').replace('URL=data:text/plain;charset=utf-8; base64,', '');
								emotions = JSON.parse(b64_to_utf8(b64));
							}catch(e){
								console.log(e);
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}else{
							try{
								emotions = JSON.parse(data);
							}catch(e){
								console.log(e);
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}
						
						for(var i=0, e ; e = emotions[i]; i++ ){
							if((e.url && e.keyword && e.hash_id) == false) {
								alert("這不是有效的圖庫備份檔案！")
								return false;
							}
						}
						
						if(method.val() == 'replace'){
							var con = confirm("警告！你確定要取代目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
							if(con) replaceEmotions(emotions, function(emotions){
								for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
								getUserEmoticons();
								alert('圖庫置換成功！');
								getUserEmoticons.emotions = null;
								backupEmotionsTab.trigger('click');
							})
						}else{
							var con = confirm("警告！你確定要合併至目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
							if(con) saveEmotions(emotions, function(emotions){
								for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
								getUserEmoticons();
								alert('圖庫合併成功！');
								getUserEmoticons.emotions = null;
								backupEmotionsTab.trigger('click');
							})
						}
					};
				})(f);
				reader.readAsText(f)
		    }
		  }
		  
		function handleDragEnd(evt) {
		}

		function handleDragOver(evt) {
			evt.stopPropagation();
			evt.preventDefault();
		}
		// Setup the dnd listeners.
		$(dropZone).get(0).addEventListener('dragover', handleDragOver, false);
		$(dropZone).get(0).addEventListener('dragend', handleDragEnd, false);
		$(dropZone).get(0).addEventListener('drop', handleFileSelect, false);
	});
}
Gallery.prototype.getPanel = function(){

	var self = this;
	this.generateGalleryTab();

	// 隱藏官方面板
	$('#emoticon_selecter #emoticon_holder_super_parent').hide();

	if(self.emoticonsPanel){
		return self.emoticonsPanel.show().children(':not(.loading)').hide().end();
	}else{

		var panel = self.emoticonsPanel = $($('#emoticons_show').get(0) || $('<div id="emoticons_show" />').css('height', '250px').prependTo('#emoticon_selecter')).show().children().hide().end();
		var loading = this.loading = self.loading || $('<div/>', { class: 'loading',
			text: 'Loading...'
		}).appendTo(panel).show();
		
		$('#emoticons_tabs li[id^=emo_]').click(function(){
			$('#emoticon_selecter #emoticon_holder_super_parent').show();
			$('#emoticons_show').hide();
		});
		$(panel).css({'position': 'relative'});
		$(panel).unbind('click').click(function(){ return false; });
		return self.emoticonsPanel;
	}
}
Gallery.prototype.deprecateDefaultTab = function(){
	$("#emo_my").bind('click' ,function(){
		var t = setInterval(function(){
			$(".emoticons_my #emoticons_my_holder")
			.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
			.find('.showMyEmotions:not(:Event(click))').click( function(){
				$(this).parents('#emoticons_my_holder').find('.protect').hide();
				$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
				return false;
			 }).end();
			
			if($(".emoticons_my #emoticons_my_holder table:not(.protected)").length == 0) {
				return;
			}else{
				clearInterval(t);
			}
			
			$(".emoticons_my #emoticons_my_holder")
			.find('table').addClass('protected').hide().end()
			.append(
				$("<ol class='protect' style='margin:20px auto;color:#555;width:350px;'></ol>")
				.append($("<li style='margin:20px 0px;'/>").html(__("PlurkCustoms 已經代管噗浪自訂表情<br> 您應該從「<a class='gallery'>圖庫</a>」來使用表情圖片")))
				.append($("<li style='margin:20px 0px;'/>").html(__("您可以按上方的「新增...」來上傳圖片到圖庫")))
				.append($("<li style='margin:20px 0px;'/>").html(__("或者也可以點選任何他人的自訂表情新增到圖庫")))
				.append($("<li style='margin:20px 0px;'/>").html(__("如果仍需要顯示線上的自訂表情請按一下<a class='showMyEmotions'>這裡</a>")))
			)
			.find('a').css({'cursor' : 'pointer'}).end()
			.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
			.find('.showMyEmotions:not(:Event(click))').click( function(){
				$(this).parents('#emoticons_my_holder').find('.protect').hide();
				$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
				return false;
			 }).end();
		}, 200);
	})	
}
Gallery.prototype.generateGalleryTab = function(){

	var self = this;

	if(this.galleryTab) return;
	
	self.deprecateDefaultTab();

	var doc = document; 
	createStyle(doc, ".emoticon_selecter.delete.current{ background:red !important; }	.emoticon_selecter.delete.current a{ color:white !important;}");
	createStyle(doc, ".emoticon_selecter.rename.current{ background:green !important; }	.emoticon_selecter.rename.current a{ color:white !important;}");
	createStyle(doc, ".emoticon_selecter.backup.current{ background:#CF5A00 !important; }	.emoticon_selecter.backup.current a{ color:white !important;}");
	
	//add tab
	function switchTab(e){
		$(this).siblings().removeClass("current");
		$(this).addClass("current");

		var panel = self.getPanel();
		return self.getPanel();
	}

	this.galleryTab = $('<li>', {
		class: 'gallery',
		attr: {title: __('圖庫')},
		html: $('<a/>'),
		click: function(){
			switchTab.apply(this, arguments);
			//self.showBackupTab.apply(self, arguments);
			self.showGalleryTab("#emoticons_show");
		}
	}).appendTo("#emoticons_tabs ul");

	this.backupTab = backupEmotionsTab = $('<li>', {
		class: 'backup',
		attr: {title: __('備份')},
		html: $('<a/>'),
		click: function(){
			switchTab.apply(this, arguments);
			self.showBackupTab.apply(self, arguments);
		}
	}).appendTo("#emoticons_tabs ul");

	this.settingTab = $('<li>', {
		class: 'setting',
		attr: {title: __('設定')},
		html: $('<a/>'),
		click: function(){
			var tab = switchTab.apply(this, arguments);
			//self.showSettingTab.apply(self, arguments);
			self.showSettingTab.apply(self, arguments);
		}
	}).appendTo("#emoticons_tabs ul");


	$("<a class='switchWindowMode' style='float:right;height:9px;width:9px; margin:8px; padding:2px; background:url(http://emos.plurk.com/633e54d3723da4e8c1acc48288e952bc_w8_h8.gif) no-repeat; cursor:pointer;' title='切換視窗大小'></a>").toggle(function(){
		$(this).parents('#emoticon_selecter').addClass('large').draggable({ disabled: true });
		$('body').addClass('large_emoticon_selecter');
		$('.tableWrapper').scrollTop(0);
		self.lazyLoader.resize();

	},function(){
		$(this).parents('#emoticon_selecter').removeClass('large').draggable({ disabled: false });
		$('body').removeClass('large_emoticon_selecter');
		$('.tableWrapper').scrollTop(0);
		self.lazyLoader.resize();
	}).insertAfter("#emoticons_tabs a.bn_close");
	
	//Make it draggable
	$("#emoticon_selecter").draggable({attachTo: "#emoticons_tabs", ignore: "a, li", "cursor": "move" })
	createStyle(doc, "#emoticon_selecter.ondrag {opacity: 0.5;}");
	createStyle(doc, "#emoticon_selecter {-webkit-box-shadow: rgba(0, 0, 0, 0.8) 2px 2px 5px 0px;-webkit-transition: opacity 0.2s linear;}");
	//createStyle(doc, "#emoticon_selecter #emoticons_tabs {cursor: move ;}");	
}
Gallery.prototype.createGalleryFilter = function(table, defaultValue){

	var self = this;

	if(typeof self.galleryFilterValue == 'undefined') self.galleryFilterValue = "";
	var delayTimer;
	var filter = $("<input class='filter' type='text' placeholder='"+ __('快速找到相關的表情') + "' />")
		.val(self.galleryFilterValue)
		.keyup(function(){
			var val = $(this).val();
			val = val.replace(/^[\s　]+/, '').replace(/[\s　]+$/, '');
			
			self.galleryFilterValue = val;
			
			var tds = $(table).find("td");

			//show all if empty
			if(val.length == 0) {
				//restore 
				tds.css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
				self.lazyLoader && self.lazyLoader.resize();
				return false;
			}
			
			var matched = tds.filter(function(){
				var alt = $(this).find('a').attr('alt').toLowerCase();
				return (alt.indexOf(val.toLowerCase()) != -1);
			});
			
			
			if(matched.length == 0 && val.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)){
				return false;
			}


				
			clearInterval(delayTimer);
			delayTimer = setTimeout(function(){
				//show matched
				matched.addClass('matched').css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
				
				//hide others
				var animated = tds.not(matched).filter(':visible').filter(':lt(25)').css({'max-width': '0', 'max-height': '0', 'opacity' : '0', 'display': ''})
				tds.not(matched).not(animated).attr('style', 'display:none !important;')
				//don't know why this not work
				//tds.not(matched).not(animated).css('display', 'none');
				
				//make first 25 hidden element animated next time
				tds.not(matched).not(":visible").filter(':lt(25)').css({'opacity' : '1', 'display': '', 'max-width': '0', 'max-height': '0'});
				setTimeout(function(){
					self.lazyLoader.resize();
				}, 300);
			}, 200)

		})
		.trigger('keyup')
		.css({width: '100%'})
		.click(function(){this.select();})
	return filter;
}
Gallery.prototype.generateGalleryTable = function(emotions){

	var self = this;
	var startTime = new Date();
	var totalPics = emotions.length;
	var count = 0;
	var line = 0;
	var row ;
	

	var tabWrapper 		= $('<div/>', { class: 'tabWrapper gallery'});
	var filterWrapper 	= $('<div/>', { class: 'filterWrapper'});
	var tableWrapper 	= $('<div/>', { class: 'tableWrapper',
		html: $('<div/>', { class: 'help',
			text: __('Shift + 點選重新命名 / %s + 點選刪除').replace('%s', (isMac? "⌘" : "Ctrl"))
		})
	});

	var table = $('<table/>', { class: 'flexible plurkCustoms gallery'});
	var filter = self.createGalleryFilter(table);

	function operationClickImage (event, emoticon) {

		var td 		= $(this);
		var img 	= $(this).find('img');
		var wrapper = $(this).find('a');
		var keyword = emoticon.keyword;
		var url 	= emoticon.url;
		
		if(event.shiftKey){ //ShiftKey rename
			var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
			if(newKeyword && newKeyword != "" && newKeyword != keyword) {
				//需要重寫
				removeEmotion(url, function(){	//從自訂表情刪除
					deleteEmotion(keyword, function(emotions){	//從圖庫刪除
						saveEmotion(url, newKeyword, function(emotions){
							for(z in emotions) if(emotions[z].url == url) newKeyword = emotions[z].keyword; // peocessed keyword
							wrapper.attr('alt', newKeyword).attr('title', newKeyword + " ("+__('已重新命名')+")").end().addClass('highlighted');
						})
					});
				});
				EmoticonsStorage.renameFavorite(url, newKeyword);
				//showCandidateEmotions(parent);
			}
		}else if( ((!isMac && event.ctrlKey) || isMac && event.metaKey) ){ //ctrlKey delete
			var ok = confirm(__("你確定要刪除 %s 嗎").replace('%s', keyword));
			if(ok) {
				removeEmotion(url, function(){
					deleteEmotion(keyword, function(emotions){
						wrapper.animate({opacity: 0.1}, 500).unbind('click');
					});
				});
				EmoticonsStorage.removeFavorite(url);
				//showCandidateEmotions(parent);
			}
		}else{
			EmoticonsStorage.addFavorite(emoticon);
			gallery.operateEmoticonClick(wrapper); 
			return false; 
		}
	}	
	for(var i in emotions){ 
		if(count%8==0) {
			line++;
			row = $("<tr/>", {
				attr: {
					'data-line': line, 
					'data-number': ((count+1) + '-' + (count+8))
				}
			}).appendTo(table);			
		}

		count++;
		(function(emoticon){

			var td = $('<td/>', {
				//data: 	{emotion : emoticon},
				//css: 	{'opacity': (emoticon.alive ? '1.0 ' : '1.0')},
				click : function(event){
					console.log('click');
					operationClickImage.call(this, event, emoticon);
				}
			}).appendTo(row);

			var imgWrapper = $('<a/>', { class: 'a_emoticon lazy',
				//data: 	{emotion : emoticon},
				attr: 	{
					url: 	emoticon.url,
					alt: 	emoticon.keyword,
					title: 	emoticon.keyword,
				},
				html: $('<img/>', {
					attr: { 'data-src': emoticon.url },
				}).hide()
			}).appendTo(td);


		})(emotions[i])
		
	}
	var spendTime = (Math.round((new Date() - startTime) /10) /100) + 's';
	var footer = $('<div/>', { class: 'footer',
		css: {color: '#555'},
		html: [
			__('共 %d 張圖片').replace('%d', totalPics) +" ("+spendTime+")",
			$('<span/>', {
				css: { float: 'right' },
				html: [
					"PlurkCustoms " + manifest('version') + " © 2011-2013 ",
					$('<a>',{
						text: 'Lackneets',
						attr: {href: 'http://www.plurk.com/Lackneets', target : '_blank'}
					})
				]

			}),
			$('<div/>', {
				css: { color:'#999', margin:'5px 0' },
				text: __('※請勿自行刪除重新安裝以免圖庫遺失，如需更新請重新啟動瀏覽器')
			})
		] 
	});

	tabWrapper.tableWrapper = tableWrapper.append(table).append(footer);
	tabWrapper.filterWrapper = filterWrapper.empty().append(filter);

	tableWrapper.get(0).addEventListener('scroll',function(){
		self.panelScrollTop = this.scrollTop;
	})
	tabWrapper.html([filterWrapper, tableWrapper]);
	tabWrapper.json = JSON.stringify(emotions); // 驗證版本用
	tabWrapper.on('DOMNodeInserted', function(){
		self.lazyLoader = new LazyLoader(tableWrapper);
		tableWrapper.scrollTop(self.panelScrollTop);
		return tabWrapper;
	});
	tabWrapper.focusFilter = function(){
		filter.focus().select();
		return tabWrapper;
	}
	tabWrapper.restoreScrollTop = function(){
		tableWrapper.scrollTop(self.panelScrollTop);
		return tabWrapper;
	}

	tabWrapper.focusFilter();

	return self.tabWrapperGallery = tabWrapper;
}
Gallery.prototype.reduceOnlineEmoticons = function(max){
	var self = this;
	console.log('縮減線上表情', max);
	this.getRemovableEmoticons(function(removeable){
		//console.log('delete', removeable.length, 'onlineEmoticons');
		_.each(removeable, function(emo, i){
			if(i >= max) setTimeout(function(){
				removeEmotion(removeable[i].url, function(){});
			}, (i-max)*120);
		})
	});
}
Gallery.prototype.getRemovableEmoticons = function(callback){
	var self = this;
	getOnlineEmoticons(function(onlineEmoticons){
		var favEmotions = EmoticonsStorage.getFavorites();
		var removeable = _.map(onlineEmoticons, function(emo){
			var f = _.findWhere(favEmotions, {hash_id: emo.hash_id});
			emo.favorite = f ? f.favorite : -1;
			return emo;
		});
		removeable = _.sortBy(removeable, function(emo){
			return emo.favorite;
		}).reverse();
		callback && callback(removeable);
	});

	/*loadEmotions(function(emotions){
		emotions.reverse();

		var aliveCount = 0;
		//可移除清單
		var removeable = emotions.slice(0);
		var favEmotions = EmoticonsStorage.getFavorites();

		for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, self.emotionUplaoded) != -1) aliveCount++;

		//加入常用作為排序參照
		for(var i in removeable) {
			removeable[i].favorite = 0;
			for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
				removeable[i].favorite = favEmotions[f].favorite;
				break;
			}
		}

		function sortFavorite(a, b){ return b.favorite - a.favorite; }
		removeable.sort(sortFavorite);

		var _removeable = []
		for(var i in removeable) { 
			//如果正在使用則不可移除
			if($.inArray(removeable[i].keyword, self.emotionUsed) != -1) continue;
			//不在線上 && 未上傳
			if(removeable[i].alive != true && $.inArray(removeable[i].keyword, self.emotionUplaoded) == -1) continue;
			//已移除
			if($.inArray(removeable[i].keyword, self.emotionRemoved) != -1) continue;
			
			_removeable.push(removeable[i]);
			//console.log(removeable[i].keyword, removeable[i].favorite); 
		}
		removeable = _removeable; delete _removeable;

		callback && callback(removeable);
	})*/
}
var gallery = new Gallery();