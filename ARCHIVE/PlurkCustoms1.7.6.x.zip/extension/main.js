if(typeof PlurkCustoms == 'undefined') PlurkCustoms = {};

var isMac = navigator.platform.match(/Mac/i);
var plurkCustoms;
var user_id;
var token;
var extension_url = "https://chrome.google.com/webstore/detail/plurkcustoms-%E8%87%AA%E8%A8%82%E8%A1%A8%E6%83%85%E5%9C%96%E5%BA%AB/npkllofhoohpldfjaepknfbjbmehjpmc";
var permission_request = false;


var Emotion = function(emotion_data){
	for(var i in this.__proto__){
		this[i] = emotion_data[i];
	}
}
Emotion.prototype = {
	keyword	: "",
	hash_id	: "",
	url		: "",
	alive	: false
}


function arrayClone(arr){
	if(typeof arr == 'object') return arr.slice(0);
	else return arr;
}

//取得 manifest 的資料
function manifest(name) {
	var value;
	
	if(! manifest.data ) $.ajax({
		url: chrome.extension.getURL('/manifest.json'),
		dataType: 'json',
		async: false,
		success: function(data){
			manifest.data = data;
		}
	});
	value = manifest.data[name]
	return value;
}

/*Libs*/
var handup = false;
var emotionsCache;

function normalizeKeywordFilter(emoticons){
	return _.map(emoticons, function(emo, i){
		emo.keyword = emo.keyword || ('_遺失的表情_' + i)
		emo.keyword = emo.keyword.replace(/'/ig, '');
		emo.keyword = emo.keyword.replace(/[\[\]]]/ig, '_');
		emo.keyword = emo.keyword.replace(/[\[\]]]/ig, '_');
		return emo
	});
}

function sendExtensionRequest(obj, callback){
	if(handup) return false;
	try{
		chrome.extension.sendRequest(obj, callback);
	}catch(e){
		handup = true;
		alert(__('發生錯誤：') + e);
		var c = confirm(__('無法連線到圖庫，請立即重新整理頁面看看，可能有版本更新，繼續將無法正常操作'));
		if(c) window.location.reload();
	}
}
function renameEmotion(url, keyword, newkeyword, callback){
	deleteEmotion(keyword, function(){
		saveEmotion(url, newkeyword, function(emotions){
			if(typeof callback == 'function') callback(emotions);
		});
	})
}

//將單一個自訂表情從圖庫刪除
function deleteEmotion(keyword, callback){
	if(handup) return false;
	sendExtensionRequest({deleteEmotion: true, keyword: keyword}, function(emotions){
		console.log("deleteEmotion: userEmotions has been updated");
		if(typeof callback == 'function') callback(emotions);
	});
}
//將單一個自訂表情新增到圖庫
function saveEmotion(url, keyword, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotion: true, url: url, keyword: keyword}, function(emotions){
		if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
		console.log("saveEmotion: userEmotions has been updated");
		if(typeof callback == 'function') callback(emotions);
	});
}
//取代所有 (警告)
function replaceEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({replaceEmotions: true, emotions: emotions}, function(emotions){
		console.log("emotions replaced!!!!!!");
		if(typeof callback == 'function') callback(emotions);
	});
}
//合併表情
function saveEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotions: true, emotions: emotions}, function(emotions){
		console.log("emotions merged!!!!!!");
		if(typeof callback == 'function') callback(emotions);
	});
}
function onlineMergeEmotions(emotions, callback){
	if(handup) return false;
	sendExtensionRequest({saveEmotions: true, type: 'onlineMerge' , emotions: emotions}, function(emotions){
		console.log("onlineMergeEmotions");
		if(typeof callback == 'function') callback(emotions);
	});

}



//從圖庫載入所有表情
function loadEmotions(callback){
	if(handup) return false;
	sendExtensionRequest({loadEmotions: true}, function(emotions){
		emotions = normalizeKeywordFilter(emotions);
		if(typeof emotions != 'object' && typeof emotions != 'array') emotions = new Array();
		if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
		if(typeof callback == 'function') callback(emotions);
	});		

}

function getOnlineEmoticons(callback){
	$.ajax({ url: "http://www.plurk.com/EmoticonManager/getUserEmoticons",
		data: {token: token},
		dataType: 'json',
		type: 'POST',
		success: function(onlineEmotions){
			callback && callback(onlineEmotions);
		},
		error: function(){
			if(!getUserEmoticons.alerted && (getUserEmoticons.alerted = true)) alert("無法存取您的噗浪自訂表情，請確認您有填寫100%個人資料開啟自訂表情功能");
		}
	});
}

//檢查表情是否在噗浪上
function isAlive(keyword, callback){
	if(handup) return false;
	sendExtensionRequest({isAlive: true, keyword: keyword}, callback);
}

function doOnlineMerge(callback){
	getOnlineEmoticons(function(onlineEmotions){
		loadEmotions(function(emotions){
			onlineMergeEmotions(onlineEmotions, function(){
				var delay = 0;
				for(var i in onlineEmotions) for(var e in emotions) (function(o, e){
					if(o.hash_id == e.hash_id && o.keyword != e.keyword){
						console.log('可疑', o, e);
						if(o.keyword){
							renameEmotion(o.url, e.keyword, o.keyword, function(){
								console.log('將衝突名稱更改為官方名稱', e.keyword, ' => ', o.keyword);
							});						
						} else{
							console.log('線上版本沒有名稱?? 刪除！', o, e);
							setTimeout(function(){removeEmotion(o.url);}, (delay++)*50)
						}
					 	//setTimeout(function(){removeEmotion(o.url);}, (delay++)*300) && console.log(o.url, delay*300);
					}
				})(onlineEmotions[i], emotions[e]);
				if(typeof callback == 'function') callback(emotions);
			});			
		});
	})
}

function getUserEmoticons(callback, nocache){
	if(!getUserEmoticons.emotions || (nocache===true)) $.ajax({ url: "http://www.plurk.com/EmoticonManager/getUserEmoticons",
		data: {token: token},
		dataType: 'json',
		type: 'POST',
		success: function(onlineEmotions){
			getUserEmoticons.emotions = onlineEmotions;
			onlineMergeEmotions(onlineEmotions, function(){
				doOnlineMerge(callback);
			/*	loadEmotions(function(emotions){
					console.log('getUserEmoticons-> merge');
					console.trace();
					var delay = 0;
					for(var i in onlineEmotions) for(var e in emotions) (function(o, e){
						if(o.hash_id == e.hash_id && o.keyword != e.keyword){
						 	//setTimeout(function(){removeEmotion(o.url);}, (delay++)*300) && console.log(o.url, delay*300);
						 	renameEmotion(o.url, e.keyword, o.keyword, function(){
								console.log('將衝突名稱更改為官方名稱', e.keyword, ' => ', o.keyword);
							});
						}
					})(onlineEmotions[i], emotions[e]);
					if(typeof callback == 'function') callback(emotions);
				})*/
			});
		},
		error: function(){
			if(!getUserEmoticons.alerted && (getUserEmoticons.alerted = true)) alert("無法存取您的噗浪自訂表情，請確認您有填寫100%個人資料開啟自訂表情功能");
		}
	});
	else loadEmotions(function(emotions){
		if(callback) callback(emotions);
	})
}

//將一個表情上傳到噗浪
function addEmotion(url, keyword, callback){
	var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
	$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/addEmoticon",
		data: {form_token: token, url: url,  hash_id: hash_id, keyword: keyword},
		type: 'POST',
		success:function(response){
			callback(response);
			/*getUserEmoticons(function(response){
				console.log("userEmotions has been uploaded", keyword);
				if(callback) callback(response);
			});*/
		}
	});
}

//從噗浪上刪除一個表情
function removeEmotion(url, _callback){
	//if(typeof url != 'string' || !url.match(/plurk\.com\/([0-9a-zA-Z]+)/) ) throw('removeEmotion: invalid url', url)
	var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
	$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/removeEmoticon",
		data: {form_token: token, hash_id: hash_id},
		type: 'POST',
		success:function(response){
			console.log("removeEmotion: " + url + " has been removed from plurk");
			if(typeof _callback == 'function') _callback();
		}
	});
}

function utf8_to_b64( str ) {
    return window.btoa(unescape(encodeURIComponent( str )));
}

function b64_to_utf8( str ) {
    return decodeURIComponent(escape(window.atob( str )));
}



//Start PlurkCustoms



(function($){

	jQuery.fn.swapWith = function(to) {
	    return this.each(function() {
	        var copy_to = $(to).clone(true);
	        $(to).replaceWith(this);
	        $(this).replaceWith(copy_to);
	    });
	};

	getLocal('GLOBAL', function(GLOBAL){
		token = GLOBAL.session_user.token;
		user_id = GLOBAL.session_user.id;
		gallery.reduceOnlineEmoticons(50);
	})



	
	Function.prototype.clone = function() {
	    var that = this;
	    var temp = function temporary() { return that.apply(this, arguments); };
	    for( key in this ) {
	        temp[key] = this[key];
	    }
	    return temp;
	};
	
	function require(file, callback){
		$.ajax({
		  url: chrome.extension.getURL('/' + file),
		  dataType: "script",
		  async: false,
		  success: callback
		});
	}

})(jQuery);