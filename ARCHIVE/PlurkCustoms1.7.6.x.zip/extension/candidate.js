var GalleryCandidate = function(gallery){
	this.gallery = gallery
	this.init();
}
GalleryCandidate.prototype.previousKeyowrds = [];
GalleryCandidate.prototype.previousElements = null;
GalleryCandidate.prototype.candidateDiv = null;
GalleryCandidate.prototype.gallery = null;
GalleryCandidate.prototype.init = function(){
	var self = this;
	var delayTimer;

	$("#input_big").live('keyup click', function(e){ 
		if(e.keyCode == 13 || e.keyCode == 16 || $(this).val() == '' ) return; 
		clearTimeout(delayTimer); delayTimer = setTimeout(function(){self.show('#main_poster')}, 250); 
	});

	$("#input_small").live('keyup click', function(e){ 
		if(e.keyCode == 13 || e.keyCode == 16 || $(this).val() == '' ) return;
		clearTimeout(delayTimer); delayTimer = setTimeout(function(){self.show('.mini_form')}, 250); 
	});	

	$("#input_big, #input_small").live('keydown keyup', function(e){ 
		self.candidateDiv = $(".candidate");
		if(e.keyCode == 13) self.candidateDiv.fadeOut('fast',function(){ $(this).remove()});
	});	

	setInterval(function(){
		if($("#input_big").length && $("#input_big").val().length == 0) $("#main_poster .candidate").fadeOut('fast',function(){ $(this).remove()});
		if($("#input_small").length && $("#input_small").val().length == 0) $(".mini_form .candidate").fadeOut('fast',function(){ $(this).remove()});
	}, 200)

	$(".cmp_plurk").live('click', function(e){ 
		self.candidateDiv = $(".candidate");
		if(e.keyCode == 13) self.candidateDiv.fadeOut('fast',function(){ $(this).remove()});
	});	

	$("#input_big").live('keydown', function(e){ return self.selectByKey(e, '#main_poster'); });
	$("#input_small").live('keydown', function(e){ return self.selectByKey(e, '.mini_form'); });

	$("#main_poster textarea").live("focus",function(){self.gallery.lastInputFocused = document.getElementById('input_big');});
	$(".mini_form textarea").bind("focus",function(){self.gallery.lastInputFocused = document.getElementById('input_small');});
}
GalleryCandidate.prototype.prepare = function(emotions, parent){

	var self = this;
	
	if(JSON.stringify(emotions) == this.previousElements && self.candidateDiv.children().length > 0){
		self.candidateDiv.removeAttr('style').show();
		return;
	}
	this.previousElements = JSON.stringify(emotions);
	
	
	var c=0
	
	var buffer = $("<div class='__emotionBuffer'/>").hide() //.appendTo('body');
					
	if(emotions.length > 0 && !emotions[0].skip) for(var i in emotions){ 
		
		if(emotions[i].skip) continue;
		if(typeof emotions[i].match == 'undefined') emotions[i].match = 0;
		if(typeof emotions[i].type == 'undefined') emotions[i].type = "custom";
		if(typeof emotions[i].sortWeight == 'undefined') emotions[i].sortWeight = 0;
		
		c++; if(c > 100) break;
		
		
		var td = $("<div style='width:48px;text-align:center; position:relative; cursor:pointer;' />").data('emotion', emotions[i]).css({'opacity': (emotions[i].alive ? '1.0 ' : '1.0')}).css('display', 'inline-block').appendTo(buffer);
		
		if($.inArray(emotions[i].keyword, self.previousKeyowrds) == -1) td.hide().delay(25*c).fadeIn('fast');

		var tag = $("<span style='position:absolute; cursor:default; top:-15px; left:0px; font-size:12px; ; color:#ccc ;z-index:99;display:block; text-overflow:clip; overflow:hidden;white-space: nowrap; max-width:48px;'/>").appendTo(td);
		if(c < 10) tag.text("Alt + " + c).css('color', '#CF5A00');
		else tag.text(emotions[i].keyword);
			
		emo = $('<a class="a_emoticon canadite" style="position:relative" />')
			.attr('url', emotions[i].url)
			.attr('alt', emotions[i].keyword)
			.attr('match', emotions[i].match)
			.attr('type', emotions[i].type)
			.attr('isFavorite', ((typeof emotions[i].favorite != 'undefined') ? "1" : "0"))
			.attr('title', emotions[i].keyword + ((typeof emotions[i].favorite != 'undefined') ? " \n"+__("使用頻率") +": "+emotions[i].favorite+ "\n" + __("排序權重") + ": " +Math.round(emotions[i].sortWeight*100)/100 : "\n" + __("排序權重") + ": " + Math.round(emotions[i].sortWeight*100)/100) )
			.attr('sortWeight', Math.round(emotions[i].sortWeight*100)/100 )
			.data('emotion', emotions[i])
			.html("<img src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />")
			.appendTo(td);
		
		

		td.bind("click", function(e){  
			
			var type = $(this).find('a').attr("type");
			var isCustom = (type == "custom");
			var isDefault = (type == "default");
			var url = $(this).find('a').attr("url");
			var keyword = $(this).find('a').attr("alt");
			var match = $(this).find('a').attr("match");
			var isFavorite = $(this).find('a').attr("isFavorite") == "1";
			
			if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) && e.shiftKey){ //ctrlKey delete
				if(!isFavorite) return false;
				var e = $(this).find('a');
				//var ok = confirm("從常用表情中移除 "+ keyword +" 嗎 (不會移除圖庫中的表情)");
				//if(ok) {
					EmoticonsStorage.removeFavorite(url);
					self.show(parent);
				//}
			}else if(e.shiftKey && isCustom){ //ShiftKey rename
				var e = $(this).find('a');
				var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
				if(newKeyword && newKeyword != "" && newKeyword != keyword) {
					removeEmotion(url, function(){	//從自訂表情刪除
						deleteEmotion(keyword, function(emotions){	//從圖庫刪除
							saveEmotion(url, newKeyword, function(){
								showStoredEmotions(target, actionMode);
							})
						});
					});
					EmoticonsStorage.renameFavorite(url, newKeyword);
					self.show(parent);
				}
			}else if( ((!isMac && e.ctrlKey) || isMac && e.metaKey)  && isCustom ){ //ctrlKey delete
				var e = $(this).find('a');
				var ok = confirm( __("你確定要刪除 %s 嗎").replace('%s', keyword));
				if(ok) {
					removeEmotion(url, function(){
						deleteEmotion(keyword, function(emotions){
							$(e).animate({opacity: 0.1}, 500).unbind('click');
						});
					});
					EmoticonsStorage.removeFavorite(url);
					//showCandidateEmotions(parent);
				}
			}else{
				if(e.altKey) $(this).find('a').removeAttr('match');
				var e = new Emotion($(this).data('emotion'));
				if(isCustom){ 
					EmoticonsStorage.addFavorite(e);
					gallery.operateEmoticonClick($(this).find('a'), function(){
						self.candidateDiv.fadeOut('fast', function(){ $(this).remove()})
					});
				}else{
					self.gallery.useDefaultSmile(keyword, match);
					self.candidateDiv.fadeOut('fast', function(){ $(this).remove()})
				}
			}
			
			return false; 
		} );
	}
	
	if(emotions.length == 0  ||  emotions[0].skip){ 
		self.candidateDiv.fadeOut('fast',function(){ $(this).remove()})
	}else{
		self.candidateDiv.removeAttr('style').show().empty();
		buffer.children().appendTo(self.candidateDiv);				
	}		
	
	buffer.remove();
} // End prepare

GalleryCandidate.prototype.show = function(parent){

	var self = this;
	var parent = $(parent);
	var input = gallery.lastInputFocused;
	var value = input.value.substr(0, input.selectionStart).replace(/^\s*/, '')/*.replace(/\s*$/, '')*/;
	
	self.candidateDiv = parent.find(".candidate").length ? parent.find(".candidate") : $("<div class='candidate' />")
			.css({
				'width' 	: '99%',
				'z-index'	: '199',
				'background': 'white'
			}).appendTo(parent.find(".input_holder")).hide();
			

	self.candidateDiv.find('div').each(function(){
		self.previousKeyowrds.push($(this).find('a').attr('alt'));
	});
	
	
	//show favorite
	if(input.value.substr(0, input.selectionStart).match(/\s+$/)){
		self.prepare(EmoticonsStorage.getFavorites().slice(0, 60), parent);
		return;
	}
	
	// Process keywords
	var keywords = [];
	for( i = value.length-1; i > value.length-8; i--){
		var k = value.substr(i, value.length);
		if(k == keywords[keywords.length]) break;
		if(k.length == 1 && k.match(/^[0-9a-zA-Z]{1}$/)) continue;
		if(k.length > 1 && k.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)) keywords.push(k.substr(0, k.length-1));
		keywords.push(k);
	};

	if(keywords.length == 0) return false;
	
	//show keyword-filtered
	self.getDefaultSmiles(function(defaultSmiles){
		getUserEmoticons(function(emotions){

			for(var i in defaultSmiles){ 
				defaultSmiles[i].alive = true;
				defaultSmiles[i].type = "default";
				defaultSmiles[i].hash_id = "";
			}
			
			for(var i in emotions) emotions[i].type = 'custom';
			emotions = emotions.concat(defaultSmiles);
			
			var favEmotions = EmoticonsStorage.getFavorites();
			
			var maxFav = (favEmotions.length) ? favEmotions[0].favorite : 1;
			for(var i in emotions){ 
				emotions[i].match = emotions[i].sortWeight = 0;
				for(var k in keywords){ // for all keyword patterns
					var kw = keywords[k].toLowerCase(); if(kw.match(/^\s*$/)) continue; // skip empty keyword match
					var ek = emotions[i].keyword.toLowerCase();
					var ea = (typeof emotions[i].alias == 'string') ? emotions[i].alias.toLowerCase() : "";
					try{
						//Matches a new keyword pattern and the pattern longer then previous one
						if(Math.max(ek.indexOf(kw), ea.indexOf(kw)) != -1 && kw.length > emotions[i].match){
							emotions[i].match = kw.length;
							emotions[i].sortWeight = Math.max(emotions[i].match*2.5 - (Math.max(ek.indexOf(kw), ea.indexOf(kw)) + 1)*emotions[i].match*0.2, emotions[i].sortWeight);
						}
							emotions[i].skip = (emotions[i].match == 0) ? true : false;
					}catch(e){
						console.log(emotions[i]);
					}
				}
				for(var f in favEmotions){
					if(!emotions[i].skip && emotions[i].url == favEmotions[f].url){
						emotions[i].sortWeight *= (1.8 + (favEmotions[f].favorite/maxFav));
						break;
					} 
				}
			}
			
			
			function sortByWeight(a, b){
				if(a.sortWeight == b.sortWeight) return 0;
				return  a.sortWeight > b.sortWeight ? -1 : 1;
			}

			emotions.sort(sortByWeight);
			self.prepare(emotions, parent); 
		});	
	})

}

GalleryCandidate.prototype.getDefaultSmiles = function(callback){
	localScript("var _Emoticons = _Emoticons || {silver:Emoticons.silver, platinum:Emoticons.platinum, gold:Emoticons.gold, platinum_2:Emoticons.platinum_2, karma100:Emoticons.karma100};");
	getLocal('GLOBAL', function(GLOBAL){
		getLocal('_Emoticons', function(Emoticons){
			var u = GLOBAL.session_user;
			var e = u&&u.recruited||0;
			var c = u&&u.karma||0;
			var a = [];
			if(c>=25) a=a.concat(Emoticons.silver);
			if(e>=10) a=a.concat(Emoticons.platinum);
			if(c>=50) a=a.concat(Emoticons.gold);
			if(c>=81) a=a.concat(Emoticons.platinum_2);
			if(c>=100) a=a.concat(Emoticons.karma100);
			var emoticons = [
				{url: "http://statics.plurk.com/47d20905d017c396d67b4a30c9ac9b10.png", keyword: "(goal)"},
				{url: "http://statics.plurk.com/5a2a63fa773e68797ec69a1303bfa3b9.png", keyword: "(bzzz)"},
				{url: "http://statics.plurk.com/7256dae81d56d150120ccd0c96dd2197.gif", keyword: "(fireworks)"},
				{url: "http://statics.plurk.com/4ad099fba019942f13058610ff3fc568.gif", keyword: "(dance_bzz)"},
				{url: "http://statics.plurk.com/deda4d9f78ad528d725e3a6bfbf6352f.gif", keyword: "(Русский)", alias: "(Pyccknn)"},
				{url: "http://statics.plurk.com/0efc4d55d28704f4370ef874ae906161.gif", keyword: "(code)"},
				{url: "http://statics.plurk.com/4c40d16a0d369b895c08f2e33d062ec8.gif", keyword: "(yarr)"},
				{url: "http://statics.plurk.com/1a5f23ed863e70e52f239b045a48e6fb.gif", keyword: "(xmas1)"},
				{url: "http://statics.plurk.com/f5dbd5fdf5f5df69cfb024d6be76a76b.gif", keyword: "(xmas2)"},
				{url: "http://statics.plurk.com/e902170e97aee14836b5df6b0fe61ba2.gif", keyword: "(xmas3)"},
				{url: "http://statics.plurk.com/e476574723d5042f24658fa36866bd92.gif", keyword: "(xmas4)"},
				{url: "http://statics.plurk.com/a555399b40c379adca5b6f5bad5bf732.gif", keyword: "(dance_okok)"},
				{url: "http://statics.plurk.com/74030f05f06547a3d26b02ccbf0bbac7.gif", keyword: "(music_okok)"},
				{url: "http://statics.plurk.com/bac8c8392f7ca8f5ac74612be4d08b74.gif", keyword: "(wave_okok)"},
				{url: "http://statics.plurk.com/71acd802cc931649dd9a371ccf70bad2.gif", keyword: "(hungry_okok)"},
				{url: "http://statics.plurk.com/3acbaf42504fff32c5eac4f12083ce56.gif", keyword: "(yar_okok)"},
				{url: "http://statics.plurk.com/fcd28d7d78ec1f828c76930fa63270e6.gif", keyword: "(gym_okok)"},
				{url: "http://statics.plurk.com/8855f56400a936db07f348d9290adaac.gif", keyword: "(code_okok)"},
				{url: "http://statics.plurk.com/feb43dbbbf2763905571060be9a496d1.gif", keyword: "(no_dance)"},
				{url: "http://statics.plurk.com/5b51892d7d1f392d93ea7fe26e5100f4.gif", keyword: "(banana_gym)"},
				{url: "http://statics.plurk.com/6de58c967f1c2797d250a713ba50eddd.gif", keyword: "(dance_yarr)"},
				{url: "http://statics.plurk.com/88fac5a4b99110a35d4e4794dad58ab4.gif", keyword: "(taser_okok)"},
				{url: "http://statics.plurk.com/6675254cd7449b1847a93b0024127eae.gif", keyword: "(angry_okok)"},
				{url: "http://statics.plurk.com/b3b9856e557fcc2700fd41c53f9d4910.gif", keyword: "(droid_dance)"},
				{url: "http://statics.plurk.com/cfdd2accc1188f5fbc62e149074c7f29.png", keyword: "(fuu)", 		alias: "rage"},
				{url: "http://statics.plurk.com/828b9819249db696701ae0987fba3638.png", keyword: "(gfuu)", 		alias: "rage"},
				{url: "http://statics.plurk.com/1bd653e166492e40e214ef6ce4dd716f.png", keyword: "(yay)", 		alias: "rage"},
				{url: "http://statics.plurk.com/3fe6cf919158597d7ec74f8d90f0cc9f.png", keyword: "(gyay)", 		alias: "rage"},
				{url: "http://statics.plurk.com/9c5c54081547d2ad903648f178fcc595.png", keyword: "(bah)", 		alias: "rage"},
				{url: "http://statics.plurk.com/2da76999ca3716fb4053f3332270e5c9.png", keyword: "(gbah)", 		alias: "rage"},
				{url: "http://statics.plurk.com/f73b773aa689647cb09f57f67a83bb89.png", keyword: "(troll)", 		alias: "rage"},
				{url: "http://statics.plurk.com/45beda260eddc28c82c0d27377e7bf42.png", keyword: "(gtroll)",		alias: "rage"},
				{url: "http://statics.plurk.com/8590888362ae83daed52e4ca73c296a6.png", keyword: "(aha)", 		alias: "rage"},
				{url: "http://statics.plurk.com/c7551098438cc28ec3b54281d4b09cc3.png", keyword: "(gaha)", 		alias: "rage"},
				{url: "http://statics.plurk.com/cfd84315ebceec0c4389c51cf69132bd.png", keyword: "(whatever)", 	alias: "rage"},
				{url: "http://statics.plurk.com/0e0bf1ec2c2958799666f3995ef830ca.png", keyword: "(gwhatever)", 	alias: "rage"},
				{url: "http://statics.plurk.com/e2998ca75f80c1c4a5508c549e3980a6.png", keyword: "(pokerface)", 	alias: "rage"},
				{url: "http://statics.plurk.com/c6ad1c4f9e11f6859a1ba39c4341ef8b.png", keyword: "(gpokerface)", alias: "rage"},
				{url: "http://statics.plurk.com/4a61085f1c6a639f028cd48ae97d07d0.png", keyword: "(yea)", 		alias: "rage"},
				{url: "http://statics.plurk.com/53253ca60f5831f0812954213a2e9bb3.png", keyword: "(gyea)", 		alias: "rage"},
				{url: "http://statics.plurk.com/6928f3117658cc38d94e70519a511005.png", keyword: "(jazzhands)", 	alias: "rage"},
				{url: "http://www.plurk.com/static/emoticons/valentine/lingerie.png", keyword: "v_shy"},
				{url: "http://www.plurk.com/static/emoticons/valentine/tiffany-box.png", keyword: "v_tiffany"},
				{url: "http://www.plurk.com/static/emoticons/valentine/heart-love.png", keyword: "v_love"},
				{url: "http://www.plurk.com/static/emoticons/valentine/perfume.png", keyword: "v_perfume"},
				{url: "http://www.plurk.com/static/emoticons/valentine/envelope.png", keyword: "v_mail"},
			/*	{url: "http://www.plurk.com/static/emoticons/lantern/lantern-love.png", keyword: "lantern_love"},
				{url: "http://www.plurk.com/static/emoticons/lantern/lantern-well.png", keyword: "latern_well"},
				{url: "http://www.plurk.com/static/emoticons/lantern/lantern-peace.png", keyword: "lantern_peace"},
				{url: "http://www.plurk.com/static/emoticons/lantern/lantern-health.png", keyword: "lantern_health"},
				{url: "http://www.plurk.com/static/emoticons/lantern/lantern-fortune.png", keyword: "lantern_fortune"},
				{url: "http://www.plurk.com/static/emoticons/lantern/lantern-happy.png", keyword: "lantern_happy"}, */
			]
			for(var i in a) emoticons.push({ url: a[i][1], keyword: a[i][2] });		
			callback && callback(emoticons);	
		})
	});	
}

GalleryCandidate.prototype.selectByKey =  function(e, parent){
	var candidateDiv = $(parent).find(".candidate");
	var key = Keycode.getValueByEvent(e);
	var self = this;
	if((e.altKey) &&  new String(key).match(/[0-9]/)){
		evt = $.Event("click");
		if( ((!isMac && e.ctrlKey) || isMac && e.metaKey)  ) evt.altKey = true;
		self.candidateDiv.find('div').eq(parseInt(key)-1).trigger(evt)
		return false;
	}
}


var candidate = new GalleryCandidate(gallery);
