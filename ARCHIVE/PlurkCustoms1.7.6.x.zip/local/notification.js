function notificationSound(){
	var sound = (localStorage.getItem("notificationSound_on") == 'true');
	if(sound){
		var audio = document.createElement('audio');
		audio.setAttribute('src', $extension('notification.mp3'));
		audio.play();
	}
}
if(localStorage.getItem("notificationSound_on") == null) localStorage.setItem("notificationSound_on", true);

var on = (localStorage.getItem("notificationSound_on") == 'true');
var soundOnOff = 
	$('<img/>', {
		class : (on ? 'on' : 'off'),
		attr: {
			src: ( on ? $extension('images/sound_on.png') : $extension('images/sound_off.png') )
		},
		css: {
			'vertical-align': 'middle',
			'height': '16px'
		}
	});
	
soundOnOff.click(function(){
	var on = $(this).hasClass('on');
	on = !on;
	localStorage.setItem("notificationSound_on", on);
	$(this).removeClass('on off').addClass( on ? 'on' : 'off');
	$(this).attr('src', on ? $extension('images/sound_on.png') : $extension('images/sound_off.png'));
	notificationSound();
});

//$('通知 <img class="'+(on ? 'on' : 'off')+'" style="vertical-align:middle;" src="'+ ( on ? $extension('images/sound_on.png') : $extension('images/sound_off.png') ) +'" height=16 >')

$('<a class="off_tab" href="#" onclick="return false"></a>')
	.attr('title', __('開啟/關閉 通知音效'))
	.empty().append( soundOnOff )
	.wrap('li')
	.prependTo("#filter_tab");