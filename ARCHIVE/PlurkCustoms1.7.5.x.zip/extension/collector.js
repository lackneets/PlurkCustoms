(function(){
	function collectable(){
		var img = $(this);
		loadEmotions(function(){
			for(var i in emotionsCache) if(img.attr('src').match(emotionsCache[i].hash_id)){
				img.addClass('exist');
				img.attr('title', emotionsCache[i].keyword);
				return;
			}
			img.addClass('new').attr('title', __('點選以蒐集這張圖片')).bind('click', function(){
				var url = img.attr('src');
				var defaultKeyword = img.attr('keyword');
				var keyword = prompt(__("請為這張圖片取一個名字"), defaultKeyword || __("表情"));
				if(keyword && keyword.replace(/\s*/, '') != ""){
					saveEmotion(url, keyword, function(emotions){
						img.removeAttr('title').removeClass('new').unbind('click');
						img.attr('title', keyword);
					});
				}
			});	
		});
	}

	//$(".plurk img[src*='emos.plurk.com']:not(.new):not(.exist), #emotiland img[src*='emos.plurk.com']:not(.new):not(.exist)").livequery(collectable);
	
	$(document).on('mouseover', ".plurk img[src*='emos.plurk.com']:not(.new):not(.exist), #emotiland img[src*='emos.plurk.com']:not(.new):not(.exist)", function(){
		collectable.call(this, this);
	});

})()

