﻿(function($){
	
	var token;
	var uid;
	
	try{
		token = $("body").html().match(/token=([\d\w]+)/)[1];
		uid = $("body").html().match(/user_id=([\d]+)/)[1];
	}catch(e){
		return false;
	}
	
	/*function localScript(scriptText){
		var script = document.createElement('script'); 
		script.type = 'text/javascript'; 
		script.appendChild(document.createTextNode(scriptText));
		document.body.appendChild(script);	
	}*/
	
	function localScript(scriptText, args){
		var args = JSON.stringify(args);
		//if(typeof scriptText == 'function') scriptText = '(function(args){(' + scriptText + ')();})('+args+');';
		if(typeof scriptText == 'function') scriptText = '(' + scriptText + ')('+args+');';
		var script = document.createElement('script'); 
		script.type = 'text/javascript'; 
		script.appendChild(document.createTextNode(scriptText));
		document.body.appendChild(script);	
	}	
		
	function refreshPlurk(){
		window.location = "javascript:(function() {var jq = document.createElement('script');jq.src = 'http://code.jquery.com/jquery-1.6.4.min.js';jq.setAttribute('async', false);document.documentElement.firstChild.appendChild(jq);setTimeout(function(){if(typeof jQuery != 'function') {setTimeout(arguments.callee, 1);return false;}console.log(jQuery);jQuery.noConflict();plurkRestart();}, 1);})();function plurkRestart(){GLOBAL.show_inivted_guide = 0;GLOBAL.current_lang = 'zh_Hant';TimeLine.init($('content'));TimeLine.showLoading();Plurks.init();Emoticons.init();Tracks.init();KeyManager.init();SiteState.init();InfoOverlay.init();Users.init();PUBLIC_PLURKS = [];fetchUserData(function() {jQuery('#main_poster .plurkForm:gt(0)').remove();        var ses_user = SiteState.getSessionUser();Profile.renderFans();Profile.renderFriends();setHTML($('span_years'), Utils.getYears(SiteState.getPageUser().date_of_birth));if(window.Media) {    Media.attach($('about_me'), SiteState.getPageUser());    map($bytc('a', null, $('about_me')), function(elm) {        if(hasClass(elm, 'youtube')) {            var img = $gc(elm, 'img');            if(img) {                img.width = 60;                img.height = 50;            }        }    })}});}";
	}
	
	function markMuted(ids){
		ids = '[' + ids.join(',') + ']';
		console.log("markMuted("+ids+");");
		localScript("markMuted("+ids+");");
	}
	
	function markRead(){
		//全部標示為已讀
		localScript('(function () { var d=TimeLine.plurks.length; var b=Poll.counts; var e=[]; var g=[]; map(TimeLine.plurks,function(h) { e.push(h.plurk_id); g.push(h.id) } ); if(e.length>0) { Poll.disabled=true; var c=getRequest("/Responses/markAllRead"); c.sendReq( { ids:serializeJSON(e) } ); c.addCallback(function() { Poll.disabled=false } ); map(g,function(h) { Poll.setPlurkRead(h) } ); false; } else { false; } return false })();');
		localScript("TimeLineCache.cache = []; TimeLine.plurks = []; TimeLine.reset(); TimeLine.showLoading(); TimeLine.getPlurks(); Plurks.cleanData(); Plurks.init();");
	}
	
	function refreshTimeline(){
		
		//檢視所有訊息
		localScript(function () {
			Poll._viewAll();
			setTimeout(function(){
				DisplayOptions._filter();
			}, 800);
		});
	}
	
	setInterval(function(){

		if($("#noti_re_actions .updater_link").length == 2 ){
			$("<a class='updater_link muteAll' href='#' >")
				.css('margin-left', '15px')
				.html("<span>✖ "+__('全部消音')+"</span>")
				.appendTo("#noti_re_actions")
				.click(function(){ muteAll(); return false; });
		}
		
		var plurkManager = $(".plurk .manager:has(.delete)");
		if(plurkManager.length){
			
			if(plurkManager.find(".mute").length == 0){
				var plurkBox = plurkManager.parents(".plurk");
				var plurkId = plurkBox.attr('id').match(/\d+/)[0];
				var muted = plurkBox.hasClass('muted');
				var muteBtn = muted 
					? $("<a class='mute delete unmute' href='#'>"+__("解除消音")+"</a>")
					: $("<a class='mute delete' href='#'>"+__("消音")+"</a>");
				muteBtn.click(function(){
					mutePlurk(plurkId, !muted, function(){
						muteBtn.text(!muted ? __("解除消音") : __("消音"))
						plurkBox.toggleClass('muted');
					})
					return false;
				});
				muteBtn.prependTo(plurkManager);
			}
		}
		

	}, 200);
	
	function getProgressBar(){
		var progressBar = $("#noti_re_actions .progressBar");
		if( progressBar.length == 0){
			progressBar = $("<a class='progressBar' style='width:180px;display:inline-block;height:18px;position:relative;overflow:hidden;border:1px solid #eee;margin-left:15px;'></a>").hide().appendTo("#noti_re_actions");
				var progress = $("<div class='progress' style='width:0%;height:18px;position:absolute;z-index:-1;top:0px;left:0px;background:#eb9757;'></div>").appendTo(progressBar);
				var progressText = $("<div class='progressText' style='width:100%;height:18px;text-align:center;'>"+__('正在消音...')+"</div>").appendTo(progressBar);
		}
		progressBar.setProgress = function(p){
			$(this).find('.progress').width( p + '%');
			$(this).find('.progressText').text(__('正在消音...'))
		}
		progressBar.setText = function(t){
			$(this).find('.progressText').text(t)
		}
		return progressBar;
	}
	
	function mutePlurk(plurk_id, mute, callback){
		var value = mute ? '2' : '0';
		$.ajax({
			url: "http://www.plurk.com/TimeLine/setMutePlurk",
			data: {plurk_id: plurk_id, value: value },
			type: "POST", cache: false,
			success: function(data){
				if(callback) callback();
			}
		});
	}

	function muteAll(){

		var muteAll = $("#noti_re_actions .muteAll");
		var progressBar = getProgressBar();
		
		muteAll.stop(true, true).fadeOut('fast', function(){ progressBar.stop(true, true).fadeIn('fast');})
		progressBar.setProgress(0);
		progressBar.setText("Wait...");
		
		$.ajax({
			url: "http://www.plurk.com/Users/getUnreadPlurks",
			data: {known_friends: JSON.stringify([uid]) },
			type: "POST", cache: false,
			success: function(dataJSON){
				var data = eval('(' + dataJSON + ')'); console.log(data)
				for(var i=0; i < data.unread_plurks.length; i++) if(data.unread_plurks[i].owner_id == uid || data.unread_plurks[i].plurk_type > 1) { data.unread_plurks.splice(i,1); i--; }	
				
				var total = data.unread_plurks.length; 
				
				if(total == 0){ 
					progressBar.stop(true, true).fadeOut('fast', function(){ muteAll.stop(true, true).fadeIn('fast');})
					progressBar.setText(__('已無未讀噗'))
					return false;
				}
				var ok = confirm( __("確定要消音 %d 則未讀噗嗎? (不包含已回應過)").replace('%d', total) ); 
				var ids = [];
				if(!ok){ 
					progressBar.stop(true, true).fadeOut('fast', function(){ muteAll.stop(true, true).fadeIn('fast');})
					progressBar.setText(__('已取消'))
					return false;
				}
				
				for(var i in data.unread_plurks) ids.push(data.unread_plurks[i].plurk_id);
				mutePlurks(ids);
			}
		});
	}	
	
	function mutePlurks(ids){

			
		var muteAll = $("#noti_re_actions .muteAll");
		var progressBar = getProgressBar();
		
		muteAll.stop(true, true).fadeOut('fast', function(){ progressBar.stop(true, true).fadeIn('fast');})
		
		var muted = 0;
		for(var i in ids) $.ajax({
			url: "http://www.plurk.com/TimeLine/setMutePlurk",
			data: {plurk_id: ids[i], value: 2 },
			type: "POST", cache: false,
			xhr: function() {
		        var xhr = jQuery.ajaxSettings.xhr();
		        if(xhr instanceof window.XMLHttpRequest) {
					xhr.addEventListener('readystatechange', function(){
						if(xhr.readyState >=2){
							xhr.abort();
							muted++; 
							var p = Math.ceil((muted / ids.length)*100);
							progressBar.setProgress(p);
							
							if(p == 100){
								for(var i in ids) $("#p" + ids[i]).addClass('muted').find('.manager .mute').addClass('unmute').html('Muted')
								progressBar.stop(true, true).delay(1500).fadeOut('slow', function(){ muteAll.stop(true, true).fadeIn('fast');})
								progressBar.setText(__('請按一下「全部標為已讀」'));
								markRead();
								markMuted(ids);
								refreshTimeline();
								progressBar.hide();
							}
						}
					}, false);

		        }
		        return xhr;
			}
		});
		
		
		/*$.ajax({
			url: "http://www.plurk.com/TimeLine/setMutePlurk",
			data: {plurk_id: ids[i], value: 2 },
			type: "POST", cache: false,
			success: function(data){ muted++; 
				var p = Math.ceil((muted / ids.length)*100);
				progressBar.setProgress(p);
				
				if(p == 100){
					for(var i in ids) $("#p" + ids[i]).addClass('muted').find('.manager .mute').addClass('unmute').html('Muted')
					progressBar.stop(true, true).delay(1500).fadeOut('slow', function(){ muteAll.stop(true, true).fadeIn('fast');})
					progressBar.setText(__('請按一下「全部標為已讀」'));
					markRead();
					markMuted(ids);
					refreshTimeline();
					progressBar.hide();
					//setTimeout(refreshTimeline, 100);
				}
			}
		});*/
	}

})(jQuery);