﻿function usingjQuery(callback){
	if(typeof jQuery == 'function'){
		if(typeof callback == 'function') callback(jQuery);
	}else{
		var script = document.createElement('script'); 
		script.type = 'text/javascript'; 
		script.src = jQueryPath;
		document.body.appendChild(script);
		var interval = setInterval(function(){
			if(typeof jQuery == 'function'){
				jQuery.noConflict();
				clearInterval(interval);
				if(typeof callback == 'function') callback(jQuery);
				console.log("jQuery is ready")
			}else{
				console.log("Waiting jQuery....")
			}
		}, 50);
	}
}

function notificationSound(){
	var sound = (localStorage.getItem("notificationSound_on") == 'true');
	if(sound){
		var audio = document.createElement('audio');
		audio.setAttribute('src', 'chrome-extension://npkllofhoohpldfjaepknfbjbmehjpmc/notification.mp3');
		audio.play();
	}
}

usingjQuery(function($){
	if(localStorage.getItem("notificationSound_on") == null) localStorage.setItem("notificationSound_on", true);

	var on = (localStorage.getItem("notificationSound_on") == 'true');
	var soundOnOff = $('通知 <img class="'+(on ? 'on' : 'off')+'" style="vertical-align:middle;" src="chrome-extension://npkllofhoohpldfjaepknfbjbmehjpmc/sound_'+(on ? 'on' : 'off')+'.png" height=16 >').click(function(){
		var on = $(this).hasClass('on');
		on = !on;
		localStorage.setItem("notificationSound_on", on);
		$(this).removeClass('on off').addClass( on ? 'on' : 'off');
		$(this).attr('src', on ? 'chrome-extension://npkllofhoohpldfjaepknfbjbmehjpmc/sound_on.png' : 'chrome-extension://npkllofhoohpldfjaepknfbjbmehjpmc/sound_off.png');
		notificationSound();
	});
	
	$('<a class="off_tab" href="#" onclick="return false"></a>')
		.attr('title', '開啟/關閉 通知音效')
		.empty().append( soundOnOff )
		.wrap('li')
		.prependTo("#filter_tab");
});

setInterval(function(){
	if(typeof Poll == 'undefined') return;
	Poll.counts = Poll.getUnreadCounts();
	
	if(typeof arguments.callee.my == 'undefined' && (Poll.counts.my + Poll.counts.responded) > 0) notificationSound();
	if(typeof arguments.callee.my == 'undefined') arguments.callee.my = Poll.counts.my;
	if(typeof arguments.callee.responded == 'undefined') arguments.callee.responded = Poll.counts.responded;
	
	if(arguments.callee.my < Poll.counts.my || arguments.callee.responded < Poll.counts.responded){
		notificationSound();
	}
	arguments.callee.my = Poll.counts.my;
	arguments.callee.responded = Poll.counts.responded;
		
	var title = "";	 var detail = "";
	if(Poll.counts.my) detail += " 我 " + Poll.counts.my;	
	if(Poll.counts.responded) detail += " 回 " + Poll.counts.responded;
	if(Poll.counts.priv) detail += " 私 " + Poll.counts.priv;
	detail = detail.replace(/^\s+/, '').replace(/\s+$/, '');
	if(detail) title = title + " " + detail + "";
	if(Poll.counts.all) title += " 未讀 " + Poll.counts.all;
	
	if(title) document.title = title + " - " + TopBar.cur_page_title;
	else document.title = title;
}, 200);


function markMuted(ids){
	if(typeof ids == 'array' || typeof ids == 'object'){
		for(var i in ids) markMuted(ids[i]);
		return;
	}
	var id = ids;
	console.log("Mute " + id)
	if(typeof id == 'string' || typeof id == 'number') for(var i in $plurks) if($plurks[i].obj.plurk_id == id) ($plurks[i].obj.is_unread = 2);
}
