$(function(){
	$.wait("#plurk_form .icons_holder", function(elements){

		if(elements.find('img.downloadEmoticons').length > 0) return;
		
		var icon = $('<a/>',{
			class: 'downloadEmoticons',
			attr: {title: __('打包下載所有表情圖案')},
			click: function(e){
				downloadEmoticons();
				return false;
			}
		}).appendTo(elements);

	});
})

function loadImageBinary(url, callback){
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url, true);

	xhr.responseType = 'arraybuffer';

	xhr.onload = function(e) {
		if (this.status == 200) {
			var uInt8Array = new Uint8Array(this.response);
			var i = uInt8Array.length;
			var binaryString = new Array(i);
			while (i--){
				binaryString[i] = String.fromCharCode(uInt8Array[i]);
			}
			var data = binaryString.join('');

			//var base64 = window.btoa(data);
			callback && callback(data);
		}
	}

	xhr.send();
}

var saveData = (function () {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (blob, fileName) {
        url = URL.createObjectURL(blob);
        a.href = url;
        a.download = fileName;
        a.click();
        console.log(url, a);
        URL.revokeObjectURL(url);
    };
}());


function downloadEmoticons(){
	var zip;
	var folder = newZip();
	var downloader = arguments.callee;

	if(NProgress.status){
		alert(__('忙碌中請稍後再試'));
		return false;
	}


	NProgress.configure({ minimum: 0.005 ,
		template: '<div class="bar" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon"></div></div>'
	});


	if(downloader.isDownloading == true){
		alert(__('忙碌中請稍後再試'));
		return false;
	}

	if(typeof downloader.isDownloading == 'undefined') downloader.isDownloading = true;

	NProgress.configure({ minimum: 0.005 });
	NProgress.set(0.0);

	try{
		loadEmotions(function(emoticons) {

			try{
				var json = JSON.stringify(emoticons);
				//var b64 = utf8_to_b64( json );
				zip.file('backup.txt', json);
				
				var toDownload = emoticons.length;
				var downloaded = 0
				var progress = 0;
				for(var i=0; i< toDownload; i++){
					(function(emo){
						setTimeout(function(){
							loadImageBinary(emo.url, function(base64){
								var ext = emo.url.match(/\.(\w+)$/)[1];
								var fileneme = emo.keyword.replace(/\\/ig, '＼')
									.replace(/\*/ig, '_')
									.replace(/\//ig, '／')
									.replace(/\:/ig, '：')
									.replace(/\</ig, '＞')
									.replace(/\>/ig, '＜')
									.replace(/\?/ig, '？')
									.replace(/\|/ig, '｜');
								downloaded++;
								var p = Math.round(downloaded/toDownload*100)/100;

								if(p - progress > 0.005){
									progress = p;
									NProgress.set(p);
								}

								folder.file(fileneme + '.' + ext, base64, {binary: true});
								if(toDownload == downloaded){
									packfile();
									NProgress.set(1.0);
									NProgress.done(true);
									downloader.isDownloading = false;
								}
							});
						}, i*30);

					})(emoticons[i]);

				}

			}catch(e){
				alert(__('發生錯誤：') + e);
				downloader.isDownloading = false;
			}
		})		
	}catch(e){
		alert(__('發生錯誤：') + e);
		downloader.isDownloading = false;
	}


	function newZip(){
		zip = new JSZip();
		zip.file("readme.txt", "把backup.txt拖曳到備份模式的框框可以還原。如果檔名是亂碼請嘗試使用 7-zip 開啟 http://www.7-zip.org/\n by 小耀博士 http://www.plurk.com/Lackneets");
		zip.file('Use 7-zip if you see garbled', '');
		return zip.folder("emoticons");
	}

	function packfile(){
		var d = new Date();
		var blob = zip.generate({type:'blob'});
		saveData(blob, 'PlurkCustomsBackup ' + d.getFullYear() +'_'+ (d.getMonth()+1)  +'_'+  d.getDate() + '.zip')
		//window.open(URL.createObjectURL(blob));
		folder = newZip();
	}
}