﻿var isMac = navigator.platform.match(/Mac/i);
var plurkCustoms;
var token;

function arrayClone(arr){
	if(typeof arr == 'object') return arr.slice(0);
	else return arr;
}

function localScript(scriptText, args){
	var args = JSON.stringify(args);
	//if(typeof scriptText == 'function') scriptText = '(function(args){(' + scriptText + ')();})('+args+');';
	if(typeof scriptText == 'function') scriptText = '(' + scriptText + ')('+args+');';
	var script = document.createElement('script'); 
	script.type = 'text/javascript'; 
	script.appendChild(document.createTextNode(scriptText));
	document.body.appendChild(script);	
}
function loadScript(file){
	var script = document.createElement('script'); 
	script.type = 'text/javascript'; 
	script.src = chrome.extension.getURL(file);
	document.body.appendChild(script);
}

function include(file) {
	if(typeof arguments.callee.cache == 'undefined') arguments.callee.cache = new Array();
	var value;
	var cache = arguments.callee.cache;
	if(typeof cache[file] == 'undefined') $.ajax({
		url: chrome.extension.getURL(file),
		dataType: 'text',
		async: false,
		success: function(data){ cache[file] = data; }
	});
	value = cache[file];
	try{eval(value);}catch(e){ throw e; }
	//return value;
}






//Start PlurkCustoms

var LANG = "zh_Hant";

(function($){

	LANG = $("select[name=language] option[selected]").val();
	
	//jQuery extension
	$.wait = function(selector, callback, loop){
		var i = setInterval(function(){
			if($(selector).length > 0 && typeof callback == 'function'){
				var obj = $(selector);
				if(! loop ) clearInterval(i);
				callback.call(obj, obj);
			} 
		}, 50);
	}	
	jQuery.fn.swapWith = function(to) {
	    return this.each(function() {
	        var copy_to = $(to).clone(true);
	        $(to).replaceWith(this);
	        $(this).replaceWith(copy_to);
	    });
	};
	
	//Setup localScript
	
	loadScript('languages.js');
	localScript(function(args){
		window.jQueryPath		 	= args.jQueryPath;
		window.plurkCustoms_key 	= args.plurkCustoms_key;
		window.plurkCustoms_path 	= args.plurkCustoms_path;
		//window.LANG					= args.LANG;
		window.$extension = function(url){
			return args.plurkCustoms_path + url;
		}

	}, {
		jQueryPath 			: chrome.extension.getURL('jquery.min.js'),
		plurkCustoms_key 	: chrome.extension.getURL('').replace('chrome-extension://', '').replace('/', ''),
		plurkCustoms_path 	: chrome.extension.getURL(''),
		LANG				: LANG,
		
	});
	loadScript('js/sprintf.js');
	loadScript('js/usingjQuery.js');
	loadScript('localScript.js');	
	
	//jQuery.getScript(chrome.extension.getURL('plurkUI.js'));
	//include('plurkUI.js');
	



	$.wait("#filter_tab span:contains((0))", function(){
		$(this).html('')
	}, true);
	
	$.wait("#filter_tab", function(){
		loadScript('js/timeMachine.js');
		$("<a href='#' title='" + __('瀏覽以前的噗') + "' class='off_tab timeMachine' rel='timeMachine'>"+ __('時光機') +"</a>").click(function(){
			localScript('PlurkCustoms.timeTravel();');
		}).wrap('<li/>').appendTo(this);
		
	})
	
	/*點選蒐集表情圖片*/
	$.wait(".emoticon_my:not(.new):not(.exist)", function(e){
		if(! emotionsCache ) {
			loadEmotions();
			return ;
		}
		$(this).each(function(){
			for(var i in emotionsCache) if(emotionsCache[i].url == $(this).attr('src')){
				$(this).addClass('exist');
				return;
			}
			$(this).addClass('new').attr('title', __('點選以蒐集這張圖片')).bind('click', function(){
				var img = $(this);
				url = $(this).attr('src');
				keyword = prompt(__("請為這張圖片取一個名字"), __("表情"));
				if(keyword && keyword.replace(/\s*/, '') != ""){
					saveEmotion(url, keyword, function(emotions){
						console.log("saveEmotion done");
						img.removeAttr('title').removeClass('new').unbind('click');
					});
				}
			});
		});
	}, true);
	
	//去廣告
	$.wait("#plurk_ads", function(){ $(this).remove(); }, true);

	// read token
	try{
		token = $("body").html().match(/token=([\d\w]+)/)[1];
	}catch(e){
		return false;
	}

	var emotionsCache;
	//將單一個自訂表情新增到圖庫
	function saveEmotion(url, keyword, callback){
		chrome.extension.sendRequest({saveEmotion: true, url: url, keyword: keyword}, function(emotions){
			if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
			console.log("saveEmotion: userEmotions has been updated");
			if(typeof callback == 'function') callback(emotions);
		});
	}
	//取代所有 (警告)
	function replaceEmotions(emotions, callback){
		chrome.extension.sendRequest({replaceEmotions: true, emotions: emotions}, function(emotions){
			console.log("emotions replaced!!!!!!");
			if(typeof callback == 'function') callback(emotions);
		});
	}
	//合併表情
	function saveEmotions(emotions, callback){
		chrome.extension.sendRequest({saveEmotions: true, emotions: emotions}, function(emotions){
			console.log("emotions merged!!!!!!");
			if(typeof callback == 'function') callback(emotions);
		});
	}
	function onlineMergeEmotions(emotions, callback){
		chrome.extension.sendRequest({saveEmotions: true, type: 'onlineMerge' , emotions: emotions}, function(emotions){
			console.log("onlineMergeEmotions");
			if(typeof callback == 'function') callback(emotions);
		});
	}

	//將單一個自訂表情從圖庫刪除
	function deleteEmotion(keyword, callback){
		chrome.extension.sendRequest({deleteEmotion: true, keyword: keyword}, function(emotions){
			console.log("deleteEmotion: userEmotions has been updated");
			if(typeof callback == 'function') callback(emotions);
		});
	}

	//從圖庫載入所有表情
	function loadEmotions(callback){
		chrome.extension.sendRequest({loadEmotions: true}, function(emotions){
			if(typeof emotions.slice == 'function') emotionsCache = emotions.slice(0);
			if(typeof callback == 'function') callback(emotions);
		});
	}

	//將一個表情上傳到噗浪
	function addEmotion(url, keyword, callback){
		var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
		$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/addEmoticon",
			data: {form_token: token, url: url,  hash_id: hash_id, keyword: keyword},
			type: 'POST',
			success:function(response){
				getUserEmoticons(function(response){
					console.log("userEmotions has been updated", keyword);
					if(callback) callback(response);
				});
			}
		});
	}

	//從噗浪上刪除一個表情
	function removeEmotion(url, _callback){
		//if(typeof url != 'string' || !url.match(/plurk\.com\/([0-9a-zA-Z]+)/) ) throw('removeEmotion: invalid url', url)
		var hash_id = url.match(/plurk\.com\/([0-9a-zA-Z]+)/)[1];
		$.ajax({ url: "http://www.plurk.com/EmoticonDiscovery/removeEmoticon",
			data: {form_token: token, hash_id: hash_id},
			type: 'POST',
			success:function(response){
				console.log("removeEmotion: " + url + " has been removed from plurk");
				if(typeof _callback == 'function') _callback();
			}
		});
	}

	Emotion = function(emotion_data){
		for(var i in this.__proto__){
			this[i] = emotion_data[i];
		}
	}
	Emotion.prototype = {
		keyword	: "",
		hash_id	: "",
		url		: "",
		alive	: false
	}

	EmoticonsStorage = {	}
	EmoticonsStorage.getFavorites = function(){
		var fav = localStorage.getItem("emotions_favorites");
		try{ fav = JSON.parse(fav); }catch(e){ fav = new Array();; }
		if(typeof fav != 'object' && typeof fav != 'array') fav = new Array();
		if(fav == null) fav = new Array();
		return arrayClone(fav);
	}
	EmoticonsStorage.addFavorite = function(emotion){
		if(! typeof emotion == 'Emotion') throw("EmoticonsStorage.addFavorite(): Emotion expected");
		
		var emotions = this.getFavorites();
		emotions.sort(sortFavorite);
		
		
		var high = (emotions.length > 0) ? emotions[0].favorite : 0;
		
		// Find the same
		var exist;
		for(var i in emotions) if(emotions[i].hash_id == emotion.hash_id){
			emotion = emotions[i];
			exist = true;
			break;
		}
		if(! exist ) emotions.push(emotion);
		
		function array_mid(arr, attr){var s=0; for(i in arr) s+= arr[i][attr]; return s/arr.length; }

		if( typeof emotion.favorite != 'number') emotion.favorite = 0;

		if(emotion.hash_id == emotions[0].emotion){
			//已經是第一個
		} else if(emotion.favorite < 256){
			var mid = Math.ceil(array_mid(emotions, 'favorite')); if(mid < 2) mid = 2;
			if(emotion.favorite < mid)  emotion.favorite += mid;
			else emotion.favorite += Math.ceil(mid/4);
		} else {
			for(i in emotions){
				emotions[i].favorite--;
				if(emotions[i].favorite > 255) emotions[i].favorite = 255;
			}
		}
		
		emotions.sort(sortFavorite);
		
		if(emotions.length > 200) emotions.splice(emotions.length-200, emotions.length); 
		
		function sortFavorite(a, b){ return b.favorite - a.favorite; }
		
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
		
	}
	EmoticonsStorage.renameFavorite = function(url, keyword){
		var emotions = this.getFavorites();
		for(i in emotions) if(emotions[i].url == url) emotions[i].keyword = keyword;
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
	}

	EmoticonsStorage.removeFavorite = function(url){
		var emotions = this.getFavorites();
		for(i in emotions) if(emotions[i].url == url) emotions.splice(i, 1);
		localStorage.setItem("emotions_favorites", JSON.stringify(emotions));
	}

	
	Function.prototype.clone = function() {
	    var that = this;
	    var temp = function temporary() { return that.apply(this, arguments); };
	    for( key in this ) {
	        temp[key] = this[key];
	    }
	    return temp;
	};
	
	function require(file, callback){
		$.ajax({
		  url: chrome.extension.getURL('/' + file),
		  dataType: "script",
		  async: false,
		  success: callback
		});
	}
	
	//取得 manifest 的資料
	function manifest(name) {
		var value;
		
		if(! manifest.data ) $.ajax({
			url: chrome.extension.getURL('/manifest.json'),
			dataType: 'json',
			async: false,
			success: function(data){
				manifest.data = data;
			}
		});
		value = manifest.data[name]
		return value;
	}
	
	
	
	//監控自訂表情上傳
	$.wait(".add-emoticon-panel .popup img.col-right:not(.locked):visible", function(){
		var img = this;
		$(img).addClass('locked');
		$(".add-emoticon-panel").hide();
		
		var url = $(img).attr('src');
		var keyword = prompt(__("請為這張圖片取一個名字"), +("表情"));
		
		if(keyword && keyword.replace(/\s*/, '') != ""){
			saveEmotion(url, keyword, function(emotions){
				$(".add-emoticon-panel").hide();
				$(img).removeClass('locked');
			});
		}else{
			$(".add-emoticon-panel").hide();
			$(img).removeClass('locked');
		}
		
	}, true);
	
	$.wait(".error-msg.emo-file-error[style*='visibility: visible']", function(){
		$(".error-msg.emo-file-error").css('visibility', 'hidden');
		alert($(".error-msg.emo-file-error").text());
	}, true);
	
	$.wait(".error-msg.emo-url-error[style*='visibility: visible']", function(){
		$(".error-msg.emo-url-error").css('visibility', 'hidden');
		alert($(".error-msg.emo-url-error").text());
	}, true);
	

	
	
	//Show Candidate Emotions
	
	var showCandidateDelay = 0;
	$("#input_big").live('keyup click', function(e){ if(e.keyCode == 13 || e.keyCode == 16) return; clearTimeout(showCandidateDelay); showCandidateDelay = setTimeout(function(){showCandidateEmotions('#main_poster')}, 250); });
	$("#input_small").live('keyup click', function(e){ if(e.keyCode == 13 || e.keyCode == 16) return; clearTimeout(showCandidateDelay); showCandidateDelay = setTimeout(function(){showCandidateEmotions('.mini_form')}, 250); });	
	
	$("#input_big, #input_small").live('keydown keyup', function(e){ 
		var candidateDiv = $(".candidate");
		if(e.keyCode == 13) candidateDiv.fadeOut('fast',function(){ $(this).remove()});
	});	
	
	setInterval(function(){
		if($("#input_big").length && $("#input_big").val().length == 0) $("#main_poster .candidate").fadeOut('fast',function(){ $(this).remove()});
		if($("#input_small").length && $("#input_small").val().length == 0) $(".mini_form .candidate").fadeOut('fast',function(){ $(this).remove()});
	}, 200)
	
	$(".cmp_plurk").live('click', function(e){ 
		var candidateDiv = $(".candidate");
		if(e.keyCode == 13) candidateDiv.fadeOut('fast',function(){ $(this).remove()});
	});	
	
	$("#input_big").live('keydown', function(e){ return selectByKey(e, '#main_poster'); });
	$("#input_small").live('keydown', function(e){ return selectByKey(e, '.mini_form'); });
	
	$("#main_poster textarea").live("focus",function(){lastInputFocused = document.getElementById('input_big');});
	$(".mini_form textarea").bind("focus",function(){lastInputFocused = document.getElementById('input_small');});
	
	function selectByKey(e, parent){
		var candidateDiv = $(parent).find(".candidate");
		var key = keycode.getValueByEvent(e);
		if((e.altKey) &&  new String(key).match(/[0-9]/)){
			evt = $.Event("click");
			if( ((!isMac && e.ctrlKey) || isMac && e.metaKey)  ) evt.altKey = true;
			candidateDiv.find('div').eq(parseInt(key)-1).trigger(evt)
			return false;
		}
	}
	
	function showCandidateEmotions(parent){
		var parent = $(parent)
		var candidateDiv = parent.find(".candidate").length ? parent.find(".candidate") : $("<div class='candidate' />")
				.css({
					'width' 	: '99%',
					'z-index'	: '199',
					'background': 'white'
				}).appendTo(parent.find(".input_holder")).hide();
				
		var input = lastInputFocused;
		var value = input.value.substr(0, input.selectionStart).replace(/^\s*/, '')/*.replace(/\s*$/, '')*/;
		
		var previousKeyowrds = [];
		candidateDiv.find('div').each(function(){
			previousKeyowrds.push($(this).find('a').attr('alt'));
		});
		
		//show favorite
		if(input.value.substr(0, input.selectionStart).match(/\s+$/)){
			//console.log('show favorite');
			prepareEmotionsList(EmoticonsStorage.getFavorites().slice(0, 40));
			return;
		}
		
		// Process keywords
		var keywords = [];
		for( i = value.length-1; i > value.length-8; i--){
			var k = value.substr(i, value.length);
			if(k == keywords[keywords.length]) break;
			if(k.length == 1 && k.match(/^[0-9a-zA-Z]{1}$/)) continue;
			if(k.length > 1 && k.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)) keywords.push(k.substr(0, k.length-1));
			keywords.push(k);
		};

		if(keywords.length == 0) return false;
		

		//show keyword-filtered
		//console.log('show keyword-filtered');
		getUserEmoticons(function(emotions){
			
			
			var favEmotions = EmoticonsStorage.getFavorites();
			/*var fav_urls = [];
			for(var i in favEmotions) fav_urls.push(favEmotions[i].url);*/
			
			var maxFav = (favEmotions.length) ? favEmotions[0].favorite : 1;
			for(var i in emotions){ 
				
				emotions[i].match = emotions[i].sortWeight = 0;
				for(var k in keywords){
					try{
					emotions[i].match =  (emotions[i].keyword.toLowerCase().indexOf(keywords[k].toLowerCase()) != -1 && (keywords[k].length) > emotions[i].match) ? (keywords[k].length) : emotions[i].match;
					emotions[i].sortWeight = (emotions[i].keyword.toLowerCase().indexOf(keywords[k].toLowerCase()) == 0) ? emotions[i].match*3 : emotions[i].match;
					emotions[i].skip = (emotions[i].match == 0) ? true : false;
					}catch(e){
						console.log(emotions[i]);
					}
				}
				for(var f in favEmotions){
					if(!emotions[i].skip && emotions[i].url == favEmotions[f].url){
					//	console.log(emotions[i].keyword, emotions[i].sortWeight);
						emotions[i].sortWeight *= (1.5 + (favEmotions[f].favorite/maxFav));
					//	console.log(emotions[i].keyword, emotions[i].sortWeight);
					//	console.log("加權", emotions[i].keyword, emotions[i].sortWeight);
						//fc--;
						break;
					} 
				}
			}
			
			
			function sortByWeight(a, b){
				if(a.sortWeight == b.sortWeight) return 0;
				return  a.sortWeight > b.sortWeight ? -1 : 1;
			}

			emotions.sort(sortByWeight);
			prepareEmotionsList(emotions);
		});
		
		function prepareEmotionsList(emotions){
			
			var c=0
			
			var buffer = $("<div class='__emotionBuffer'/>").hide().appendTo('body');
				
			if(emotions.length > 0 && !emotions[0].skip) for(var i in emotions){ 
				
				
			
				if(emotions[i].skip) continue;
				if(typeof emotions[i].match == 'undefined') emotions[i].match = 0;
				
				c++; if(c > 100) break;
				
				
				var td = $("<div style='width:48px;text-align:center; position:relative; cursor:pointer;' />").data('emotion', emotions[i]).css({'opacity': (emotions[i].alive ? '1.0 ' : '1.0')}).css('display', 'inline-block').appendTo(buffer);
				
				if($.inArray(emotions[i].keyword, previousKeyowrds) == -1) td.hide().delay(25*c).fadeIn('fast');

				var tag = $("<span style='position:absolute; cursor:default; top:-15px; left:0px; font-size:12px; ; color:#ccc ;z-index:99;display:block; text-overflow:clip; overflow:hidden;white-space: nowrap; max-width:48px;'/>").appendTo(td);
				if(c < 10) tag.text("Alt + " + c).css('color', '#CF5A00');
				else tag.text(emotions[i].keyword);
					
				emo = $('<a class="a_emoticon canadite" style="position:relative" />')
					.attr('url', emotions[i].url)
					.attr('alt', emotions[i].keyword)
					.attr('match', emotions[i].match)
					.attr('isFavorite', ((typeof emotions[i].favorite != 'undefined') ? "1" : "0"))
					.attr('title', emotions[i].keyword + ((typeof emotions[i].favorite != 'undefined') ? " ("+__("使用頻率")+": "+emotions[i].favorite+" )" : "") )
					.data('emotion', emotions[i])
					.html("<img src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />")
					.appendTo(td);
					
				td.bind("click", function(e){  
					
					var url = $(this).find('a').attr("url");
					var keyword = $(this).find('a').attr("alt");
					var isFavorite = $(this).find('a').attr("isFavorite") == "1";
					
					if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) && e.shiftKey){ //ctrlKey delete
						if(!isFavorite) return false;
						var e = $(this).find('a');
						//var ok = confirm("從常用表情中移除 "+ keyword +" 嗎 (不會移除圖庫中的表情)");
						//if(ok) {
							EmoticonsStorage.removeFavorite(url);
							showCandidateEmotions(parent);
						//}
					}else if(e.shiftKey){ //ShiftKey rename
						var e = $(this).find('a');
						var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
						if(newKeyword && newKeyword != "" && newKeyword != keyword) {
							removeEmotion(url, function(){	//從自訂表情刪除
								deleteEmotion(keyword, function(emotions){	//從圖庫刪除
									saveEmotion(url, newKeyword, function(){
										showStoredEmotions(target, actionMode);
									})
								});
							});
							EmoticonsStorage.renameFavorite(url, newKeyword);
							showCandidateEmotions(parent);
						}
					}else if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) ){ //ctrlKey delete
						var e = $(this).find('a');
						var ok = confirm( __("你確定要刪除 %s 嗎").replace('%s', keyword));
						if(ok) {
							removeEmotion(url, function(){
								deleteEmotion(keyword, function(emotions){
									$(e).animate({opacity: 0.1}, 500).unbind('click');
								});
							});
							EmoticonsStorage.removeFavorite(url);
							//showCandidateEmotions(parent);
						}
					}else{
						if(e.altKey) $(this).find('a').removeAttr('match');
						var e = new Emotion($(this).data('emotion'));
						EmoticonsStorage.addFavorite(e);
						click_smile($(this).find('a'), function(){
							candidateDiv.fadeOut('fast',function(){ $(this).remove()})
						});
					}
					
					return false; 
				} );
			}
			
			if(emotions.length == 0  ||  emotions[0].skip){ 
				candidateDiv.fadeOut('fast',function(){ $(this).remove()})
			}else{
				candidateDiv.removeAttr('style').show().empty();
				buffer.children().appendTo(candidateDiv);				
			}			
		} // End prepare
	}

		
	//檢查表情是否在噗浪上
	function isAlive(keyword, callback){
		chrome.extension.sendRequest({isAlive: true, keyword: keyword}, callback);
		//return	$inArray(keyword, emotionUplaoded) != -1;
	}
	
	function getUserEmoticons(callback, cache){
		if(!getUserEmoticons.emotions) $.ajax({ url: "http://www.plurk.com/EmoticonManager/getUserEmoticons",
			data: {token: token},
			dataType: 'json',
			type: 'POST',
			success: function(onlineEmotions){
				getUserEmoticons.emotions = onlineEmotions;
				onlineMergeEmotions(onlineEmotions, function(){
					loadEmotions(function(emotions){
						var delay = 0;
						for(var i in onlineEmotions) for(var e in emotions) (function(o, e){
							if(o.url == e.url && o.keyword != e.keyword){
							 	setTimeout(function(){removeEmotion(o.url);}, (delay++)*300) && console.log(o.url, delay*300);
							}
						})(onlineEmotions[i], emotions[e]);
						if(typeof callback == 'function') callback(emotions);
					})
				});
			},
			error: function(){
				if(!getUserEmoticons.alerted && (getUserEmoticons.alerted = true)) alert("無法存取您的噗浪自訂表情，請確認您有填寫100%個人資料開啟自訂表情功能");
			}
		});
		else loadEmotions(function(emotions){
			if(callback) callback(emotions);
		})
	}

	
	//顯示「表情圖庫」
	function showMoreEmotionsTab(){
		
		if(showMoreEmotionsTab.exist) return false;
		
		$("#emo_my").bind('click' ,function(){
			var t = setInterval(function(){

				$(".emoticons_my #emoticons_my_holder")
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				
				if($(".emoticons_my #emoticons_my_holder table:not(.protected)").length == 0) {
					return;
				}else{
					clearInterval(t);
				}
				
				$(".emoticons_my #emoticons_my_holder")
				.find('table').addClass('protected').hide().end()
				.append(
					$("<ol class='protect' style='margin:20px auto;color:#555;width:350px;'></ol>")
					.append($("<li style='margin:20px 0px;'/>").html(__("PlurkCustoms 已經代管噗浪自訂表情<br> 您應該從「<a class='gallery'>圖庫</a>」來使用表情圖片")))
					.append($("<li style='margin:20px 0px;'/>").html(__("您可以按上方的「新增...」來上傳圖片到圖庫")))
					.append($("<li style='margin:20px 0px;'/>").html(__("或者也可以點選任何他人的自訂表情新增到圖庫")))
					.append($("<li style='margin:20px 0px;'/>").html(__("如果仍需要顯示線上的自訂表情請按一下<a class='showMyEmotions'>這裡</a>")))
				)
				.find('a').css({'cursor' : 'pointer'}).end()
				.find('.gallery:not(:Event(click))').click( function(){ $(".emoticon_selecter.plurkCustoms.gallery").click(); return false; }).end()
				.find('.showMyEmotions:not(:Event(click))').click( function(){
					$(this).parents('#emoticons_my_holder').find('.protect').hide();
					$(this).parents('#emoticons_my_holder').find('.protected').addClass('forced').show();
					return false;
				 }).end();
				 
			}, 200);
		})
		
		var doc = document; 
		createStyle(doc, ".emoticon_selecter.delete.current{ background:red !important; }	.emoticon_selecter.delete.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.rename.current{ background:green !important; }	.emoticon_selecter.rename.current a{ color:white !important;}");
		createStyle(doc, ".emoticon_selecter.backup.current{ background:#CF5A00 !important; }	.emoticon_selecter.backup.current a{ color:white !important;}");
		
		//add tab
		var moreEmotionsTab = $('<li class="emoticon_selecter plurkCustoms gallery"><a href="#">'+__('圖庫')+'</a></li>').appendTo("#emoticons_tabs ul");
		moreEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			showStoredEmotions("#emoticons_show");
			return false;
			
		});
		
	/*	var renameEmotionsTab = $('<li class="emoticon_selecter plurkCustoms rename" ><a href="#">更名</a></li>').appendTo("#emoticons_tabs ul");
		renameEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			showStoredEmotions("#emoticons_show", 'rename');
			return false;
		});	
			
		var delEmotionsTab = $('<li class="emoticon_selecter plurkCustoms delete" ><a href="#">刪除</a></li>').appendTo("#emoticons_tabs ul");
		delEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			showStoredEmotions("#emoticons_show", 'delete');
			return false;
		});*/
		

		
		var backupEmotionsTab = $('<li class="emoticon_selecter plurkCustoms backup" ><a href="#">'+__('備份')+'</a></li>').appendTo("#emoticons_tabs ul");
		backupEmotionsTab.bind("click",function(){
			$("#emoticons_show").css({'color': '#555'}).html("<div style='margin: 30px; auto; text-align:center;'>Loading...</div>");
			$("#emoticons_tabs ul li").each(function(){$(this).removeClass("current")});
			$(this).addClass("current");
			
			showStoredEmotions("#emoticons_show", 'none');
			
			
			loadEmotions(function(emotions){
				
				var json = JSON.stringify(emotions);
				var b64 = utf8_to_b64( json );
				//var b64_compressed = utf8_to_b64( lzw_encode(JSON.stringify(emotions)) );
				
				$("#emoticons_show").empty();
				
				var zone = $(__("<div style='border:3px dashed gray;margin:10px;padding:10px;position:relative;'><p>備份方式：將上方的檔案圖示拖曳至桌面儲存，或點選右鍵另存</p><p>還原方式：將備份的檔案拖曳到虛線框中，而還原有兩種模式</p><p>取代模式：圖庫將被完全刪除並置換成檔案的內容</p><p>合併模式：從備份的檔案中補足圖庫中缺少的圖片</p></div>")).appendTo("#emoticons_show").bind('click', function(e){
					e.stopPropagation();
				    e.preventDefault();
				    return false;
				});
				
				var exp = $("<a class='icon_export' style='display:block;width:auto;margin:8px;padding-left:55px;line-height:48px;'title='"+__("按右鍵另存此檔案")+"' target='_blank'></a>").html(__("%d 張圖片").replace('%d', emotions.length)).prependTo(zone).map(function(){
					this.href = "data:text/plain;charset=utf-8; base64," + b64
				});
				/*$('.icon_export').click(function(){
					//window.open("data:application/octet-stream;charset=utf-8; base64," + b64);
					downloadDataURI({
					        filename: "EmotionsBackup (" + emotions.length + ").txt", 
					        data: "data:text/plain;charset=utf-8; base64," + b64
					});
				});*/
						
				var method = $("<select style='position:absolute; right:10px; top:10px;' />")
					.append( $('<option value="replace">'+__('取代模式')+'</option>') )
					.append( $('<option value="merge">'+__('合併模式')+'</option>') )
					/*.append( $('<option value="delete" style="background:red">刪除圖庫</option>').select(function(){
						var ok = confirm('你確定要完全清空圖庫嗎?');
					}) )*/
					.appendTo(zone);
					
				//var file_upload = $('<input type="file" id="restore_file" name="files"  />').appendTo(zone);	
				
				function handleFileSelect(evt) {
					
				    evt.stopPropagation();
				    evt.preventDefault();

				    var files = evt.dataTransfer.files || evt.target.files; 
				    
				    for (var i = 0, f; f = files[i]; i++) {
				    	
						var reader = new FileReader();
						reader.onload = (function(theFile) {
							return function(e) {
								var data = e.target.result;
								var emotions = {};
								if(data.indexOf('[InternetShortcut]') == 0){ 
									try{
										b64 = data.replace(/[\n\r]*/ig, '').replace('[InternetShortcut]', '').replace('URL=data:text/plain;charset=utf-8; base64,', '');
										emotions = JSON.parse(b64_to_utf8(b64));
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}else{
									try{
										emotions = JSON.parse(data);
									}catch(e){
										console.log(e);
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								for(var i=0, e ; e = emotions[i]; i++ ){
									if((e.url && e.keyword && e.hash_id) == false) {
										alert("這不是有效的圖庫備份檔案！")
										return false;
									}
								}
								
								if(method.val() == 'replace'){
									var con = confirm("警告！你確定要取代目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) replaceEmotions(emotions, function(emotions){
										for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
										getUserEmoticons();
										alert('圖庫置換成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}else{
									var con = confirm("警告！你確定要合併至目前的圖庫嗎？ (已載入" + emotions.length  + "張圖片)")
									if(con) saveEmotions(emotions, function(emotions){
										for(var e in emotions) EmoticonsStorage.renameFavorite(emotions[e].url, emotions[e].keyword);
										getUserEmoticons();
										alert('圖庫合併成功！');
										getUserEmoticons.emotions = null;
										backupEmotionsTab.trigger('click');
									})
								}
							};
						})(f);
						reader.readAsText(f)
				    }
				  }
				  
				function handleDragEnd(evt) {
				}

				function handleDragOver(evt) {
					evt.stopPropagation();
					evt.preventDefault();
				}

				  // Setup the dnd listeners.
				  $(zone).get(0).addEventListener('dragover', handleDragOver, false);
				  $(zone).get(0).addEventListener('dragend', handleDragEnd, false);
				  $(zone).get(0).addEventListener('drop', handleFileSelect, false);
				  
				 // $(file_upload).get(0).addEventListener('change', handleFileSelect, false);
				  
			});
				
			return false;
			
		}); // End backup click event
		

		$("<a style='float:right;height:9px;width:9px; margin:8px; padding:2px; background:url(http://emos.plurk.com/633e54d3723da4e8c1acc48288e952bc_w8_h8.gif) no-repeat; cursor:pointer;' title='切換視窗大小'></a>").toggle(function(){
			$(this).parents('#emoticon_selecter').addClass('large').draggable({ disabled: true });
			$('body').addClass('large_emoticon_selecter');
		},function(){
			$(this).parents('#emoticon_selecter').removeClass('large').draggable({ disabled: false });
			$('body').removeClass('large_emoticon_selecter');
		}).insertAfter("#emoticons_tabs a.bn_close");
		
		//Make it draggable
		$("#emoticon_selecter").draggable({attachTo: "#emoticons_tabs", ignore: "a, li", "cursor": "move" })
		createStyle(doc, "#emoticon_selecter.ondrag {opacity: 0.5;}");
		createStyle(doc, "#emoticon_selecter {-webkit-box-shadow: rgba(0, 0, 0, 0.8) 2px 2px 5px 0px;-webkit-transition: opacity 0.2s linear;}");
		//createStyle(doc, "#emoticon_selecter #emoticons_tabs {cursor: move ;}");
		showMoreEmotionsTab.exist = true;		

	}
	
	$(".smily_holder img, .cmp_emoticon_off, .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", showMoreEmotionsTab );
	//[reload] showStoredEmotions
	$(".smily_holder img, .cmp_emoticon_off,  .cmp_emoticon_on, .cmp_emoticon_mini_on, .emoticon_selecter_img_on").live("click", function(){
		if($(".emoticon_selecter.plurkCustoms.delete.current").length) showStoredEmotions("#emoticons_show", 'auto');
		else if($(".emoticon_selecter.plurkCustoms.current").length) showStoredEmotions("#emoticons_show", 'auto');
	});


	function showStoredEmotions(target, actionMode){

		var static = arguments.callee;
		
		// Select tab
		$('#emoticons_tabs li').removeClass('current');
		$('#emoticons_tabs li.gallery').addClass('current');
		
		var tableWrapper 	= $('.tableWrapper').length		? $('.tableWrapper')	:  $("<div class='tableWrapper' style='position:absolute;top:28px;right:0px;left:0px;bottom:0px;overflow-x:hidden;overflow-y:scroll;'><div style='padding:0 8px; color:#ccc;'>" +  __('Shift + 點選重新命名 / %s + 點選刪除').replace('%s', (isMac? "⌘" : "Ctrl")) +"</div> </div>");
		var filterWrapper 	= $('.filterWrapper').length	? $('.filterWrapper')	:  $("<div class='filterWrapper' style='position:absolute;right:0px;left:0px;top:0px;'></div>").css({'padding' : "3px 8px"});

		var totalPics = 0;
		
		getUserEmoticons(function(emotions){
			
			totalPics = emotions.length;
			
			var shown = $('table.plurkCustoms.gallery').length == 1;
			var modified = JSON.stringify($(target).data('emotions')) != JSON.stringify(emotions);
			
			console.log('shown', shown, 'modified', modified);
			
			if(shown && !modified){
				//console.log('not reload tab');
				$(target).find('.filter').focus()[0].select();
				if(typeof static.scrollTop == 'number') $(tableWrapper).scrollTop(static.scrollTop);
				return false;
			}
			
			$(target).data('emotions', emotions);
			
			$(target).unbind('scroll');
			
			var table = static.table = $("<table class='flexible plurkCustoms gallery' />");
			var count = 0;
			var row ;

			for(var i in emotions){ 
				
				if(count%8==0) row = $("<tr/>").appendTo(table);
				count++;
				var td = $("<td/>").data('emotion', emotions[i]).css({'opacity': (emotions[i].alive ? '1.0 ' : '1.0')}).appendTo(row);
				
				emo = $('<a class="a_emoticon" style="position:relative" />')
					.data('emotion', emotions[i])
					.attr('url', emotions[i].url)
					.attr('alt', emotions[i].keyword)
					.attr('title', emotions[i].keyword)
					.html("<img src='"+emotions[i].url+"' style='max-width: 50px; max-height: 50px;' />")
					.appendTo(td);
				
				td.bind("click", function(e){
					var url = $(this).find('a').attr("url");
					var keyword = $(this).find('a').attr("alt");
					
					if(e.shiftKey){ //ShiftKey rename
						var e = $(this).find('a');
						var td = $(this);
						var newKeyword = prompt(__("重新命名 %s").replace('%s', keyword) + " : ",  keyword );
						if(newKeyword && newKeyword != "" && newKeyword != keyword) {
							removeEmotion(url, function(){	//從自訂表情刪除
								deleteEmotion(keyword, function(emotions){	//從圖庫刪除
									saveEmotion(url, newKeyword, function(emotions){
										for(z in emotions) if(emotions[z].url == url) newKeyword = emotions[z].keyword; // peocessed keyword
										var emo = $(td).find('a').attr('alt', newKeyword).attr('title', newKeyword + " ("+__('已重新命名')+")").end().addClass('highlighted');
									})
								});
							});
							EmoticonsStorage.renameFavorite(url, newKeyword);
							//showCandidateEmotions(parent);
						}
					}else if( ((!isMac && e.ctrlKey) || isMac && e.metaKey) ){ //ctrlKey delete
						var e = $(this).find('a');
						var ok = confirm(__("你確定要刪除 %s 嗎").replace('%s', keyword));
						if(ok) {
							removeEmotion(url, function(){
								deleteEmotion(keyword, function(emotions){
									$(e).animate({opacity: 0.1}, 500).unbind('click');
								});
							});
							EmoticonsStorage.removeFavorite(url);
							//showCandidateEmotions(parent);
						}
					}else{
						var e = new Emotion($(this).data('emotion'));
						EmoticonsStorage.addFavorite(e);
						click_smile($(this).find('a')); return false; 
					}
				});
			}
			
			var footer = $("<div style='margin:3px 15px; color:#777; font-size:12px; cursor:default;'> "+ __('共 %d 張圖片').replace('%d', totalPics) +" <span style='float:right'> PlurkCustoms " + manifest('version') + " © 2011 <a href='http://www.plurk.com/Lackneets' target='_blank'>Lackneets</a></span></div>");
			 
			var buffer = $('<div/>').append(tableWrapper, filterWrapper).hide().appendTo('body');
			var filter = newFilter(table);
		
			tableWrapper.empty().append(table).append(footer);
			filterWrapper.empty().append(filter);
			
			$(target).css({'position': 'relative'});
			$(target).click(function(){ return false; });
			$(target).empty().prepend(filterWrapper).append(tableWrapper);
			buffer.remove();
			
			//記憶卷軸位置
			$(tableWrapper).unbind('scroll').bind('scroll', function(){ if($(target)[0].scrollHeight > $(this).height()) static.scrollTop = $(this).scrollTop();});
			$(tableWrapper).scrollTop(static.scrollTop);
			
			filter.focus()[0].select();
			
			function newFilter(table, defaultValue){

				if(typeof static.filterValue == 'undefined') static.filterValue = "";
				var filter = $("<input class='filter' type='text' placeholder='"+ __('快速找到相關的表情') + "' />")
					.val(static.filterValue)
					.keyup(function(){
						var val = $(this).val();
						val = val.replace(/^[\s　]+/, '').replace(/[\s　]+$/, '');
						
						console.log('Filter: ' + val);
						static.filterValue = val;
						
						var tds = $(table).find("td");

						//show all if empty
						if(val.length == 0) {
							//restore 
							tds.css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
							return false;
						}
						
						var matched = tds.filter(function(){
							var alt = $(this).find('a').attr('alt').toLowerCase();
							return (alt.indexOf(val.toLowerCase()) != -1);
						});
						
						
						if(matched.length == 0 && val.match(/[ㄦㄢㄞㄚㄧㄗㄓㄐㄍㄉㄅㄣㄟㄛㄨㄘㄔㄑㄎㄊㄆㄤㄠㄜㄩㄙㄕㄒㄏㄋㄇㄥㄡㄝㄖㄌㄈ]$/)){
							return false;
						}
						
						//show matched
						matched.addClass('matched').css({'max-width': '80px', 'max-height': '80px', 'opacity' : '1', 'display': ''});
						
						//hide others
						var animated = tds.not(matched).filter(':visible').filter(':lt(25)').css({'max-width': '0', 'max-height': '0', 'opacity' : '0', 'display': ''})
						tds.not(matched).not(animated).css('display', 'none !important');
						
						//make first 25 hidden element animated next time
						tds.not(matched).not(":visible").filter(':lt(25)').css({'opacity' : '1', 'display': '', 'max-width': '0', 'max-height': '0'});
					})
					.trigger('keyup')
					.css({width: '100%'})
					.click(function(){this.select();})
				return filter;
			}

		});
		
		
	}
	
	
	

	var emotionUsed = [];
	var emotionUplaoded = [];
	var emotionRemoved = [];
		
	function click_smile(smile, callback) { 
		
		var keyword = $(smile).attr("alt");;
		var url = smile.find('img').attr('src');
		
		var match = $(smile).attr("match"); if(! match ) match = 0;
		
		var uploaded = ($.inArray($(smile).attr("alt"), emotionUplaoded) != -1);
		var removed = ($.inArray($(smile).attr("alt"), emotionRemoved) != -1);
				
		if( !uploaded || removed ){ isAlive(keyword, function(isAlive){
			if(!isAlive || removed ){ 
				
				$(smile).find('img').hide().end().append($("<span style='color:red;text-decoration:none;font-size:12px!important;'>"+ __('上傳中...') +"</span>"));
				
				loadEmotions(function(emotions){
					emotions.reverse();
					
					
					var aliveCount = 0;
					for(var e in emotions) if(emotions[e].alive == true || $.inArray(emotions[e].keyword, emotionUplaoded) != -1) aliveCount++;
					
					console.log('aliveCount', aliveCount);
					
					//可移除清單
					var removeable = emotions.slice(0);
					
					//加入常用作為排序參照
					var favEmotions = EmoticonsStorage.getFavorites();
					for(var i in removeable) {
						removeable[i].favorite = 0;
						for(var f in favEmotions) if(removeable[i].url == favEmotions[f].url){
							removeable[i].favorite = favEmotions[f].favorite;
							break;
						}
					}
					function sortFavorite(a, b){ return b.favorite - a.favorite; }
					removeable.sort(sortFavorite);
					
					var _removeable = []
					for(var i in removeable) { 
						//如果正在使用則不可移除
						if($.inArray(removeable[i].keyword, emotionUsed) != -1) continue;
						//不在線上 && 未上傳
						if(removeable[i].alive != true && $.inArray(removeable[i].keyword, emotionUplaoded) == -1) continue;
						//已移除
						if($.inArray(removeable[i].keyword, emotionRemoved) != -1) continue;
						
						_removeable.push(removeable[i]);
						//console.log(removeable[i].keyword, removeable[i].favorite); 
					}
					removeable = _removeable; delete _removeable;
					
					
					var toRemove ;
					/*for(var e in emotions){ //console.log("remove? "+ emotions[e].alive +  ", " + emotions[e].keyword + ", " + ($.inArray(emotions[e].keyword, emotionUsed ) == -1) + ", " + ($.inArray(emotions[e].keyword, emotionRemoved ) == -1));
						if(emotions[e].alive == true && $.inArray(emotions[e].keyword, emotionUsed ) == -1 && $.inArray(emotions[e].keyword, emotionRemoved ) == -1){
							toRemove = emotions[e].url;
							emotionRemoved.push(emotions[e].keyword);
							console.log(emotions[e].keyword + "removed automatically")
							break;
						} 
					}*/
					
					if(aliveCount > 55 && removeable) toRemove = removeable.pop();
					
					function add(){
						
						
						addEmotion(url, keyword, function(emotions){
							if((i = $.inArray(keyword, emotionRemoved)) != -1) emotionRemoved.splice(i, 1); //從已刪除移除
							if((i = $.inArray(keyword, emotionUplaoded)) == -1) emotionUplaoded.push(keyword);	//列入已上傳
							//if(emotionUplaoded.length > 50) emotionUplaoded.splice(0, emotionUplaoded.length-50); //保留最後50個已上傳
							/*if(emotionUplaoded.length > 50) emotionUplaoded.splice(0, emotionUplaoded.length-50); 
							if($.inArray(keyword, emotionRemoved) != -1 ) emotionRemoved.splice($.inArray(keyword, emotionRemoved), 1);
							emotionUplaoded.push( keyword );*/
							console.log(keyword + "uploaded");
							$(smile).find('img').show().end().find('span').remove();
							addSmile(keyword, match);
							if(typeof callback == 'function') callback();
						});
					}
					
					if(toRemove && toRemove.url){
						removeEmotion(toRemove.url, function(emotions){
							if((i = $.inArray(toRemove.keyword, emotionUplaoded)) != -1) emotionUplaoded.splice(i, 1);	//從已上傳移除
							if((i = $.inArray(toRemove.keyword, emotionRemoved)) == -1) emotionRemoved.push(toRemove.keyword);	//列入已刪除
							add();if(typeof callback == 'function') callback();
						});
					} else {
						add();if(typeof callback == 'function') callback();
					}
				})
				
			}else{
				addSmile(keyword, match);if(typeof callback == 'function') callback();
			}
		})
		}else{ addSmile(keyword, match);if(typeof callback == 'function') callback(); }
		
		if((i = $.inArray(keyword, emotionUsed)) != -1) emotionUsed[i]= emotionUsed.splice(emotionUsed.length-1, 1, emotionUsed[i])[0]; //swap to last
		if(emotionUsed.length > 50) emotionUsed.splice(0, emotionUsed.length-50); //保留最後50個使用紀錄
		if($.inArray($(smile).attr("alt"), emotionUsed) == -1) emotionUsed.push( $(smile).attr("alt") );
		
		console.log('emotionUsed', emotionUsed);
		console.log('emotionUplaoded', emotionUplaoded)
		console.log('emotionRemoved', emotionRemoved)
		
	}
	var lastInputFocused;
	function addSmile(keyword, backward){
		if(!backward) backward = 0;
		if ( !lastInputFocused  ) lastInputFocused = document.getElementById('input_big');
		
		var s = lastInputFocused.selectionStart;
		
		if(backward) lastInputFocused.value = lastInputFocused.value.substr(0, lastInputFocused.selectionStart-backward) + lastInputFocused.value.substr(lastInputFocused.selectionStart, lastInputFocused.value.length)
		if(backward) s = s-backward;
		var t = lastInputFocused.value;
		var k = "[" + keyword + "]";
		var x = t.substr(0, s) + k + t.substr(s, t.length);
		
		lastInputFocused.value = x;
		lastInputFocused.setSelectionRange(s + k.length, s + k.length);
		
		//$("body").append("<script type='text/javascript'>/*Emoticons.forceHide();*/window.scrollTo(0,0);</script>");
	}
	//捷徑
	$.wait("#plurk_form .icons_holder, .mini_form .icons_holder", function(e){
		var icon = $('<img src="http://i.imgur.com/cQdzq.png" class="emoticon_selecter_img_off gallery" style="visibility: visible; ">').appendTo(this);

		$(".mini_form").find(icon).css('max-height', '19px').click(function(e){
			lastInputFocused = document.getElementById('input_small');
			localScript("Emoticons.toggle('input_small');");
			showMoreEmotionsTab();
			showStoredEmotions("#emoticons_show");
			$("#emoticon_selecter").css({'top': $(this).offset().top+30, 'left': $(this).offset().left});
			return false;
		});
		$("#plurk_form").find(icon).insertAfter("#plurk_form .icons_holder > img:eq(0)").click(function(e){
			lastInputFocused = document.getElementById('input_big');
			localScript("Emoticons.toggle('input_big');");
			showMoreEmotionsTab();
			showStoredEmotions("#emoticons_show");
			$("#emoticon_selecter").css({'top': $(this).offset().top+30, 'left': $(this).offset().left});
			return false;
		});
	});
	
	$("#main_poster .smily_holder img").live("click",function(){
		 lastInputFocused = document.getElementById('input_big');
		 //return false;
	});
	$(".mini_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_small');
	});
	
	$(".cmp_emoticon_on, .cmp_emoticon_off, #main_poster .emoticon_selecter_img_on, #main_poster .emoticon_selecter_img_off").live("click",function(){
		 lastInputFocused = document.getElementById('input_big');
		 console.log('input_big');
		 //return false;
	});
	$(".cmp_emoticon_mini_on, .cmp_emoticon_mini_off, .mini_form .emoticon_selecter_img_on, .mini_form .emoticon_selecter_img_off").live("click",function(){
		lastInputFocused = document.getElementById('input_small');
		console.log('input_small');
	});
	
	$(".private_plurk_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_big_private');
	});
	$(".private_plurk_form .smily_holder img").live("click",function(){
		lastInputFocused = document.getElementById('input_big_private');
	});
	
	function utf8_to_b64( str ) {
	    return window.btoa(unescape(encodeURIComponent( str )));
	}

	function b64_to_utf8( str ) {
	    return decodeURIComponent(escape(window.atob( str )));
	}
	
	// LZW-compress a string
	function lzw_encode(s) {
	    var dict = {};
	    var data = (s + "").split("");
	    var out = [];
	    var currChar;
	    var phrase = data[0];
	    var code = 256;
	    for (var i=1; i<data.length; i++) {
	        currChar=data[i];
	        if (dict[phrase + currChar] != null) {
	            phrase += currChar;
	        }
	        else {
	            out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
	            dict[phrase + currChar] = code;
	            code++;
	            phrase=currChar;
	        }
	    }
	    out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
	    for (var i=0; i<out.length; i++) {
	        out[i] = String.fromCharCode(out[i]);
	    }
	    return out.join("");
	}

	// Decompress an LZW-encoded string
	function lzw_decode(s) {
	    var dict = {};
	    var data = (s + "").split("");
	    var currChar = data[0];
	    var oldPhrase = currChar;
	    var out = [currChar];
	    var code = 256;
	    var phrase;
	    for (var i=1; i<data.length; i++) {
	        var currCode = data[i].charCodeAt(0);
	        if (currCode < 256) {
	            phrase = data[i];
	        }
	        else {
	           phrase = dict[currCode] ? dict[currCode] : (oldPhrase + currChar);
	        }
	        out.push(phrase);
	        currChar = phrase.charAt(0);
	        dict[code] = oldPhrase + currChar;
	        code++;
	        oldPhrase = phrase;
	    }
	    return out.join("");
	}
	
	function createStyle(targetDocument, style){
		var eStyle = targetDocument.createElement('style');
		eStyle.setAttribute("type", "text/css");

		if (eStyle.styleSheet) {   // IE
		    eStyle.styleSheet.cssText = style;
		} else {                // the world
		    var tStyle = targetDocument.createTextNode(style);
		    eStyle.appendChild(tStyle);
		}
		var eHead = targetDocument.getElementsByTagName('head')[0];
		eHead.appendChild(eStyle);
		return eStyle;
	}
	
	/* dependency: jquery 
		http://code.google.com/p/download-data-uri/source/checkout
	*/
	var downloadDataURI = function(options) {
	  if(!options) {
	    return;
	  }
	  $.isPlainObject(options) || (options = {data: options});
	  if(!$.browser.webkit) {
	    location.href = options.data;
	  }
	  options.filename || (options.filename = "download." + options.data.split(",")[0].split(";")[0].substring(5).split("/")[1]);
	  options.url || (options.url = "http://download-data-uri.appspot.com/");
	  $('<form method="post" action="'+options.url+'" style="display:none"><input type="hidden" name="filename" value="'+options.filename+'"/><input type="hidden" name="data" value="'+options.data+'"/></form>').submit().remove();
	}
	
	keycode = {
	    getKeyCode : function(e) {
	        var keycode = null;
	        if(window.event) {
	            keycode = window.event.keyCode;
	        }else if(e) {
	            keycode = e.which;
	        }
	        return keycode;
	    },
	    getKeyCodeValue : function(keyCode, shiftKey) {
	        shiftKey = shiftKey || false;
	        var value = null;
	        if(shiftKey === true) {
	            value = this.modifiedByShift[keyCode];
	        }else {
	            value = this.keyCodeMap[keyCode];
	        }
	        return value;
	    },
	    getValueByEvent : function(e) {
	        return this.getKeyCodeValue(this.getKeyCode(e), e.shiftKey);
	    },
	    keyCodeMap : {
	        8:"backspace", 9:"tab", 13:"return", 16:"shift", 17:"ctrl", 18:"alt", 19:"pausebreak", 20:"capslock", 27:"escape", 32:" ", 33:"pageup",
	        34:"pagedown", 35:"end", 36:"home", 37:"left", 38:"up", 39:"right", 40:"down", 43:"+", 44:"printscreen", 45:"insert", 46:"delete",
	        48:"0", 49:"1", 50:"2", 51:"3", 52:"4", 53:"5", 54:"6", 55:"7", 56:"8", 57:"9", 59:";",
	        61:"=", 65:"a", 66:"b", 67:"c", 68:"d", 69:"e", 70:"f", 71:"g", 72:"h", 73:"i", 74:"j", 75:"k", 76:"l",
	        77:"m", 78:"n", 79:"o", 80:"p", 81:"q", 82:"r", 83:"s", 84:"t", 85:"u", 86:"v", 87:"w", 88:"x", 89:"y", 90:"z",
	        96:"0", 97:"1", 98:"2", 99:"3", 100:"4", 101:"5", 102:"6", 103:"7", 104:"8", 105:"9",
	        106: "*", 107:"+", 109:"-", 110:".", 111: "/",
	        112:"f1", 113:"f2", 114:"f3", 115:"f4", 116:"f5", 117:"f6", 118:"f7", 119:"f8", 120:"f9", 121:"f10", 122:"f11", 123:"f12",
	        144:"numlock", 145:"scrolllock", 186:";", 187:"=", 188:",", 189:"-", 190:".", 191:"/", 192:"`", 219:"[", 220:"\\", 221:"]", 222:"'"
	    },
	    modifiedByShift : {
	        192:"~", 48:")", 49:"!", 50:"@", 51:"#", 52:"$", 53:"%", 54:"^", 55:"&", 56:"*", 57:"(", 109:"_", 61:"+",
	        219:"{", 221:"}", 220:"|", 59:":", 222:"\"", 188:"<", 189:">", 191:"?",
	        96:"insert", 97:"end", 98:"down", 99:"pagedown", 100:"left", 102:"right", 103:"home", 104:"up", 105:"pageup"
	    }
	};


})(jQuery);