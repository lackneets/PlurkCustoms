﻿function usingjQuery(callback){
	
	if(typeof jQuery == 'function'){
		if(typeof callback == 'function') callback(jQuery);
	}else{
		if(typeof window.$ != 'undefined'){
			arguments.callee.$ = window.$;
			console.log('window.$', window.$);
		}
		if(!arguments.callee.loading){
			arguments.callee.loading = true;
			var script = document.createElement('script'); 
			script.type = 'text/javascript'; 
			script.src = jQueryPath;
			document.body.appendChild(script);
		}
		
		var interval = setInterval(function(){
			if(typeof jQuery == 'function'){
				jQuery.noConflict();
				clearInterval(interval);
				if(typeof callback == 'function') callback(jQuery);
				console.log("jQuery is ready");
				arguments.callee.loading = false;
				if(typeof arguments.callee.$ != 'undefined'){
					 window.$ = arguments.callee.$;
					 arguments.callee.$ = null;
					 delete arguments.callee.$;
				}
			}else{
				console.log("Waiting jQuery....");
			}
		}, 500);
	}
}

function notificationSound(){
	var sound = (localStorage.getItem("notificationSound_on") == 'true');
	if(sound){
		var audio = document.createElement('audio');
		audio.setAttribute('src', $extension('notification.mp3'));
		audio.play();
	}
}

//Delay startup for 1s
setTimeout(function(){
	usingjQuery(function($){
		
		if(localStorage.getItem("notificationSound_on") == null) localStorage.setItem("notificationSound_on", true);

		var on = (localStorage.getItem("notificationSound_on") == 'true');
		var soundOnOff = $('通知 <img class="'+(on ? 'on' : 'off')+'" style="vertical-align:middle;" src="'+ ( on ? $extension('images/sound_on.png') : $extension('images/sound_off.png') ) +'" height=16 >').click(function(){
			var on = $(this).hasClass('on');
			on = !on;
			localStorage.setItem("notificationSound_on", on);
			$(this).removeClass('on off').addClass( on ? 'on' : 'off');
			$(this).attr('src', on ? $extension('images/sound_on.png') : $extension('images/sound_off.png'));
			notificationSound();
		});
		
		$('<a class="off_tab" href="#" onclick="return false"></a>')
			.attr('title', __('開啟/關閉 通知音效'))
			.empty().append( soundOnOff )
			.wrap('li')
			.prependTo("#filter_tab");
	});
	//Show replurkers
	usingjQuery(function($){
		
		function getDisplayname(uid){
			if(typeof USERS[uid] != 'undefined') return USERS[uid].display_name;
			else return null;
		}
		
		$('.plurk[id^=p]').live('mouseover click', function(){
			var div = $(this);
			var id = $(this).attr('id');
			if(!$plurks[id].obj.replurkable) return;

			if(div.find('.replurk').length) return;
			replurkers = $plurks[id].obj.replurkers;
			
			replurkers_list = "";
			replurkers_more = 0;
			for(var i in replurkers){
				if((name = getDisplayname(replurkers[i]))) replurkers_list += name + "\n";
				else replurkers_more++;
			}
			replurkers_list = replurkers_list.replace(/\n$/, '');
			//if(replurkers.length == 0) replurkers_list = __('還沒有人轉噗');
			if(replurkers.length == 0) return;
			else if(replurkers_list == "") replurkers_list = __("%d 個人轉噗").replace('%d', replurkers_more);
			else if(replurkers_more) replurkers_list += "\n" + __("以及其他 %d 個人都分享了此訊息").replace('%d', replurkers_more);
			else replurkers_list += "\n" + __("分享了此訊息");
			
			
			$(_('<a class="replurk action replurkers" style="color:#ccc; cursor:default;" >'+__('轉噗(%d)')+'</a>').replace('%d', replurkers.length)).attr('title', replurkers_list).insertBefore(div.find('.manager a:last'));

		});
		
		//enlarge avatars
		$('.p_img img').live('mouseenter', function(){
			function enlarge(obj){
				$(obj).stop(true).animate({width: 100, height: 100, top:-40, left:-40}, 500);
				$(obj).css({'z-index' : '99999', 'position': 'relative', '-webkit-box-shadow' : 'rgba(0, 0, 0, 0.796875) 0px 0px 10px 0px'});
			}
			if( (m = $(this).attr('src').match(/(\d+)-small(\d+)/)) ){
				//$(this).css({top: 0, left:0});
				$(this).one('load', function(){	enlarge(this); });
				$(this).attr('src', ( 'http://avatars.plurk.com/'+ m[1] +'-big'+m[2]+'.jpg' ));
			}else{ enlarge(this); }

		}).live('mouseleave', function(){
			$(this).stop(true).animate({width: 20, height: 20, top:0, left:0}, 500, function(){ $(this).css({'-webkit-box-shadow' : 'none'}); });
			$(this).unbind('load');
		});			
		
		function dateString(_d){ 
			//function td(d){ return (new String(d).match(/^d{1}$/)) '0' + d : d; }
			var y = _d.getFullYear();
			var m = _d.getMonth() +1;
			var d = _d.getDate();
			var h = _d.getHours();
			var i = _d.getMinutes();
			var s = _d.getSeconds();
			var a = (_d.getHours() < 12 ) ? __("早上") : __("下午");
			var h12 = h%12;
			//if(y == new Date().getFullYear()) return sprintf('%02d:%02d %d/%d', h, i, m, d);
			return sprintf('%s %02d:%02d %d/%d/%d', a, h12, i, y, m, d);
		}
		function countTime($time){
			$sec = (new Date().getTime() - ($time).getTime()) /1000; 
						
			if($sec < 60)
				return __("剛剛");
				
			else if($sec < 60*60)
				return sprintf(__("%s 分鐘前"), Math.round($sec /60));
				
			else if($sec < 86400)
				return sprintf(__("%s 小時前"), Math.round($sec /(60*60)));
				
			else if($sec > 86400 && $sec < 86400*2)
				return __("昨天");
					
			else if($sec > 86400 && $sec < 86400*7)
				return sprintf(__("%s 天前"), Math.round($sec /(60*60*24)));
				
			else if($sec < 86400*30)
				return sprintf(__("%s 星期前"), Math.round($sec /(60*60*24*7)));
				
			else 
				return dateString($time);
		}
					
		//show time
		$('.plurk[id^=p]').live('mouseover click', function(){
			var div = $(this);
			var id = $(this).attr('id');
			
			var time = div.find('.posted');
			if(time.length == 0) time = $('<a class="posted action" style="color:#ccc; cursor:default;display:block" ></a>').appendTo(div.find('.manager'));

			time.html(countTime($plurks[id].obj.posted)).attr('title', dateString($plurks[id].obj.posted));
			
		});	
			
	});


}, 2000);



setInterval(function(){
	if(typeof Poll == 'undefined') return;
	Poll.counts = Poll.getUnreadCounts();
	
	if(typeof arguments.callee.my == 'undefined' && (Poll.counts.my + Poll.counts.responded) > 0) notificationSound();
	if(typeof arguments.callee.my == 'undefined') arguments.callee.my = Poll.counts.my;
	if(typeof arguments.callee.responded == 'undefined') arguments.callee.responded = Poll.counts.responded;
	
	if(arguments.callee.my < Poll.counts.my || arguments.callee.responded < Poll.counts.responded){
		notificationSound();
		console.log('notificationSound');
	}
	arguments.callee.my = Poll.counts.my;
	arguments.callee.responded = Poll.counts.responded;
		
	var title = "";	 var detail = "";
	if(Poll.counts.my) detail 			+= " " + __("我 %d").replace('%d', Poll.counts.my) + " ";	
	if(Poll.counts.responded) detail 	+= " " + __("回 %d").replace('%d', Poll.counts.responded) + " ";
	if(Poll.counts.priv) detail 		+= " " + __("私 %d").replace('%d', Poll.counts.priv) + " ";
	detail = detail.replace(/^\s+/, '').replace(/\s+$/, '');
	if(detail) title = title + " " + detail + "";
	if(Poll.counts.all) title 			+= " " + __("未讀 %d").replace('%d', Poll.counts.all) + " ";
	
	if(title) document.title = title + " - " + TopBar.cur_page_title;
	else document.title = title;
}, 200);


function markMuted(ids){
	if(typeof ids == 'array' || typeof ids == 'object'){
		for(var i in ids) markMuted(ids[i]);
		return;
	}
	var id = ids;
	console.log("Mute " + id);
	//if(typeof $plurks['p' + id] != 'undefined') delete $plurks['p' + id];	
	if(typeof $plurks['p' + id] != 'undefined'){
		var p = $plurks['p' + id];
		p.obj.is_unread = 2;
		p.block.is_rendered = false;
		for(i in p) if(p[i] instanceof HTMLDivElement){  console.log('delete', p[i]); delete p[i]; }
	}
	//if(typeof id == 'string' || typeof id == 'number') for(var i in $plurks) if($plurks[i].obj.plurk_id == id) ($plurks[i].obj.is_unread = 2);
}
